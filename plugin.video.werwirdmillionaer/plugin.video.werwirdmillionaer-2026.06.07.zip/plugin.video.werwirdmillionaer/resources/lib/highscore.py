import json
from urllib.request import Request, urlopen

_HS_URL   = 'http://more.bplaced.net/wwm/highscore.php'
_HS_TOKEN = 'wwm_0818'


def submit(nickname, score, level, prize):
    try:
        payload = json.dumps({
            'token':    _HS_TOKEN,
            'nickname': nickname,
            'score':    int(score),
            'level':    int(level),
            'prize':    str(prize),
        }).encode('utf-8')
        req = Request(_HS_URL, payload, headers={'Content-Type': 'application/json'})
        urlopen(req, timeout=8)
    except Exception:
        pass


def get_scores(period='week', limit=20):
    try:
        full_url = '{}?period={}&limit={}'.format(_HS_URL, period, int(limit))
        resp = urlopen(full_url, timeout=10)
        data = json.loads(resp.read().decode('utf-8'))
        return data.get('scores', [])
    except Exception:
        return []
