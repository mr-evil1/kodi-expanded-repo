import json
import xbmcaddon

_ADDON = xbmcaddon.Addon()
_KEY   = 'session_data'


def save(session):
    _ADDON.setSetting(_KEY, json.dumps(session))


def load():
    raw = _ADDON.getSetting(_KEY)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError:
        return None


def clear():
    _ADDON.setSetting(_KEY, '')
