import xbmc
import xbmcgui
import xbmcaddon

from resources.lib.api import WWMClient, WWMError
from resources.lib.gui import WWMWindow
import resources.lib.session as session_store

_ADDON = xbmcaddon.Addon()
_DLG   = xbmcgui.Dialog()


def _parse_login(data):
    keys = ['userId', 'gameId', 'acId', 'acTitle', 'acDate',
            'nick', 'sessionId', 'latestShow', 'latestDaily', 'loginId']
    return {k: str(data.get(k, '')) for k in keys}


class Game:
    def __init__(self):
        self._client  = WWMClient()
        self._session = None

    def _authenticate(self):
        saved      = session_store.load()
        use_account = _ADDON.getSetting('use_account') == 'true'

        if saved and saved.get('loginId'):
            try:
                data = self._client.session_login(
                    saved['loginId'], saved['gameId'])
                self._session = _parse_login(data)
                session_store.save(self._session)
                return True
            except WWMError:
                session_store.clear()

        if use_account:
            email    = _ADDON.getSetting('username').strip()
            password = _ADDON.getSetting('password').strip()
            if not email or not password:
                choice = _DLG.yesno(
                    'Kein Konto eingetragen',
                    'Noch kein Konto? Jetzt kostenlos bei wwm.rtl.de registrieren?\n\n'
                    'Oder zuerst in den Einstellungen E-Mail / Passwort eintragen.',
                    nolabel='Einstellungen öffnen',
                    yeslabel='Jetzt registrieren')
                if choice:
                    self._register_new_account()
                else:
                    _ADDON.openSettings()
                return False
            try:
                data = self._client.login_account(email, password)
            except WWMError as e:
                _DLG.ok('Login fehlgeschlagen', str(e))
                return False

        else:
            shown_hint = _ADDON.getSetting('guest_hint_shown') == 'true'
            if not shown_hint:
                _DLG.ok(
                    'Gast-Modus',
                    'Du spielst als Gast.\n\n'
                    'Highscores werden nur mit einem\n'
                    'registrierten Konto (wwm.rtl.de) gespeichert.\n\n'
                    'Konto in den Einstellungen eintragen.')
                try:
                    xbmcaddon.Addon().setSetting('guest_hint_shown', 'true')
                except Exception:
                    pass

            nickname = _ADDON.getSetting('nickname').strip()
            if not nickname and saved:
                nickname = saved.get('nickname', '').strip()
            if not nickname:
                nickname = _DLG.input('Spitzname eingeben:')
                if not nickname:
                    nickname = 'Spieler'
                try:
                    xbmcaddon.Addon().setSetting('nickname', nickname)
                except Exception:
                    pass
            try:
                data = self._client.login_guest(nickname=nickname)
            except WWMError as e:
                _DLG.ok('Verbindungsfehler', str(e))
                return False

        self._session = _parse_login(data)
        if not use_account:
            self._session['nickname'] = nickname
        session_store.save(self._session)
        return True

    def _register_new_account(self):
        _DLG.ok('Registrierung', 'Bitte folgende Felder ausfüllen.\n(Alle Felder sind Pflichtfelder)')

        nickname = _DLG.input('Spielername (Nickname):')
        if not nickname:
            return

        email = _DLG.input('E-Mail-Adresse:')
        if not email:
            return

        password = _DLG.input('Passwort:', type=xbmcgui.INPUT_ALPHANUM,
                               option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return

        password_again = _DLG.input('Passwort (Wiederholung):', type=xbmcgui.INPUT_ALPHANUM,
                                     option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password_again:
            return

        if password != password_again:
            _DLG.ok('Fehler', 'Die Passwörter stimmen nicht überein.')
            return

        try:
            self._client.register_account(email, password, password_again, nickname)
        except WWMError as e:
            _DLG.ok('Registrierung fehlgeschlagen', str(e))
            return

        try:
            _ADDON.setSetting('username', email)
            _ADDON.setSetting('password', password)
            _ADDON.setSetting('use_account', 'true')
        except Exception:
            pass

        _DLG.ok(
            'Registrierung erfolgreich',
            'Konto für {} wurde angelegt.\n\n'
            'E-Mail und Passwort wurden in den Einstellungen gespeichert.\n'
            'Bitte starte das Spiel erneut.'.format(email))

    def _pick_library(self, lib_data):
        if not isinstance(lib_data, list) or not lib_data:
            return 'undefined'
        entries  = ['Zufaellige Fragen (alle)']
        entries += ['{} – {}'.format(
            l.get('txt', l.get('label', l.get('id', '?'))),
            l.get('desc', '')) for l in lib_data]
        idx = _DLG.select('Fragensatz waehlen', entries)
        if idx < 0:
            return None
        if idx == 0:
            return 'undefined'
        return lib_data[idx - 1].get('id', 'undefined')

    def run(self):
        xbmcgui.Dialog().notification(
            'WWM', 'Verbinde mit Server...',
            xbmcgui.NOTIFICATION_INFO, 2000)

        try:
            lib_data = self._client.library_init()
        except WWMError as e:
            _DLG.ok('Verbindungsfehler', str(e))
            return

        if not self._authenticate():
            return

        s      = self._session
        lib_id = self._pick_library(lib_data)
        if lib_id is None:
            return

        try:
            first = self._client.resume_session(
                s['userId'], s['nick'], lib_id, s['sessionId'])
        except WWMError as e:
            _DLG.ok('Fehler', 'Spielstart fehlgeschlagen:\n' + str(e))
            return

        window = WWMWindow(s, lib_id, first, self._client)
        window.doModal()
        del window
