import hashlib
import json
import ssl
import time
from urllib.request import Request, build_opener, HTTPCookieProcessor, HTTPSHandler
from urllib.parse  import urlencode
from urllib.error  import HTTPError, URLError
from http.cookiejar import CookieJar

BASE_URL = 'https://wwm.rtl.de/wwm/game/'
VERSION  = '7'
PLATFORM = 'appAndroid'

HEADERS = {
    'User-Agent':       ('Mozilla/5.0 (Linux; Android 6.0.1; SM-G977N Build/V417IR; wv) '
                         'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 '
                         'Chrome/83.0.4103.120 Safari/537.36'),
    'Origin':           'https://localhost',
    'Referer':          'https://localhost/',
    'X-Requested-With': 'com.rtlinteractive.wwm',
    'Accept':           '*/*',
    'Accept-Language':  'de-DE,de;q=0.9',
    'Content-Type':     'application/x-www-form-urlencoded',
}


class WWMError(Exception):
    pass


class WWMClient:
    def __init__(self):
        jar = CookieJar()
        try:
            ctx = ssl.create_default_context()
        except Exception:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        self._opener = build_opener(
            HTTPCookieProcessor(jar),
            HTTPSHandler(context=ctx),
        )

    def _post(self, endpoint, params):
        url  = BASE_URL + endpoint
        data = urlencode(params).encode('utf-8')
        req  = Request(url, data=data)
        for k, v in HEADERS.items():
            req.add_header(k, v)
        try:
            resp = self._opener.open(req, timeout=20)
            body = resp.read().decode('utf-8')
        except HTTPError as e:
            raise WWMError('HTTP {}: {}'.format(e.code, e.reason))
        except URLError as e:
            raise WWMError('Verbindungsfehler: {}'.format(e.reason))
        try:
            result = json.loads(body)
        except ValueError:
            raise WWMError('Ungültige Serverantwort: ' + body[:100])
        if isinstance(result, dict) and 'alert' in result:
            raise WWMError(result['alert'])
        return result

    def library_init(self):
        return self._post('library/init', {})

    def login_guest(self, nickname=''):
        params = {
            'email': '@', 'password': 'guest',
            'version': VERSION, 'platform': PLATFORM,
        }
        if nickname:
            params['nickname'] = nickname
            params['nick2']    = nickname
        return self._post('login', params)

    def login_account(self, email, password):
        return self._post('login', {
            'email': email, 'password': password,
            'version': VERSION, 'platform': PLATFORM,
        })

    def register_account(self, email, password, password_again, nickname):
        return self._post('account/register', {
            'ac':            'register',
            'email':         email,
            'password':      password,
            'passwordAgain': password_again,
            'nickname':      nickname,
            'agree':         '1',
        })

    def session_login(self, login_id, game_id):
        return self._post('sessionLogin', {
            'loginId': login_id, 'gameId': game_id,
            'version': VERSION, 'platform': PLATFORM,
        })

    def resume_session(self, user_id, nick, lib_id, session_id):
        return self._post('resumeSession', {
            'userId': user_id, 'email': nick,
            'libId':  lib_id if lib_id else 'undefined',
            'sessionId': session_id, 'version': VERSION,
        })

    def quiz_check(self, user_id, nick, session_id, answer,
                   timer_secs, risk_mode=False, extra_params=None):
        timer_str = str(int(round(timer_secs)))
        microtime = hashlib.md5(
            ('a' + str(user_id) + timer_str + str(session_id)).encode()
        ).hexdigest()
        params = {
            'timerDetails': timer_str, 'userId': user_id, 'email': nick,
            'riskmode': '1' if risk_mode else '0', 'microtime': microtime,
            'sessionId': session_id, 'answerGiven': answer, 'version': VERSION,
        }
        if extra_params:
            params.update(extra_params)
        return self._post('quiz/check', params)

    def quiz_wayout(self, user_id, nick, session_id):
        return self._post('quiz/wayout', {
            'userId': user_id, 'email': nick,
            'sessionId': session_id, 'version': VERSION,
        })

    def scores(self, user_id, game_id, session_id, period='week', start=0):
        return self._post('scores', {
            'start':      str(start),
            'periodType': period,
            'version':    VERSION,
            'userId':     user_id,
            'gameId':     game_id,
            'sessionId':  session_id,
        })
