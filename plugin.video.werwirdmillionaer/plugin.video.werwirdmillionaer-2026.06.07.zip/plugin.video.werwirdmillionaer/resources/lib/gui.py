import time
import threading
import xbmc
import xbmcgui
import xbmcaddon

from resources.lib import pyxbmct
from resources.lib.api import WWMClient, WWMError

_ADDON = xbmcaddon.Addon()

MONEY_TREE = [
    '100 €', '200 €', '300 €', '500 €', '1.000 €',
    '2.000 €', '4.000 €', '8.000 €', '16.000 €', '32.000 €',
    '64.000 €', '125.000 €', '250.000 €', '500.000 €', '1.000.000 €',
]
MONEY_VALUES = [
    100, 200, 300, 500, 1000,
    2000, 4000, 8000, 16000, 32000,
    64000, 125000, 250000, 500000, 1000000,
]
SAFE_LEVELS = {4, 9}

def _safe_prize(level):
    if level <= 3:
        return '0 €'
    elif level <= 8:
        return '1.000 €'
    else:
        return '32.000 €'

def _quit_prize(level):
    if level <= 0:
        return '0 €'
    return MONEY_TREE[level - 1]

ANSWER_LABELS = ['A', 'B', 'C', 'D']

COL_GOLD    = '0xFFFFD700'
COL_WHITE   = '0xFFFFFFFF'
COL_GRAY    = '0xFF888888'
COL_GREEN   = '0xFF44DD66'
COL_RED     = '0xFFEE4444'
COL_SAFE    = '0xFFFFBB22'
COL_ACTIVE  = '0xFFFFD700'
COL_DIM     = '0xFF555566'


class WWMWindow(pyxbmct.AddonFullWindow):

    G_COL0, G_COL1 = 1, 36
    G_MID          = 18
    T_COL0, T_COL1 = 38, 49

    def __new__(cls, *args, **kwargs):
        return super(WWMWindow, cls).__new__(cls)

    def _setFrame(self, title):
        _fanart_path = _ADDON.getAddonInfo('path') + '/fanart.jpg'
        super(WWMWindow, self)._setFrame(title)
        self.main_bg.setImage(_fanart_path)
        self.main_bg.setColorDiffuse('0x20FFFFFF')
        self.background.setColorDiffuse('0x00000000')

    def __init__(self, session, lib_id, first_data, client):
        super(WWMWindow, self).__init__('')
        try:
            tasks = first_data.get('tasks') or first_data.get('set', {}).get('tasks', [])
            if tasks and isinstance(tasks, list):
                self._sort_ra_initial = str(tasks[0].get('ra', '')).strip()
            else:
                self._sort_ra_initial = str(first_data.get('ra', '')).strip()
        except Exception:
            self._sort_ra_initial = ''

        self.setGeometry(1280, 720, 100, 50)

        self._client  = client
        self._session = session
        self._lib_id  = lib_id
        self._level   = 0
        self._answers = []
        self._start_t = 0.0
        self._locked  = False
        self._first_data = first_data

        self._sort_remaining   = []
        self._sort_order       = []
        self._is_sort          = False
        self._timer_thread     = None
        self._timer_active     = False
        self._score            = 0
        self._correct_answers  = 0
        self._build_controls()
        self._setup_navigation()
        self._connect_events()

        self._process_question(self._first_data)
        try:
            self.setFocus(self.btn_answers[0])
        except Exception:
            pass

    def _build_controls(self):
        c0, c1, cm = self.G_COL0, self.G_COL1, self.G_MID
        tc0, tc1   = self.T_COL0, self.T_COL1

        _nick        = str(self._session.get('nick', '')).strip()
        _email       = _ADDON.getSetting('username').strip()
        _use_account = _ADDON.getSetting('use_account') == 'true'

        if _use_account and _email:
            _line1 = '[B][COLOR {}]{}[/COLOR][/B]'.format(COL_WHITE, _nick)
            _line2 = '[COLOR {}]{}[/COLOR]'.format(COL_GRAY, _email)
        else:
            _line1 = '[B][COLOR {}]{}[/COLOR][/B]'.format(COL_WHITE, _nick)
            _line2 = '[COLOR {}]Nicht registriert oder eingeloggt[/COLOR]'.format(COL_GRAY)

        self.lbl_user_nick = pyxbmct.Label(
            _line1, font='font16', textColor=COL_WHITE,
            alignment=pyxbmct.ALIGN_LEFT | pyxbmct.ALIGN_CENTER_Y)
        self.placeControl(self.lbl_user_nick, 0, c0, 3, 17)

        self.lbl_user_email = pyxbmct.Label(
            _line2, font='font12', textColor=COL_GRAY,
            alignment=pyxbmct.ALIGN_LEFT | pyxbmct.ALIGN_CENTER_Y)
        self.placeControl(self.lbl_user_email, 3, c0, 3, 17)

        self.lbl_prize = pyxbmct.Label(
            '', font='font16', textColor=COL_GOLD,
            alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.lbl_prize, 3, c0, 3, c1 - c0)

        self.lbl_timer = pyxbmct.Label(
            '', font='font16', textColor=COL_GOLD,
            alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.lbl_timer, 3, c0 + 25, 3, 8)

        self.txt_question = pyxbmct.TextBox(textColor=COL_WHITE)
        self.placeControl(self.txt_question, 8, c0, 30, 28)

        self.btn_answers = []
        positions = [
            (42, c0,  cm - c0),
            (42, cm,  c1  - cm),
            (59, c0,  cm - c0),
            (59, cm,  c1  - cm),
        ]
        for row, col, span in positions:
            btn = pyxbmct.Button('', textColor=COL_WHITE,
                                 focusedColor=COL_GOLD)
            self.placeControl(btn, row, col, 15, span)
            self.btn_answers.append(btn)

        self.lbl_status = pyxbmct.Label(
            '', font='font12', textColor=COL_GRAY,
            alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.lbl_status, 76, c0, 5, c1 - c0)

        self.btn_quit = pyxbmct.Button(
            'Aufgeben', textColor='0xFFFF8888', focusedColor=COL_RED)
        self.placeControl(self.btn_quit, 88, c0, 10, c1 - c0)

        self.btn_skip = pyxbmct.Button(
            'Sortierfrage überspringen', textColor='0xFFBBBBFF',
            focusedColor='0xFFAAAAFF')
        self.placeControl(self.btn_skip, 82, c0, 8, c1 - c0)
        self.btn_skip.setVisible(False)

        _icon_path = _ADDON.getAddonInfo('path') + '/icon.png'
        self.img_icon = pyxbmct.Image(_icon_path, aspectRatio=1)
        self.placeControl(self.img_icon, 6, 30, 25, 7)

        lbl_hdr = pyxbmct.Label(
            'Gewinnstufen', font='font12', textColor=COL_GRAY,
            alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(lbl_hdr, 2, tc0, 3, tc1 - tc0)

        self._money_labels = []
        for i in range(15):
            level_idx = 14 - i
            row       = 5 + i * 6
            lbl = pyxbmct.Label(
                MONEY_TREE[level_idx], font='font12', textColor=COL_GRAY,
                alignment=pyxbmct.ALIGN_CENTER)
            self.placeControl(lbl, row, tc0, 5, tc1 - tc0)
            self._money_labels.append((level_idx, lbl))

        lbl_score_hdr = pyxbmct.Label(
            'Punkte', font='font14', textColor=COL_GRAY,
            alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(lbl_score_hdr, 94, tc0, 3, tc1 - tc0)

        self.lbl_score = pyxbmct.Label(
            '[B][COLOR {}]0[/COLOR][/B]'.format(COL_GOLD),
            font='font20', textColor=COL_GOLD,
            alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.lbl_score, 97, tc0, 5, tc1 - tc0)

    def _setup_navigation(self):
        a, b, c, d = self.btn_answers
        q  = self.btn_quit
        sk = self.btn_skip
        a.controlRight(b);  a.controlDown(c);   a.controlUp(sk)
        b.controlLeft(a);   b.controlDown(d);   b.controlUp(sk)
        c.controlRight(d);  c.controlUp(a);     c.controlDown(sk)
        d.controlLeft(c);   d.controlUp(b);     d.controlDown(sk)
        sk.controlDown(q);  sk.controlUp(c);    sk.controlLeft(a)
        q.controlUp(sk);    q.controlRight(d)

    def _connect_events(self):
        self.connect(pyxbmct.ACTION_NAV_BACK,     self.close)
        self.connect(pyxbmct.ACTION_PREVIOUS_MENU, self.close)
        for i, btn in enumerate(self.btn_answers):
            self.connect(btn, lambda idx=i: self._on_answer(idx))
        self.connect(self.btn_quit, self._on_quit)
        self.connect(self.btn_skip, self._on_skip_sort)

    def _show_question(self, question, answers, level):
        self._start_timer(59)
        self._level   = level
        self._answers = answers
        self._start_t = time.time()
        self._locked  = False

        self.lbl_prize.setLabel(
            'Frage {}  –  {}'.format(level + 1, MONEY_TREE[level]))
        self.txt_question.setText(
            '[CR][CR]' + question)
        self.lbl_status.setLabel('')
        self._refresh_money_tree(level)

        for i, btn in enumerate(self.btn_answers):
            if i < len(answers):
                btn.setLabel(
                    '  {}:  {}'.format(ANSWER_LABELS[i], answers[i]))
                btn.setEnabled(True)
                btn.setVisible(True)
            else:
                btn.setLabel('')
                btn.setVisible(False)

        self.btn_quit.setEnabled(True)
        self.btn_skip.setVisible(False)
        try:
            self.setFocus(self.btn_answers[0])
        except Exception:
            pass

    def _refresh_money_tree(self, current_level):
        for level_idx, lbl in self._money_labels:
            is_safe    = level_idx in SAFE_LEVELS
            is_current = level_idx == current_level
            is_passed  = level_idx < current_level

            if is_current:
                text  = '[B][COLOR {}]>>  {}[/COLOR][/B]'.format(
                    COL_GOLD, MONEY_TREE[level_idx])
            elif is_passed:
                text  = '[COLOR {}]{}[/COLOR]'.format(
                    COL_GREEN, MONEY_TREE[level_idx])
            elif is_safe:
                text  = '[B][COLOR {}]{}[/COLOR][/B]'.format(
                    COL_SAFE, MONEY_TREE[level_idx])
            else:
                text  = '[COLOR {}]{}[/COLOR]'.format(
                    COL_GRAY, MONEY_TREE[level_idx])

            lbl.setLabel(text)

    def _on_answer(self, idx):
        if self._locked or idx >= len(self._answers):
            return
        elapsed = time.time() - self._start_t

        if self._is_sort:
            if idx in self._sort_picked:
                return
            self._handle_sort_pick(idx)
            return

        self._lock_buttons()

        self.lbl_status.setLabel('[COLOR {}]Prüfe Antwort...[/COLOR]'.format(COL_GRAY))
        try:
            s      = self._session
            result = self._client.quiz_check(
                s['userId'], s['nick'], s['sessionId'],
                str(idx + 1), elapsed)
        except WWMError as e:
            xbmcgui.Dialog().ok('Fehler', str(e))
            self.close()
            return
        except Exception as e:
            xbmcgui.Dialog().ok('Fehler', str(e))
            self.close()
            return

        correct   = result.get('correct') or result.get('isCorrect') or result.get('c')
        _result_str = str(result.get('result', ''))
        game_over = result.get('gameOver') or result.get('game_over') or (_result_str == 'wr')
        ra        = result.get('ra') or result.get('correctAnswer') or \
                    result.get('correct_answer', '')
        next_data = result.get('next') or result.get('nextQuestion')

        if result.get('q') and not game_over:
            next_inline = {k: v for k, v in result.items()
                           if k not in ('ra', 'result', 'serverScore')}
        else:
            next_inline = None
        if not next_data:
            next_data = next_inline
        if not correct and _result_str == 'ok' and next_inline:
            correct = True

        self._update_score(result)
        correct_label = self._resolve_label(ra)

        if not correct or game_over:
            self.lbl_status.setLabel(
                '[COLOR {}]Falsch!  Richtig: {}[/COLOR]'.format(
                    COL_RED, correct_label))
            xbmc.sleep(2500)
            prize = _safe_prize(self._level)
            self._submit_highscore(prize)
            xbmcgui.Dialog().ok(
                'Leider falsch!',
                'Richtige Antwort: {}\n\nDu nimmst {} mit.'.format(
                    correct_label, prize))
            self.close()
            return

        if self._level >= 14:
            self.lbl_status.setLabel(
                '[COLOR {}]RICHTIG - 1.000.000 Euro![/COLOR]'.format(COL_GREEN))
            xbmc.sleep(2000)
            self._correct_answers += 1
            self._submit_highscore('1.000.000 €')
            xbmcgui.Dialog().ok('Gewonnen!',
                                 'Herzlichen Glückwunsch!\n1.000.000 Euro!')
            self.close()
            return

        self.lbl_status.setLabel(
            '[COLOR {}]Richtig!  Weiter...[/COLOR]'.format(COL_GREEN))
        self._correct_answers += 1
        xbmc.sleep(2000)
        self._load_next(next_data)

    def close(self):
        self._stop_timer()
        super(WWMWindow, self).close()

    def _on_quit(self):
        self._stop_timer()
        if self._locked:
            return
        self._lock_buttons()
        effective_level = self._level if self._level > 0 else self._correct_answers
        prize = _quit_prize(effective_level)
        try:
            s = self._session
            self._client.quiz_wayout(s['userId'], s['nick'], s['sessionId'])
        except Exception:
            pass
        self._submit_highscore(prize)
        xbmcgui.Dialog().ok('Aufgegeben',
                             'Du nimmst {} mit.'.format(prize))
        self.close()

    def _on_skip_sort(self):
        if self._locked or not self._is_sort:
            return
        self._lock_buttons()
        self.lbl_status.setLabel(
            '[COLOR {}]Sortierfrage wird uebersprungen...[/COLOR]'.format(COL_GRAY))
        dummy = ''.join(str(i + 1) for i in range(len(self._answers)))
        elapsed = time.time() - self._start_t
        try:
            s = self._session
            result = self._client.quiz_check(
                s['userId'], s['nick'], s['sessionId'],
                dummy, elapsed,
                extra_params={'disableTimeLimit': '1'})
        except WWMError as e:
            xbmcgui.Dialog().ok('Fehler', str(e))
            self.close()
            return

        correct   = result.get('correct') or result.get('isCorrect') or result.get('c')
        _result_str = str(result.get('result', ''))
        game_over = result.get('gameOver') or result.get('game_over') or (_result_str == 'wr')
        next_data = result.get('next') or result.get('nextQuestion')
        ra        = result.get('ra') or result.get('correctAnswer') or \
                    result.get('correct_answer', '')

        if result.get('q') and not game_over:
            next_inline = {k: v for k, v in result.items()
                           if k not in ('ra', 'result', 'serverScore')}
        else:
            next_inline = None
        if not next_data:
            next_data = next_inline
        if not correct and _result_str == 'ok' and next_inline:
            correct = True

        self._update_score(result)
        self._is_sort = False
        self.btn_skip.setVisible(False)

        if not correct or game_over:
            correct_label = self._resolve_label(ra)
            self.lbl_status.setLabel(
                '[COLOR {}]Sortierfrage nicht bestanden.[/COLOR]'.format(COL_GRAY))
            xbmc.sleep(1500)
            prize = _safe_prize(self._level)
            self._submit_highscore(prize)
            xbmcgui.Dialog().ok(
                'Sortierfrage uebersprungen',
                'Richtige Reihenfolge: {}\n\nDu nimmst {} mit.'.format(
                    correct_label, prize))
            self.close()
            return

        self.lbl_status.setLabel(
            '[COLOR {}]Sortierfrage uebersprungen - weiter![/COLOR]'.format(COL_GREEN))
        xbmc.sleep(1500)
        self._load_next(next_data)

    def _start_sort(self, question, answers, level, ra=''):
        self._is_sort        = True
        self._sort_picked    = []
        self._sort_order     = []
        self._sort_ra        = str(ra).strip() or getattr(self, '_sort_ra_initial', '')
        self._show_question(question, answers, level)
        self.btn_skip.setVisible(True)
        self._update_sort_buttons()

    def _update_sort_buttons(self):
        pos = len(self._sort_picked) + 1
        n   = len(self._answers)
        self.lbl_status.setLabel(
            '[COLOR {}]Position {} von {} wählen:[/COLOR]'.format(
                COL_GRAY, pos, n))
        for i, btn in enumerate(self.btn_answers):
            if i >= n:
                continue
            label_text = '  {}:  {}'.format(ANSWER_LABELS[i], self._answers[i])
            if i in self._sort_picked:
                rank = self._sort_picked.index(i) + 1
                btn.setLabel('[COLOR {}]  {}:  {}  [{}][/COLOR]'.format(
                    COL_GOLD, ANSWER_LABELS[i], self._answers[i], rank))
                btn.setEnabled(False)
            else:
                btn.setLabel(label_text)
                btn.setEnabled(True)
            btn.setVisible(True)
        self._locked = False
        try:
            self.btn_quit.setEnabled(True)
            self.btn_skip.setEnabled(True)
        except Exception:
            pass
        try:
            for i, btn in enumerate(self.btn_answers):
                if i < n and i not in self._sort_picked:
                    self.setFocus(btn)
                    break
        except Exception:
            pass

    def _handle_sort_pick(self, btn_idx):
        if btn_idx >= len(self._answers) or btn_idx in self._sort_picked:
            self._locked = False
            return
        self._sort_picked.append(btn_idx)
        self._sort_order = [i + 1 for i in self._sort_picked]

        if len(self._sort_picked) == len(self._answers):
            answer  = ''.join(str(x) for x in self._sort_order)
            elapsed = time.time() - self._start_t
            self.lbl_status.setLabel(
                '[COLOR {}]Prüfe Sortierung...[/COLOR]'.format(COL_GRAY))
            try:
                s = self._session
                result = self._client.quiz_check(
                    s['userId'], s['nick'], s['sessionId'],
                    answer, elapsed)
            except WWMError as e:
                xbmcgui.Dialog().ok('Fehler', str(e))
                self.close()
                return

            _result_str = str(result.get('result', ''))
            game_over = result.get('gameOver') or result.get('game_over') or (_result_str == 'wr')
            ra_correct = str(result.get('ra', '')).strip()
            user_answer = ''.join(str(x) for x in self._sort_order)
            if result.get('q') and not game_over:
                next_inline = {k: v for k, v in result.items()
                               if k not in ('ra', 'result', 'serverScore')}
            else:
                next_inline = None
            next_data = result.get('next') or result.get('nextQuestion') or next_inline
            if ra_correct and len(ra_correct) == 4 and ra_correct.isdigit():
                correct = (user_answer == ra_correct) and not game_over
            else:
                correct = (_result_str == 'ok') and not game_over

            self._update_score(result)

            if not correct or game_over:
                ra = result.get('ra') or result.get('correctAnswer') or result.get('correct_answer', '')
                correct_label = self._resolve_label(ra)
                prize = _safe_prize(self._level)
                self.lbl_status.setLabel(
                    '[COLOR {}]Falsche Reihenfolge![/COLOR]'.format(COL_RED))
                xbmc.sleep(2000)
                self._submit_highscore(prize)
                xbmcgui.Dialog().ok(
                    'Leider falsch!',
                    'Richtige Reihenfolge: {}\n\nDu nimmst {} mit.'.format(correct_label, prize))
                self.close()
                return

            if self._level >= 14:
                self._correct_answers += 1
                self._submit_highscore('1.000.000 €')
                xbmcgui.Dialog().ok('Gewonnen!',
                                     'Herzlichen Glückwunsch!\n1.000.000 Euro!')
                self.close()
                return

            self.lbl_status.setLabel(
                '[COLOR {}]Richtige Reihenfolge![/COLOR]'.format(COL_GREEN))
            xbmc.sleep(2000)
            self._correct_answers += 1
            self._is_sort = False
            self._load_next(next_data)
        else:
            self._update_sort_buttons()
            self._locked = False

    def _resolve_label(self, ra):
        if not ra:
            return '?'
        ra_str = str(ra).strip()
        if len(ra_str) > 1 and ra_str.isdigit():
            parts = []
            for ch in ra_str:
                idx = int(ch) - 1
                if 0 <= idx < len(self._answers):
                    parts.append('{}: {}'.format(ANSWER_LABELS[idx],
                                                 self._answers[idx]))
                else:
                    parts.append(ch)
            return ' >> '.join(parts)
        try:
            idx = int(ra_str) - 1
            if 0 <= idx < len(self._answers):
                return '{}: {}'.format(ANSWER_LABELS[idx], self._answers[idx])
        except (ValueError, TypeError):
            pass
        return ra_str

    def _update_score(self, result):
        raw = result.get('serverScore') or result.get('score') or result.get('bonus')
        if raw is not None:
            try:
                self._score = int(raw)
            except (ValueError, TypeError):
                pass
        try:
            self.lbl_score.setLabel(
                '[B][COLOR {}]{:,}[/COLOR][/B]'.format(COL_GOLD, self._score).replace(',', '.'))
        except Exception:
            pass

    def _submit_highscore(self, prize=None):
        use_account = _ADDON.getSetting('use_account') == 'true'
        if use_account:
            return
        prize_str = prize or _quit_prize(self._level)
        nick = (self._session.get('nickname') or
                self._session.get('nick') or
                _ADDON.getSetting('nickname') or '').strip()
        if not nick or nick == '@':
            return
        score = self._score
        effective = self._level if self._level > 0 else self._correct_answers
        if score <= 0 and effective > 0:
            score = MONEY_VALUES[min(effective - 1, 14)]
        try:
            from resources.lib import highscore as _hs
            _hs.submit(nick, score, self._level, prize_str)
        except Exception:
            pass

    def _start_timer(self, seconds=30):
        self._stop_timer()
        self._timer_active = True
        self._timer_secs   = seconds

        def _run():
            remaining = seconds
            while remaining >= 0 and self._timer_active:
                color = COL_GOLD if remaining > 10 else COL_RED
                try:
                    self.lbl_timer.setLabel(
                        '[COLOR {}][{:02d}][/COLOR]'.format(color, remaining))
                except Exception:
                    break
                if remaining == 0:
                    if self._timer_active:
                        self._timer_active = False
                        self._on_timeout()
                    break
                time.sleep(1)
                remaining -= 1

        self._timer_thread = threading.Thread(target=_run)
        self._timer_thread.daemon = True
        self._timer_thread.start()

    def _stop_timer(self):
        self._timer_active = False
        try:
            self.lbl_timer.setLabel('')
        except Exception:
            pass

    def _on_timeout(self):
        if self._locked:
            return
        self._lock_buttons()
        try:
            import xbmc
            xbmc.sleep(500)
        except Exception:
            pass
        prize = _safe_prize(self._level)
        self._submit_highscore(prize)
        try:
            import xbmcgui
            xbmcgui.Dialog().ok(
                'Zeit abgelaufen!',
                'Du hast zu lange gebraucht.\n\nDu nimmst {} mit.'.format(prize))
        except Exception:
            pass
        self.close()

    def _lock_buttons(self):
        self._stop_timer()
        self._locked = True
        for btn in self.btn_answers:
            btn.setEnabled(False)
        self.btn_quit.setEnabled(False)

    def _load_next(self, next_data):
        if next_data and isinstance(next_data, dict):
            self._process_question(next_data, advance_level=True)
            return
        self.lbl_status.setLabel(
            '[COLOR {}]Lade nächste Frage...[/COLOR]'.format(COL_GRAY))
        try:
            s    = self._session
            data = self._client.resume_session(
                s['userId'], s['nick'], self._lib_id, s['sessionId'])
            self._process_question(data, advance_level=True)
        except WWMError as e:
            xbmcgui.Dialog().ok('Fehler', str(e))
            self.close()

    def _process_question(self, data, advance_level=False):
        question, answers, level, is_sort, ra = _parse_question(data)
        if advance_level and 'level' not in data:
            level = min(self._level + 1, 14)
        if not question or len(answers) < 2:
            prize = _quit_prize(self._level)
            self._submit_highscore(prize)
            xbmcgui.Dialog().ok('Spiel beendet',
                                 'Du hast {} gewonnen!'.format(prize))
            self.close()
            return
        if is_sort:
            self._start_sort(question, answers, level, ra=ra)
        else:
            self._is_sort = False
            self._show_question(question, answers, level)


_SORT_PREFIXES = (
    'Ordnen Sie', 'Bringen Sie', 'Bilden Sie', 'Sortieren Sie',
    'Stellen Sie', 'Nennen Sie der Reihe', 'Reihen Sie',
    'Nummerieren Sie', 'In welcher Reihenfolge',
    'Werfen Sie', 'Ordern Sie', 'Stimmen Sie', 'Tippen Sie',
    'Schreiben Sie', 'Sagen Sie', 'Sprechen Sie', 'Zaehlen Sie',
    'Ergaenzen Sie', 'Vervollstaendigen Sie', 'Kreuzen Sie',
)

_SORT_VERBS = (
    'ordnen', 'bringen', 'bilden', 'sortieren', 'stellen', 'reihen',
    'nummerieren', 'werfen', 'ordern', 'stimmen', 'tippen',
    'schreiben', 'sagen', 'sprechen', 'zaehlen', 'ergaenzen',
    'vervollstaendigen',
)


def _parse_question(data):
    if 'tasks' in data and isinstance(data['tasks'], list) and data['tasks']:
        task = data['tasks'][0]
        data = {
            'q':     task.get('question', data.get('q', '')),
            'a1':    task.get('answer1',  task.get('a1')),
            'a2':    task.get('answer2',  task.get('a2')),
            'a3':    task.get('answer3',  task.get('a3')),
            'a4':    task.get('answer4',  task.get('a4')),
            'ra':    task.get('ra',       data.get('ra', '')),
            'level': task.get('level',    data.get('level', 0)),
            **{k: v for k, v in data.items() if k not in ('tasks', 'q', 'a1','a2','a3','a4','ra','level')},
        }

    question = data.get('q') or data.get('question', '')
    answers  = []
    for key in ['a1', 'a2', 'a3', 'a4']:
        v = data.get(key)
        if v is not None:
            answers.append(str(v))
    if not answers:
        for key in ['a', 'b', 'c', 'd']:
            v = data.get(key)
            if v is not None:
                answers.append(str(v))
    level = int(data.get('level', 0))

    _qtype = str(data.get('qType', data.get('questionType',
                 data.get('type', '')))).lower()
    _by_api = bool(
        data.get('sortQuestion') or data.get('sort') or
        data.get('isSortQuestion') or data.get('is_sort') or
        _qtype in ('sort', 'sorting', 'order', 'reihenfolge'))

    _by_breakconfig = data.get('breakConfig') not in (None, '', False)

    _is_first = ('level' in data) and (level == 0)
    is_sort = _by_api or _by_breakconfig or _is_first

    ra = str(data.get('ra', '')).strip()
    return question, answers, level, is_sort, ra
