import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
from urllib.parse import parse_qsl, urlencode

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from resources.lib.game import Game
import resources.lib.session as session_store

_ADDON    = xbmcaddon.Addon()
_DLG      = xbmcgui.Dialog()
_HANDLE   = int(sys.argv[1]) if len(sys.argv) > 1 else -1
_BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ''


def _build_url(action, **kwargs):
    kwargs['action'] = action
    return '{}?{}'.format(_BASE_URL, urlencode(kwargs))


def show_main_menu():
    _ADDON_PATH = _ADDON.getAddonInfo('path')
    _FANART     = os.path.join(_ADDON_PATH, 'fanart.jpg')
    _ICON       = os.path.join(_ADDON_PATH, 'icon.png')

    _ADDON_DESC = (
        'Wer wird Millionär? ist Deutschlands bekannteste Quizshow, '
        'moderiert von Günther Jauch. Beantworte 15 Fragen mit steigendem '
        'Schwierigkeitsgrad und gewinne bis zu eine Million Euro! '
        'Als Hilfe stehen Publikumsjoker, Telefonjoker und 50:50-Joker bereit. '
        'Trainiere hier mit echten Sendungsfragen, vergleiche deine Highscores '
        'und teste dein Wissen – direkt vom Sofa aus.'
    )

    _ITEM_DESCRIPTIONS = {
        'play':       'Starte eine neue Spielrunde mit echten WWM-Fragen.',
        'highscores': 'Zeige die besten Ergebnisse der Woche, des Tages oder des Monats an.',
        'register':   'Erstelle ein neues Konto, um deine Ergebnisse zu speichern.',
        'settings':   'Passe die Addon-Einstellungen an.',
        'logout':     'Lösche die aktuelle Session und melde dich ab.',
    }

    items = [
        ('Neues Spiel starten',          'play'),
        ('Highscores anzeigen',          'highscores'),
        ('Konto registrieren',           'register'),
        ('Einstellungen',                'settings'),
        ('Abmelden (Session löschen)',   'logout'),
    ]
    for label, action in items:
        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'false')
        li.setArt({
            'icon':   _ICON,
            'thumb':  _ICON,
            'fanart': _FANART,
        })
        li.setInfo('video', {
            'title':   label,
            'plot':    _ITEM_DESCRIPTIONS.get(action, _ADDON_DESC),
            'plotoutline': _ADDON_DESC,
            'studio':  'Grundy UFA / RTL',
            'genre':   'Quiz / Spielshow',
        })
        xbmcplugin.addDirectoryItem(
            handle=_HANDLE,
            url=_build_url(action),
            listitem=li,
            isFolder=(action != 'play'),
        )
    xbmcplugin.endOfDirectory(_HANDLE)


def show_highscores():
    from resources.lib.api import WWMClient, WWMError
    from resources.lib import highscore as _hs

    periods     = ['Diese Woche', 'Heute', 'Diesen Monat', 'Alle Zeiten']
    period_keys = ['week', 'day', 'month', 'all']
    idx = _DLG.select('Highscores – Zeitraum', periods)
    if idx < 0:
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    entries = _hs.get_scores(period=period_keys[idx])
    if not entries:
        _DLG.ok('Highscores', 'Keine Einträge gefunden.')
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)
        return
    lines = []
    for e in entries[:50]:
        rank  = e.get('rank', '?')
        nick  = e.get('nickname', '?')
        score = e.get('score', 0)
        prize = e.get('prize', '')
        lines.append('{}. {}  –  {:,}  ({})'.format(
            rank, nick, score, prize).replace(',', '.'))
    _DLG.textviewer('Highscores – {}'.format(periods[idx]), '\n'.join(lines))
    xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)


def main():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action', '')

    if action == 'play':
        game = Game()
        game.run()
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)

    elif action == 'register':
        game = Game()
        game._register_new_account()
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)

    elif action == 'highscores':
        show_highscores()

    elif action == 'settings':
        _ADDON.openSettings()
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)

    elif action == 'logout':
        if _DLG.yesno('Abmelden', 'Session wirklich löschen?'):
            session_store.clear()
            xbmcgui.Dialog().notification('WWM', 'Session gelöscht.',
                                          xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(_HANDLE, succeeded=False)

    else:
        show_main_menu()


if __name__ == '__main__':
    main()
