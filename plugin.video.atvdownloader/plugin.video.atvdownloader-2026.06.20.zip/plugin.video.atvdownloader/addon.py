import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import urlencode, parse_qs, quote, unquote
import json

ADDON       = xbmcaddon.Addon()
ADDON_ID    = ADDON.getAddonInfo('id')
ADDON_NAME  = ADDON.getAddonInfo('name')
ADDON_PATH  = ADDON.getAddonInfo('path')
sys.path.insert(0, os.path.join(ADDON_PATH, 'resources', 'lib'))
ADDON_ICON  = os.path.join(ADDON_PATH, 'icon.png')
ADDON_FANART= os.path.join(ADDON_PATH, 'fanart.jpg')

HANDLE      = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL    = sys.argv[0]
ARGS        = parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}

BOOKMARKS_FILE = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/' + ADDON_ID + '/'), 'bookmarks.json')

HISTORY_FILE = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/' + ADDON_ID + '/'), 'history.json')

AFTVNEWS_BASE = 'https://go.aftvnews.com/'


def get_setting(key, default=''):
    val = ADDON.getSetting(key)
    return val if val else default


def get_bool_setting(key, default=False):
    val = ADDON.getSetting(key)
    if val == '':
        return default
    return val.lower() == 'true'


def get_kodi_major_version():
    try:
        import re
        build = xbmc.getInfoLabel('System.BuildVersion')
        m = re.match(r'\s*(\d+)', build)
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return 0


def build_url(params):
    return BASE_URL + '?' + urlencode(params)


def load_bookmarks():
    if not xbmcvfs.exists(BOOKMARKS_FILE):
        return []
    try:
        with xbmcvfs.File(BOOKMARKS_FILE, 'r') as f:
            return json.loads(f.read()) or []
    except Exception:
        return []


def save_bookmarks(bookmarks):
    folder = os.path.dirname(BOOKMARKS_FILE)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    with xbmcvfs.File(BOOKMARKS_FILE, 'w') as f:
        f.write(json.dumps(bookmarks, indent=2))


def add_bookmark(name, url):
    bookmarks = load_bookmarks()
    for b in bookmarks:
        if b.get('url') == url:
            return
    bookmarks.append({'name': name, 'url': url})
    save_bookmarks(bookmarks)
    xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32032), ADDON_ICON, 2000)


def remove_bookmark(url):
    bookmarks = [b for b in load_bookmarks() if b.get('url') != url]
    save_bookmarks(bookmarks)
    xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32033), ADDON_ICON, 2000)


def move_bookmark(url, direction):
    bookmarks = load_bookmarks()
    idx = next((i for i, b in enumerate(bookmarks) if b.get('url') == url), None)
    if idx is None:
        return
    if direction == 'up' and idx > 0:
        bookmarks[idx - 1], bookmarks[idx] = bookmarks[idx], bookmarks[idx - 1]
    elif direction == 'down' and idx < len(bookmarks) - 1:
        bookmarks[idx + 1], bookmarks[idx] = bookmarks[idx], bookmarks[idx + 1]
    else:
        return
    save_bookmarks(bookmarks)


def rename_bookmark(url):
    bookmarks = load_bookmarks()
    idx = next((i for i, b in enumerate(bookmarks) if b.get('url') == url), None)
    if idx is None:
        return
    current  = bookmarks[idx].get('name', '')
    new_name = xbmcgui.Dialog().input(ADDON.getLocalizedString(32045), current)
    if not new_name:
        return
    bookmarks[idx]['name'] = new_name.strip()
    save_bookmarks(bookmarks)


def get_download_folder():
    folder = get_setting('downloadfolder', 'special://home/downloads/')
    path   = xbmcvfs.translatePath(folder)
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def get_video_folder():
    base = get_setting('downloadfolder', 'special://home/downloads/')
    if not base.endswith('/'):
        base += '/'
    video_special = base + 'Videos/'
    path = xbmcvfs.translatePath(video_special)
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path, video_special



    try:
        build = xbmc.getInfoLabel('System.BuildVersion')
        return int(build.split('.')[0].split(' ')[0])
    except Exception:
        return 0


VIDEO_EXTS = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.ts', '.m4v', '.mpg', '.mpeg', '.webm')


def _is_video_file(filename):
    return os.path.splitext(filename)[1].lower() in VIDEO_EXTS


def _get_video_sources():
    raw = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Files.GetSources","params":{"media":"video"},"id":1}')
    try:
        data = json.loads(raw)
        return data.get('result', {}).get('sources', [])
    except Exception:
        return []


def _folder_is_video_source(folder):
    folder = xbmcvfs.translatePath(folder).rstrip('/\\') + '/'
    for src in _get_video_sources():
        src_path = xbmcvfs.translatePath(src.get('file', '')).rstrip('/\\') + '/'
        if folder.startswith(src_path) or src_path.startswith(folder):
            return True
    return False


def _add_video_source(folder):
    label = ADDON.getLocalizedString(32065)
    payload = json.dumps({
        'jsonrpc': '2.0',
        'method': 'Files.AddSource',
        'params': {
            'media': 'video',
            'source': {
                'label': label,
                'paths': [folder]
            }
        },
        'id': 1
    })
    result = xbmc.executeJSONRPC(payload)
    try:
        data = json.loads(result)
        return 'result' in data and data['result'] == 'OK'
    except Exception:
        return False


def _add_video_source_xml(folder, label):
    import xml.etree.ElementTree as ET
    sources_path = xbmcvfs.translatePath('special://userdata/sources.xml')

    if xbmcvfs.exists(sources_path):
        with xbmcvfs.File(sources_path, 'r') as f:
            content = f.read()
        try:
            root = ET.fromstring(content)
        except Exception:
            return False
    else:
        root = ET.Element('sources')

    video_el = root.find('video')
    if video_el is None:
        video_el = ET.SubElement(root, 'video')

    for src in video_el.findall('source'):
        for path_el in src.findall('path'):
            if path_el.text and path_el.text.rstrip('/\\') == folder.rstrip('/\\'):
                return True

    src_el = ET.SubElement(video_el, 'source')
    name_el = ET.SubElement(src_el, 'name')
    name_el.text = label
    path_el = ET.SubElement(src_el, 'path')
    path_el.text = folder
    path_el.set('pathversion', '1')
    allow_el = ET.SubElement(src_el, 'allowsharing')
    allow_el.text = 'true'

    try:
        xml_str = ET.tostring(root, encoding='unicode')
        with xbmcvfs.File(sources_path, 'w') as f:
            f.write('<?xml version="1.0" encoding="utf-8"?>\n' + xml_str)
        return True
    except Exception:
        return False


def offer_library_add(dest):
    _video_path, video_special = get_video_folder()

    if not xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32061)):
        return

    if not _folder_is_video_source(video_special):
        label = ADDON.getLocalizedString(32065)
        _add_video_source_xml(video_special, label)

    translated = xbmcvfs.translatePath(video_special)
    xbmc.executebuiltin('UpdateLibrary(video,' + translated + ')')
    xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32062), ADDON_ICON, 3000)


_BACKUP_KEY = b'DLoaderATV2024xK'


def _xor_bytes(data, key):
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))


def _encode_payload(text):
    import base64
    raw = text.encode('utf-8')
    enc = _xor_bytes(raw, _BACKUP_KEY)
    return base64.b64encode(enc).decode('ascii')


def _decode_payload(text):
    import base64
    enc = base64.b64decode(text.encode('ascii'))
    raw = _xor_bytes(enc, _BACKUP_KEY)
    return raw.decode('utf-8')


def _pick_backup_path(mode='save'):
    dialog = xbmcgui.Dialog()
    choice = dialog.select(
        ADDON.getLocalizedString(32080),
        [ADDON.getLocalizedString(32081), ADDON.getLocalizedString(32082)]
    )
    if choice < 0:
        return None

    if choice == 0:
        if mode == 'save':
            folder = dialog.browse(3, ADDON.getLocalizedString(32083), 'files')
            if not folder:
                return None
            return os.path.join(xbmcvfs.translatePath(folder), 'downloader_backup.dvbak')
        else:
            path = dialog.browse(1, ADDON.getLocalizedString(32084), 'files', '.dvbak')
            return xbmcvfs.translatePath(path) if path else None
    else:
        default = ''
        if mode == 'save':
            default = xbmcvfs.translatePath('special://home/downloads/downloader_backup.dvbak')
        entered = dialog.input(ADDON.getLocalizedString(32085), default, type=xbmcgui.INPUT_ALPHANUM)
        return entered.strip() if entered else None


def create_backup():
    import zipfile, io
    path = _pick_backup_path('save')
    if not path:
        return

    bm_data = ''
    if xbmcvfs.exists(BOOKMARKS_FILE):
        with xbmcvfs.File(BOOKMARKS_FILE, 'r') as f:
            bm_data = f.read()

    hi_data = ''
    if xbmcvfs.exists(HISTORY_FILE):
        with xbmcvfs.File(HISTORY_FILE, 'r') as f:
            hi_data = f.read()

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('bm.dat', _encode_payload(bm_data or '[]'))
        zf.writestr('hi.dat', _encode_payload(hi_data or '[]'))

    translated = xbmcvfs.translatePath(path) if path.startswith('special://') else path
    folder = os.path.dirname(translated)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)

    with xbmcvfs.File(translated, 'w') as f:
        f.write(buf.getvalue().decode('latin-1'))

    ADDON.setSetting('backup_path_display', translated)
    xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32086) + ': ' + translated)


def restore_backup():
    import zipfile, io
    path = _pick_backup_path('load')
    if not path:
        return

    translated = xbmcvfs.translatePath(path) if path.startswith('special://') else path

    if not xbmcvfs.exists(translated):
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32087))
        return

    try:
        with xbmcvfs.File(translated, 'r') as f:
            raw = f.read()

        buf = io.BytesIO(raw.encode('latin-1'))
        with zipfile.ZipFile(buf, 'r') as zf:
            names = zf.namelist()
            bm_enc = zf.read('bm.dat').decode('ascii') if 'bm.dat' in names else None
            hi_enc = zf.read('hi.dat').decode('ascii') if 'hi.dat' in names else None

        folder = os.path.dirname(BOOKMARKS_FILE)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)

        if bm_enc is not None:
            with xbmcvfs.File(BOOKMARKS_FILE, 'w') as f:
                f.write(_decode_payload(bm_enc))

        if hi_enc is not None:
            with xbmcvfs.File(HISTORY_FILE, 'w') as f:
                f.write(_decode_payload(hi_enc))

        ADDON.setSetting('backup_path_display', translated)
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32088))

    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32089) + ': ' + str(e))


def _sync_folder_display():
    val = get_setting('downloadfolder', 'special://home/downloads/')
    ADDON.setSetting('downloadfolder_display', val)


def pick_download_folder():
    dialog = xbmcgui.Dialog()
    current = get_setting('downloadfolder', 'special://home/downloads/')
    choice = dialog.select(
        ADDON.getLocalizedString(32001),
        [ADDON.getLocalizedString(32081), ADDON.getLocalizedString(32082)]
    )
    if choice < 0:
        return
    if choice == 0:
        folder = dialog.browse(3, ADDON.getLocalizedString(32001), 'files', '', False, False, current)
        if folder:
            ADDON.setSetting('downloadfolder', folder)
            _sync_folder_display()
    else:
        entered = dialog.input(ADDON.getLocalizedString(32001), current, type=xbmcgui.INPUT_ALPHANUM)
        if entered:
            ADDON.setSetting('downloadfolder', entered.strip())
            _sync_folder_display()



def _is_supported_kodi_build():
    """Return True if this Kodi build supports APK install via StartAndroidActivity."""
    try:
        import xbmcvfs
        profile = xbmcvfs.translatePath('special://masterprofile/')
        for pkg in ('kmedia', 'kodi.dev', 'leiamod'):
            if pkg in profile.lower():
                return True
    except Exception:
        pass
    try:
        friendly = xbmc.getInfoLabel('System.FriendlyName')
        if 'kmedia' in friendly.lower():
            return True
    except Exception:
        pass
    return False


def install_apk(path):
    kodi_ver = get_kodi_major_version()
    if kodi_ver < 22:
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32060))
        return
    if kodi_ver == 22 and not _is_supported_kodi_build():
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32060))
        return
    xbmc.executebuiltin(
        'StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","' + path + '")'
    )

def install_zip_addon(path):
    import zipfile
    addons_dir = xbmcvfs.translatePath('special://home/addons/')

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, ADDON.getLocalizedString(32055))

    try:
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
            if not any(n.endswith('/addon.xml') for n in names):
                dialog.close()
                xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32054), ADDON_ICON, 4000)
                return

            addon_ids = sorted(set(n.split('/')[0] for n in names if n.strip('/')))
            total = len(names) or 1

            for i, member in enumerate(names):
                if dialog.iscanceled():
                    dialog.close()
                    return
                zf.extract(member, addons_dir)
                pct = int((i + 1) * 100 / total)
                dialog.update(pct, member)

        dialog.update(100, ADDON.getLocalizedString(32056))
        xbmc.executebuiltin('UpdateLocalAddons')
        for addon_id in addon_ids:
            xbmc.executebuiltin('EnableAddon(' + addon_id + ')')

        dialog.close()
        xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32053), ADDON_ICON, 3000)
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32038) + ': ' + str(e), ADDON_ICON, 4000)



def _title_from_url(url):
    name = url.rstrip('/').split('/')[-1].split('?')[0]
    return name if name else url


def load_history():
    if not xbmcvfs.exists(HISTORY_FILE):
        return []
    try:
        with xbmcvfs.File(HISTORY_FILE, 'r') as f:
            return json.loads(f.read()) or []
    except Exception:
        return []


def _save_history(history):
    folder = os.path.dirname(HISTORY_FILE)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    with xbmcvfs.File(HISTORY_FILE, 'w') as f:
        f.write(json.dumps(history, indent=2))


def add_history(url):
    import time
    history = load_history()
    history = [h for h in history if h.get('url') != url]
    history.insert(0, {'url': url, 'title': _title_from_url(url), 'ts': int(time.time())})
    _save_history(history)


def remove_history_entry(url):
    history = [h for h in load_history() if h.get('url') != url]
    _save_history(history)


def clear_history():
    _save_history([])


def list_history():
    xbmcplugin.setPluginCategory(HANDLE, ADDON.getLocalizedString(32070))
    xbmcplugin.setContent(HANDLE, 'files')

    history = load_history()

    if not history:
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32072))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for h in history:
        url   = h.get('url', '')
        title = h.get('title') or _title_from_url(url)
        li    = xbmcgui.ListItem(title)
        li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART, 'thumb': ADDON_ICON})
        li.setInfo('video', {'title': title, 'plot': url})
        li.setProperty('IsPlayable', 'false')

        context = [
            (ADDON.getLocalizedString(32020), 'RunPlugin(' + build_url({'mode': 'browser', 'url': url}) + ')'),
            (ADDON.getLocalizedString(32031), 'RunPlugin(' + build_url({'mode': 'bookmark_from_history', 'url': quote(url)}) + ')'),
            (ADDON.getLocalizedString(32044), 'RunPlugin(' + build_url({'mode': 'del_history', 'url': quote(url)}) + ')'),
            (ADDON.getLocalizedString(32071), 'RunPlugin(' + build_url({'mode': 'clear_history'}) + ')'),
        ]
        li.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'url_menu', 'url': quote(url)}), li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)

def list_main_menu():
    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    xbmcplugin.setContent(HANDLE, 'files')

    home_url = get_setting('home_url', 'https://google.com')

    code_label = '[B]' + ADDON.getLocalizedString(32046) + '[/B]'
    entries = [
        (code_label,                        {'mode': 'download_code'}),
        (ADDON.getLocalizedString(32020),   {'mode': 'browser',     'url': home_url}),
        (ADDON.getLocalizedString(32070),   {'mode': 'history'}),
        (ADDON.getLocalizedString(32022),   {'mode': 'bookmarks'}),
        (ADDON.getLocalizedString(32021),   {'mode': 'downloads'}),
        ('Code erzeugen',                   {'mode': 'generate_code'}),
    ]

    for label, params in entries:
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART, 'thumb': ADDON_ICON})
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(HANDLE, build_url(params), li, isFolder=True)

    li_settings = xbmcgui.ListItem(ADDON.getLocalizedString(32023))
    li_settings.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'settings'}), li_settings, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def _resolve_aftvnews_url(short_url):
    import urllib.request, re, html
    useragent = get_setting('useragent', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36')
    req = urllib.request.Request(short_url, headers={'User-Agent': useragent})
    with urllib.request.urlopen(req, timeout=15) as resp:
        body = resp.read(32768).decode('utf-8', errors='ignore')
    m = re.search(r'href="(https?://[^"<>\s]+)', body) or re.search(r"href='(https?://[^'<>\s]+)'", body) or re.search(r'href=(https?://[^<>\s"]+)', body)
    if m:
        url = m.group(1)
        return html.unescape(url) if url else None
    return None


def generate_code():
    dialog = xbmcgui.Dialog()

    lang = xbmc.getLanguage(xbmc.ISO_639_1)
    if lang == 'de':
        info = (
            'So funktioniert es:\n\n'
            '1. Browser oeffnet go.aftvnews.com\n'
            '2. URL ins Feld eintippen\n'
            '3. Captcha loesen\n'
            '4. Code notieren und zurueck zu Kodi\n'
            '5. Code hier eingeben'
        )
    else:
        info = (
            'How it works:\n\n'
            '1. Browser opens go.aftvnews.com\n'
            '2. Type your URL into the field\n'
            '3. Solve the captcha\n'
            '4. Note the code and return to Kodi\n'
            '5. Enter the code here'
        )

    if not dialog.ok(ADDON_NAME + ' - Code erzeugen / Generate Code', info):
        return

    xbmc.executebuiltin('StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","https://go.aftvnews.com/")')

    xbmc.sleep(2000)
    code = dialog.input('Code aus Browser eingeben', '', type=xbmcgui.INPUT_ALPHANUM)
    if not code:
        return
    code = code.strip()
    if code.isdigit():
        short_url = AFTVNEWS_BASE + code
        resolved = _resolve_aftvnews_url(short_url)
        if resolved:
            add_history(resolved)
            _show_url_menu(resolved)
        else:
            dialog.notification(ADDON_NAME, ADDON.getLocalizedString(32049), ADDON_ICON, 3000)
    else:
        add_history(code)
        _show_url_menu(code)


def download_with_code():
    dialog  = xbmcgui.Dialog()
    entered = dialog.input(ADDON.getLocalizedString(32047), '', type=xbmcgui.INPUT_ALPHANUM)
    if not entered:
        return

    entered = entered.strip()

    if entered.startswith(('http://', 'https://')):
        url = entered
    elif entered.isdigit():
        short_url = AFTVNEWS_BASE + entered
        url = _resolve_aftvnews_url(short_url)
        if not url:
            xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32049), ADDON_ICON, 3000)
            return
    else:
        url = 'https://' + entered

    add_history(url)
    _show_url_menu(url)

def list_bookmarks():
    xbmcplugin.setPluginCategory(HANDLE, ADDON.getLocalizedString(32022))
    xbmcplugin.setContent(HANDLE, 'files')

    bookmarks = load_bookmarks()

    if not bookmarks:
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32040))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    last_idx = len(bookmarks) - 1

    for i, b in enumerate(bookmarks):
        url_raw = b.get('url', '')
        name = b.get('name') or url_raw.rstrip('/').split('/')[-1].split('?')[0] or url_raw
        url  = b.get('url', '')
        li   = xbmcgui.ListItem(name)
        li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART, 'thumb': ADDON_ICON})
        li.setInfo('video', {'title': name, 'plot': url})
        li.setProperty('IsPlayable', 'false')

        context = [
            (ADDON.getLocalizedString(32020), 'RunPlugin(' + build_url({'mode': 'browser', 'url': url}) + ')'),
            (ADDON.getLocalizedString(32045), 'RunPlugin(' + build_url({'mode': 'rename_bookmark', 'url': quote(url)}) + ')'),
        ]
        if i > 0:
            context.append((ADDON.getLocalizedString(32051), 'RunPlugin(' + build_url({'mode': 'move_bookmark', 'url': quote(url), 'dir': 'up'}) + ')'))
        if i < last_idx:
            context.append((ADDON.getLocalizedString(32052), 'RunPlugin(' + build_url({'mode': 'move_bookmark', 'url': quote(url), 'dir': 'down'}) + ')'))
        context.append((ADDON.getLocalizedString(32044), 'RunPlugin(' + build_url({'mode': 'del_bookmark', 'url': quote(url)}) + ')'))

        li.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'browser', 'url': url}), li, isFolder=True)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def list_downloads():
    xbmcplugin.setPluginCategory(HANDLE, ADDON.getLocalizedString(32021))
    xbmcplugin.setContent(HANDLE, 'files')

    folder = get_download_folder()
    dirs, files = xbmcvfs.listdir(folder)

    if not files and not dirs:
        xbmcgui.Dialog().ok(ADDON_NAME, ADDON.getLocalizedString(32039))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for subdir in sorted(dirs):
        li = xbmcgui.ListItem('[DIR] ' + subdir)
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': ADDON_FANART})
        sub_path = os.path.join(folder, subdir)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'browse_folder', 'path': quote(sub_path)}), li, isFolder=True)

    video_exts = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.ts', '.m3u8', '.m4v', '.mpg', '.mpeg', '.webm')
    audio_exts = ('.mp3', '.aac', '.flac', '.ogg', '.wav', '.m4a')

    for fname in sorted(files):
        full_path = os.path.join(folder, fname)
        ext = os.path.splitext(fname)[1].lower()
        is_video = ext in video_exts
        is_audio = ext in audio_exts
        is_media = is_video or is_audio

        is_zip = ext == '.zip'
        is_apk = ext == '.apk'

        li = xbmcgui.ListItem(fname)
        li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART, 'thumb': ADDON_ICON})

        context = []
        if is_media:
            li.setProperty('IsPlayable', 'true')
            if is_video:
                li.setInfo('video', {'title': fname})
            else:
                li.setInfo('music', {'title': fname})
            context.append((ADDON.getLocalizedString(32041), 'PlayMedia(' + full_path + ')'))
        elif is_zip:
            context.append((ADDON.getLocalizedString(32058), 'RunPlugin(' + build_url({'mode': 'install_zip', 'path': quote(full_path)}) + ')'))
        elif is_apk:
            context.append((ADDON.getLocalizedString(32058), 'RunPlugin(' + build_url({'mode': 'install_apk', 'path': quote(full_path)}) + ')'))

        context.append((ADDON.getLocalizedString(32044), 'RunPlugin(' + build_url({'mode': 'del_file', 'path': quote(full_path)}) + ')'))
        li.addContextMenuItems(context)

        if is_media:
            target_url = full_path
        elif is_zip:
            target_url = build_url({'mode': 'install_zip', 'path': quote(full_path)})
        elif is_apk:
            target_url = build_url({'mode': 'install_apk', 'path': quote(full_path)})
        else:
            target_url = build_url({'mode': 'noop'})
        xbmcplugin.addDirectoryItem(HANDLE, target_url, li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


def browse_folder(path):
    path = unquote(path)
    xbmcplugin.setPluginCategory(HANDLE, os.path.basename(path))
    xbmcplugin.setContent(HANDLE, 'files')

    dirs, files = xbmcvfs.listdir(path)
    video_exts = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.ts', '.m3u8', '.m4v', '.mpg', '.mpeg', '.webm')
    audio_exts = ('.mp3', '.aac', '.flac', '.ogg', '.wav', '.m4a')

    for subdir in sorted(dirs):
        li = xbmcgui.ListItem('[DIR] ' + subdir)
        li.setArt({'icon': 'DefaultFolder.png', 'fanart': ADDON_FANART})
        sub_path = os.path.join(path, subdir)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'browse_folder', 'path': quote(sub_path)}), li, isFolder=True)

    for fname in sorted(files):
        full_path = os.path.join(path, fname)
        ext = os.path.splitext(fname)[1].lower()
        is_media = ext in video_exts or ext in audio_exts
        is_zip = ext == '.zip'
        is_apk = ext == '.apk'

        li = xbmcgui.ListItem(fname)
        li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART})
        context = [
            (ADDON.getLocalizedString(32044), 'RunPlugin(' + build_url({'mode': 'del_file', 'path': quote(full_path)}) + ')'),
        ]
        if is_zip:
            context.append((ADDON.getLocalizedString(32058), 'RunPlugin(' + build_url({'mode': 'install_zip', 'path': quote(full_path)}) + ')'))
        elif is_apk:
            context.append((ADDON.getLocalizedString(32058), 'RunPlugin(' + build_url({'mode': 'install_apk', 'path': quote(full_path)}) + ')'))
        li.addContextMenuItems(context)
        if is_media:
            li.setProperty('IsPlayable', 'true')

        if is_media:
            target_url = full_path
        elif is_zip:
            target_url = build_url({'mode': 'install_zip', 'path': quote(full_path)})
        elif is_apk:
            target_url = build_url({'mode': 'install_apk', 'path': quote(full_path)})
        else:
            target_url = build_url({'mode': 'noop'})
        xbmcplugin.addDirectoryItem(HANDLE, target_url, li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


def open_browser(url=None):
    if not url:
        url = get_setting('home_url', 'https://google.com')

    kb = xbmcgui.Dialog()
    entered = kb.input(ADDON.getLocalizedString(32030), url, type=xbmcgui.INPUT_ALPHANUM)
    if not entered:
        return

    entered = entered.strip()
    if not entered.startswith(('http://', 'https://')):
        entered = 'https://' + entered

    _handle_url(entered)


def _handle_url(url):
    add_history(url)
    video_exts = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.ts', '.m4v', '.mpg', '.mpeg', '.webm', '.mp3', '.aac', '.flac')

    if get_bool_setting('autoplay_video', True):
        ext = os.path.splitext(url.split('?')[0])[1].lower()
        if ext in video_exts or '.m3u8' in url.lower():
            _play_url(url)
            return

    _show_url_menu(url)


def _play_url(url):
    li = xbmcgui.ListItem(path=url)
    li.setProperty('inputstream.adaptive.manifest_type', 'hls' if 'm3u8' in url.lower() else '')
    xbmc.Player().play(url, li)


def _show_url_menu(url):
    dialog  = xbmcgui.Dialog()
    choices = [
        ADDON.getLocalizedString(32041),
        ADDON.getLocalizedString(32031),
        ADDON.getLocalizedString(32048),
    ]
    idx = dialog.select(url[:60] + ('...' if len(url) > 60 else ''), choices)

    if idx == 0:
        _play_url(url)
    elif idx == 1:
        default_name = url.rstrip('/').split('/')[-1].split('?')[0] or url
        name = dialog.input(ADDON.getLocalizedString(32031), default_name)
        if name:
            add_bookmark(name, url)
    elif idx == 2:
        _download_url(url)


def _filename_from_response(response, fallback_url):
    import re
    cd = response.headers.get("Content-Disposition", "")
    if cd:
        m = re.search(r'filename=["\']?([^"\';\r\n]+)["\']?', cd, re.I)
        if m:
            return unquote(m.group(1).strip())
        m = re.search(r'filename=["\'\']?([^"\'\';\r\n]+)["\'\']?', cd, re.I)
        if m:
            return m.group(1).strip().strip('"\'')
    final_url = response.geturl()
    name = final_url.split("/")[-1].split("?")[0]
    if name:
        return unquote(name)
    name = fallback_url.split("/")[-1].split("?")[0]
    return name or "download" 


def _open_in_external_browser(url):
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","",' + '"' + url + '")')


def _download_url(url):
    import urllib.request
    folder = get_download_folder()
    useragent = get_setting('useragent', 'Mozilla/5.0')

    content_type = ''
    try:
        head_req = urllib.request.Request(url, headers={'User-Agent': useragent}, method='HEAD')
        with urllib.request.urlopen(head_req, timeout=10) as head_resp:
            preview_name = _filename_from_response(head_resp, url)
            content_type = head_resp.headers.get('Content-Type', '')
    except Exception:
        preview_name = url.split('/')[-1].split('?')[0] or 'download'

    if content_type.lower().startswith('text/html'):
        if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32098)):
            _open_in_external_browser(url)
        return

    if not xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32050) + '[CR][B]' + preview_name + '[/B]'):
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, ADDON.getLocalizedString(32036))

    try:
        req = urllib.request.Request(url, headers={'User-Agent': useragent})

        with urllib.request.urlopen(req, timeout=30) as response:
            if response.headers.get('Content-Type', '').lower().startswith('text/html'):
                dialog.close()
                if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32098)):
                    _open_in_external_browser(url)
                return

            filename   = _filename_from_response(response, url)
            if _is_video_file(filename):
                video_path, video_special = get_video_folder()
                dest = os.path.join(video_path, filename)
            else:
                dest = os.path.join(folder, filename)
            total      = int(response.headers.get('Content-Length', 0))
            downloaded = 0
            chunk      = 65536
            import time
            t_start    = time.time()

            def _fmt_bytes(b):
                for unit in ('B', 'KB', 'MB', 'GB'):
                    if b < 1024:
                        return '%.1f %s' % (b, unit)
                    b /= 1024
                return '%.1f GB' % b

            with open(dest, 'wb') as f:
                while True:
                    data = response.read(chunk)
                    if not data:
                        break
                    f.write(data)
                    downloaded += len(data)
                    elapsed = time.time() - t_start or 0.001
                    speed   = downloaded / elapsed

                    if total > 0:
                        pct      = int(downloaded * 100 / total)
                        remain   = (total - downloaded) / speed if speed > 0 else 0
                        if remain >= 3600:
                            eta = '%dh %02dm' % (remain // 3600, (remain % 3600) // 60)
                        elif remain >= 60:
                            eta = '%dm %02ds' % (remain // 60, remain % 60)
                        else:
                            eta = '%ds' % int(remain)
                        line2 = '%s / %s  |  %s/s  |  %s' % (
                            _fmt_bytes(downloaded), _fmt_bytes(total),
                            _fmt_bytes(speed), eta)
                        dialog.update(pct, filename + '[CR]' + line2)
                    else:
                        line2 = '%s  |  %s/s' % (_fmt_bytes(downloaded), _fmt_bytes(speed))
                        dialog.update(0, filename + '[CR]' + line2)

                    if dialog.iscanceled():
                        break

        dialog.close()
        xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32037) + ': ' + filename, ADDON_ICON, 3000)

        if filename.lower().endswith('.apk'):
            if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32059)):
                install_apk(dest)
        elif filename.lower().endswith('.zip'):
            if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32057)):
                install_zip_addon(dest)
        elif _is_video_file(filename):
            offer_library_add(dest)

    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32038) + ': ' + str(e), ADDON_ICON, 4000)


def delete_file(path):
    path = unquote(path)
    if get_bool_setting('confirm_delete', True):
        if not xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32034) + '\n' + os.path.basename(path)):
            return
    xbmcvfs.delete(path)
    xbmcgui.Dialog().notification(ADDON_NAME, ADDON.getLocalizedString(32035), ADDON_ICON, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _run_tv_mode():
    import tv_gui
    while True:
        win = tv_gui.TVMenuWindow()
        win.doModal()
        result = win.get_result()
        del win

        if not result:
            break

        if result == 'download_code':
            download_with_code()
        elif result == 'browser':
            open_browser()
        elif result == 'generate_code':
            generate_code()
        elif result == 'bookmarks':
            tv_gui.show_tv_bookmarks(load_bookmarks(), _handle_url)
        elif result == 'history':
            tv_gui.show_tv_history(load_history(), _handle_url)
        elif result == 'downloads':
            tv_gui.show_tv_downloads(get_download_folder())
        elif result == 'settings':
            ADDON.openSettings()


def router():
    mode = ARGS.get('mode', [None])[0]

    if mode is None:
        _sync_folder_display()
        if get_bool_setting('force_tv_mode', False):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            try:
                _run_tv_mode()
            except Exception as e:
                xbmc.log('plugin.video.atvdownloader TV mode error: ' + str(e), xbmc.LOGERROR)
            return
        if get_bool_setting('autobrowse', False):
            open_browser(get_setting('home_url', 'https://google.com'))
        else:
            list_main_menu()

    elif mode == 'url_menu':
        url = unquote(ARGS.get('url', [''])[0])
        if url:
            add_history(url)
            _show_url_menu(url)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

    elif mode == 'browser':
        url = ARGS.get('url', [get_setting('home_url', 'https://google.com')])[0]
        open_browser(url)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

    elif mode == 'download_code':
        download_with_code()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

    elif mode == 'generate_code':
        generate_code()
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

    elif mode == 'bookmarks':
        list_bookmarks()

    elif mode == 'downloads':
        list_downloads()

    elif mode == 'browse_folder':
        path = ARGS.get('path', [''])[0]
        browse_folder(path)

    elif mode == 'del_bookmark':
        url = unquote(ARGS.get('url', [''])[0])
        remove_bookmark(url)
        xbmc.executebuiltin('Container.Refresh')

    elif mode == 'move_bookmark':
        url = unquote(ARGS.get('url', [''])[0])
        direction = ARGS.get('dir', [''])[0]
        move_bookmark(url, direction)
        xbmc.executebuiltin('Container.Refresh')

    elif mode == 'rename_bookmark':
        url = unquote(ARGS.get('url', [''])[0])
        rename_bookmark(url)
        xbmc.executebuiltin('Container.Refresh')

    elif mode == 'del_file':
        path = ARGS.get('path', [''])[0]
        delete_file(path)

    elif mode == 'install_zip':
        path = unquote(ARGS.get('path', [''])[0])
        if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32057)):
            install_zip_addon(path)

    elif mode == 'install_apk':
        path = unquote(ARGS.get('path', [''])[0])
        if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32059)):
            install_apk(path)

    elif mode == 'history':
        list_history()

    elif mode == 'del_history':
        url = unquote(ARGS.get('url', [''])[0])
        remove_history_entry(url)
        xbmc.executebuiltin('Container.Refresh')

    elif mode == 'clear_history':
        if xbmcgui.Dialog().yesno(ADDON_NAME, ADDON.getLocalizedString(32073)):
            clear_history()
            xbmc.executebuiltin('Container.Refresh')

    elif mode == 'bookmark_from_history':
        url = unquote(ARGS.get('url', [''])[0])
        add_bookmark(_title_from_url(url), url)

    elif mode == 'pick_download_folder':
        pick_download_folder()

    elif mode == 'sync_folder_display':
        _sync_folder_display()

    elif mode == 'backup_create':
        create_backup()

    elif mode == 'backup_restore':
        restore_backup()

    elif mode == 'settings':
        ADDON.openSettings()

    elif mode == 'noop':
        pass


if __name__ == '__main__':
    router()
