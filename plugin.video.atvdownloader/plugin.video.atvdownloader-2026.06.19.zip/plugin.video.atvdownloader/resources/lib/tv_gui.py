import sys
import os
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

_ADDON      = xbmcaddon.Addon()
_ADDON_PATH = _ADDON.getAddonInfo('path')
_ADDON_ICON = os.path.join(_ADDON_PATH, 'icon.png')
_ADDON_FANART = os.path.join(_ADDON_PATH, 'fanart.jpg')
_ADDON_NAME = _ADDON.getAddonInfo('name')

_LIB_PATH = os.path.join(_ADDON_PATH, 'resources', 'lib')
if _LIB_PATH not in sys.path:
    sys.path.insert(0, _LIB_PATH)

import pyxbmct

COL_GOLD  = '0xFFFFD700'
COL_WHITE = '0xFFFFFFFF'
COL_GRAY  = '0xFF888888'
COL_GREEN = '0xFF44DD66'
COL_RED   = '0xFFEE4444'

_TILE_SPECS = [
    ('browser',        32020),
    ('download_code',  32046),
    ('history',        32070),
    ('bookmarks',      32022),
    ('downloads',      32021),
    ('generate_code',  0),
]

_TILE_LABELS = {
    'generate_code': 'Code erzeugen',
}

_TILE_POSITIONS = [
    (12, 2), (12, 18), (12, 34),
    (47, 2), (47, 18), (47, 34),
]

_NAV = [
    (1, 2, 3, 3),
    (2, 0, 4, 4),
    (0, 1, 5, 5),
    (4, 5, 0, 0),
    (5, 3, 1, 1),
    (3, 4, 2, 2),
]


class TVMenuWindow(pyxbmct.AddonFullWindow):

    def __new__(cls, *args, **kwargs):
        return super(TVMenuWindow, cls).__new__(cls)

    def _setFrame(self, title):
        super(TVMenuWindow, self)._setFrame(title)
        self.main_bg.setImage(_ADDON_ICON)
        self.main_bg.setColorDiffuse('0x4DFFFFFF')
        self.background.setColorDiffuse('0x00000000')

    def __init__(self):
        super(TVMenuWindow, self).__init__('')
        self.setGeometry(1280, 720, 100, 50)
        self._result = None
        self._build_controls()
        self._setup_navigation()
        self._connect_events()
        try:
            self.setFocus(self._tiles[0])
        except Exception:
            pass

    def get_result(self):
        return self._result

    def _build_controls(self):
        lbl_title = pyxbmct.Label(
            '[B][COLOR {}]{}[/COLOR][/B]'.format(COL_GOLD, _ADDON_NAME),
            font='font30',
            textColor=COL_GOLD,
            alignment=pyxbmct.ALIGN_CENTER,
        )
        self.placeControl(lbl_title, 2, 8, 8, 34)

        self._tiles = []
        for (row, col), (mode, str_id) in zip(_TILE_POSITIONS, _TILE_SPECS):
            if mode in _TILE_LABELS:
                text = _TILE_LABELS[mode]
            else:
                text = _ADDON.getLocalizedString(str_id)
            label = u'[B]{}[/B]'.format(text)
            btn = pyxbmct.Button(
                label,
                textColor=COL_WHITE,
                focusedColor=COL_GOLD,
                alignment=pyxbmct.ALIGN_CENTER,
            )
            self.placeControl(btn, row, col, 30, 14)
            self._tiles.append(btn)

        self._btn_exit = pyxbmct.Button(
            u'[B]Beenden[/B]',
            textColor=COL_WHITE,
            focusedColor=COL_RED,
            alignment=pyxbmct.ALIGN_CENTER,
        )
        self.placeControl(self._btn_exit, 83, 18, 12, 14)

    def _setup_navigation(self):
        for i, (r, l, d, u) in enumerate(_NAV):
            t = self._tiles[i]
            t.controlRight(self._tiles[r])
            t.controlLeft(self._tiles[l])
            if i >= 3:
                t.controlDown(self._btn_exit)
            else:
                t.controlDown(self._tiles[d])
            t.controlUp(self._tiles[u])

        self._btn_exit.controlUp(self._tiles[4])
        self._btn_exit.controlDown(self._tiles[1])
        self._btn_exit.controlLeft(self._btn_exit)
        self._btn_exit.controlRight(self._btn_exit)

    def _on_exit(self):
        self.close()
        xbmc.executebuiltin('ActivateWindow(Home)')

    def _connect_events(self):
        self.connect(pyxbmct.ACTION_NAV_BACK,       self.close)
        self.connect(pyxbmct.ACTION_PREVIOUS_MENU,  self.close)
        for i, btn in enumerate(self._tiles):
            self.connect(btn, lambda idx=i: self._on_tile(idx))
        self.connect(self._btn_exit, self._on_exit)

    def _on_tile(self, idx):
        self._result = _TILE_SPECS[idx][0]
        self.close()


def show_tv_bookmarks(bookmarks, on_url):
    if not bookmarks:
        xbmcgui.Dialog().ok(_ADDON_NAME, _ADDON.getLocalizedString(32040))
        return

    labels = [b.get('name') or b.get('url', '?') for b in bookmarks]
    idx = xbmcgui.Dialog().select(_ADDON.getLocalizedString(32022), labels)
    if idx < 0:
        return

    url = bookmarks[idx].get('url', '')
    action = xbmcgui.Dialog().select(
        url[:60] + ('...' if len(url) > 60 else ''),
        [
            _ADDON.getLocalizedString(32020),
            _ADDON.getLocalizedString(32048),
        ],
    )
    if action >= 0:
        on_url(url)


def show_tv_history(history, on_url):
    if not history:
        xbmcgui.Dialog().ok(_ADDON_NAME, _ADDON.getLocalizedString(32072))
        return

    labels = [h.get('title') or h.get('url', '?') for h in history]
    idx = xbmcgui.Dialog().select(_ADDON.getLocalizedString(32070), labels)
    if idx < 0:
        return

    on_url(history[idx].get('url', ''))


def show_tv_downloads(folder):
    try:
        _dirs, files = xbmcvfs.listdir(folder)
    except Exception:
        files = []

    video_exts = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv',
                  '.ts', '.m3u8', '.m4v', '.mpg', '.mpeg', '.webm')
    audio_exts = ('.mp3', '.aac', '.flac', '.ogg', '.wav', '.m4a')

    entries = []
    for fname in sorted(files):
        ext = os.path.splitext(fname)[1].lower()
        is_media = ext in video_exts or ext in audio_exts
        entries.append((fname, os.path.join(folder, fname), is_media))

    if not entries:
        xbmcgui.Dialog().ok(_ADDON_NAME, _ADDON.getLocalizedString(32039))
        return

    idx = xbmcgui.Dialog().select(
        _ADDON.getLocalizedString(32021),
        [e[0] for e in entries],
    )
    if idx < 0:
        return

    fname, full_path, is_media = entries[idx]

    opts = []
    if is_media:
        opts.append(_ADDON.getLocalizedString(32041))
    opts.append(_ADDON.getLocalizedString(32044))

    action = xbmcgui.Dialog().select(fname, opts)
    if action < 0:
        return

    if is_media and action == 0:
        li = xbmcgui.ListItem(path=full_path)
        xbmc.Player().play(full_path, li)
    else:
        if xbmcgui.Dialog().yesno(
                _ADDON_NAME,
                _ADDON.getLocalizedString(32034) + '\n' + fname):
            xbmcvfs.delete(full_path)
            xbmcgui.Dialog().notification(
                _ADDON_NAME,
                _ADDON.getLocalizedString(32035),
                _ADDON_ICON, 2000,
            )
