# -*- coding: utf-8 -*-

import sys
import urllib.parse
import requests
import feedparser

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
from bs4 import BeautifulSoup

HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
ADDON_ICON = ADDON.getAddonInfo('icon')

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

CATEGORIES = {
    "Top-News": "https://www.bild.de/feed/alles.xml",
    "Politik": "https://www.bild.de/rss-feeds/rss-16725492,feed=politik.bild.html",
    "News": "https://www.bild.de/rss-feeds/rss-16725492,feed=news.bild.html",
    "Sport": "https://www.bild.de/rss-feeds/rss-16725492,feed=sport.bild.html",
    "Unterhaltung": "https://www.bild.de/rss-feeds/rss-16725492,feed=unterhaltung.bild.html",
    "Lifestyle": "https://www.bild.de/rss-feeds/rss-16725492,feed=lifestyle.bild.html",
    "Auto": "https://www.bild.de/rss-feeds/rss-16725492,feed=auto.bild.html",
    "Ratgeber": "https://www.bild.de/rss-feeds/rss-16725492,feed=ratgeber.bild.html",
}


def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)


def show_categories():
    for title, feed_url in CATEGORIES.items():
        url = build_url({
            'mode': 'list',
            'feed': feed_url,
            'title': title
        })
        li = xbmcgui.ListItem(label=title)
        li.setArt({
            'icon': 'DefaultFolder.png',
            'thumb': 'DefaultFolder.png'
        })
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)


def list_articles(feed_url):
    feed = feedparser.parse(feed_url)
    for entry in feed.entries:
        title = entry.get("title", "Ohne Titel")
        summary = entry.get("summary", "")
        link = entry.get("link", "")
        url = build_url({
            'mode': 'article',
            'title': title,
            'link': link
        })
        li = xbmcgui.ListItem(label=title)
        
        li.setArt({
            'icon': ADDON_ICON,
            'thumb': ADDON_ICON,
            'poster': ADDON_ICON,
            'fanart': ADDON_ICON
        })

        li.setInfo('video', {
            'title': title,
            'plot': summary
        })
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=url,
            listitem=li,
            isFolder=False
        )
    xbmcplugin.endOfDirectory(HANDLE)


def get_article_text(url):
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        html = response.text
        soup = BeautifulSoup(html, "html.parser")
        article_text = []
        selectors = [
            'article p',
            '.article-body p',
            '.txt p',
            '.post-content p',
            '[data-key="article"] p'
        ]
        for selector in selectors:
            paragraphs = soup.select(selector)
            if paragraphs:
                for p in paragraphs:
                    text = p.get_text(" ", strip=True)
                    if len(text) > 40:
                        article_text.append(text)
                if article_text:
                    break
        if not article_text:
            return "Kein Artikeltext gefunden."
        cleaned = []
        for line in article_text:
            if line not in cleaned:
                cleaned.append(line)
        return "\n\n".join(cleaned)
    except Exception as e:
        return f"Fehler beim Laden:\n{str(e)}"


def show_article(title, url):
    text = get_article_text(url)
    xbmcgui.Dialog().textviewer(
        title,
        text
    )


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    if mode is None:
        show_categories()
    elif mode == 'list':
        feed = params.get('feed')
        list_articles(feed)
    elif mode == 'article':
        title = params.get('title', 'Artikel')
        link = params.get('link', '')        
        raw_link = urllib.parse.unquote(link)        
        show_article(title, raw_link)


if __name__ == '__main__':
    router(sys.argv[2][1:])
