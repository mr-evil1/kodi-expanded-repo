# -*- coding: utf-8 -*-
# Bild.de News
# IT('s) Possible
import sys
import re
import html
import json
import urllib.parse

import requests
import feedparser

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from bs4 import BeautifulSoup

HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
ADDON_ICON = ADDON.getAddonInfo("icon")

BASE_URL = "https://www.bild.de"
BILDPLAY_URL = "https://www.bild.de/video/mediathek/video/bild-live-71144736.bild.html"
BILD_LIVE_URL = "https://m.bild.de/tv/mediathek/livestreaem/startseite-77204148.bildMobile.html"

PER_PAGE = 30


USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/140.0.0.0 Safari/537.36"
)

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "de-DE,de;q=0.9,en;q=0.7",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
}

VIDEO_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "*/*",
    "Accept-Language": "de-DE,de;q=0.9,en;q=0.7",
    "Referer": "https://www.bild.de/",
    "Origin": "https://www.bild.de",
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)


CATEGORIES = {
    "Top-News": "https://www.bild.de/feed/alles.xml",
    "Politik": "https://www.bild.de/rss-feeds/rss-16725492,feed=politik.bild.html",
    "News": "https://www.bild.de/rss-feeds/rss-16725492,feed=news.bild.html",
    "Sport": "https://www.bild.de/rss-feeds/rss-16725492,feed=sport.bild.html",
    "Unterhaltung": "https://www.bild.de/rss-feeds/rss-16725492,feed=unterhaltung.bild.html",
    "Lifestyle": "https://www.bild.de/rss-feeds/rss-16725492,feed=lifestyle.bild.html",
    "Auto": "https://www.bild.de/rss-feeds/rss-16725492,feed=auto.bild.html",
    "Ratgeber": "https://www.bild.de/rss-feeds/rss-16725492,feed=ratgeber.bild.html",
}

CATEGORY_DESCRIPTIONS = {
    "Top-News": "Die wichtigsten Nachrichten und Top-Themen des Tages auf einen Blick.",
    "Politik": "Aktuelle Nachrichten, Hintergründe und Analysen aus der deutschen und internationalen Politik.",
    "News": "Aktuelle Meldungen und Nachrichten aus aller Welt.",
    "Sport": "Alle Sportereignisse, Fußball-Bundesliga, Ergebnisse und Hintergründe.",
    "Unterhaltung": "Stars, Sternchen, Kino, TV und Klatsch & Tratsch.",
    "Lifestyle": "Ratgeber, Mode, Trends, Reise und Genuss.",
    "Auto": "Fahrberichte, Autotests, Verkehrsnews und Neuheiten rund ums Auto.",
    "Ratgeber": "Nützliche Tipps, Recht, Geld, Gesundheit und Alltagshilfen.",
}


def build_url(query):
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)


def absolute_url(url):
    if not url:
        return ""
    url = html.unescape(str(url).strip())
    if url.startswith("//"):
        return "https:" + url
    if url.startswith("/"):
        return BASE_URL + url
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return urllib.parse.urljoin(BASE_URL + "/", url)


def clean_text(value):
    if value is None:
        return ""
    value = html.unescape(str(value))
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def show_categories():
    url = build_url({"mode": "live"})
    li = xbmcgui.ListItem(label="BILD Live")
    li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle("BILD Live")
        tag.setPlot("Live-Streams, TV-Sender und Live-Berichterstattung von BILD.")
    except Exception:
        li.setInfo("video", {"title": "BILD Live", "plot": "Live-Streams, TV-Sender und Live-Berichterstattung von BILD."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    url = build_url({"mode": "bildplay"})
    li = xbmcgui.ListItem(label="BILDplay")
    li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle("BILDplay")
        tag.setPlot("Die BILD Mediathek mit aktuellen Videos, Dokus und Reportagen.")
    except Exception:
        li.setInfo("video", {"title": "BILDplay", "plot": "Die BILD Mediathek mit aktuellen Videos, Dokus und Reportagen."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    for title, feed_url in CATEGORIES.items():
        url = build_url({"mode": "list", "feed": feed_url, "title": title, "page": 1})
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
        plot = CATEGORY_DESCRIPTIONS.get(title, f"Aktuelle Artikel und Meldungen aus der Rubrik {title}.")
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setPlot(plot)
        except Exception:
            li.setInfo("video", {"title": title, "plot": plot})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_articles(feed_url, page=1):
    try:
        page = int(page)
        feed = feedparser.parse(feed_url)
    except Exception as e:
        xbmc.log(f"BILD RSS ERROR: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    entries = feed.entries
    start_idx = (page - 1) * PER_PAGE
    end_idx = start_idx + PER_PAGE
    page_entries = entries[start_idx:end_idx]

    for entry in page_entries:
        title = clean_text(entry.get("title", "Ohne Titel"))
        summary = clean_text(entry.get("summary", ""))
        link = absolute_url(entry.get("link", ""))

        if not link:
            continue

        url = build_url({"mode": "article", "title": title, "link": link})
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON, "poster": ADDON_ICON, "fanart": ADDON_ICON})

        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setPlot(summary if summary else f"Artikel: {title}")
        except Exception:
            li.setInfo("video", {"title": title, "plot": summary if summary else f"Artikel: {title}"})

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    if len(entries) > end_idx:
        next_url = build_url({
            "mode": "list",
            "feed": feed_url,
            "title": feed.get("feed", {}).get("title", "News"),
            "page": page + 1
        })
        next_li = xbmcgui.ListItem(label="Nächste Seite >>")
        next_li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
        try:
            tag = next_li.getVideoInfoTag()
            tag.setTitle("Nächste Seite")
            tag.setPlot("Weitere Artikel in dieser Rubrik laden.")
        except Exception:
            next_li.setInfo("video", {"title": "Nächste Seite", "plot": "Weitere Artikel in dieser Rubrik laden."})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def get_article_text(url):
    try:
        response = SESSION.get(url, headers=HEADERS, timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        selectors = ["article p", ".article-body p", ".txt p", '[data-key="article"] p']
        article_text = []

        for selector in selectors:
            paragraphs = soup.select(selector)
            if not paragraphs:
                continue
            for p in paragraphs:
                text = clean_text(p.get_text(" ", strip=True))
                if len(text) > 40 and text not in article_text:
                    article_text.append(text)
            if article_text:
                break

        if not article_text:
            return "Kein Artikeltext gefunden."

        return "\n\n".join(article_text)
    except Exception as e:
        return f"Fehler beim Laden:\n{e}"


def show_article(title, url):
    text = get_article_text(url)
    xbmcgui.Dialog().textviewer(title, text)


def load_bildplay():
    response = SESSION.get(BILDPLAY_URL, headers=HEADERS, timeout=25)
    response.raise_for_status()
    return response.text


def is_bild_article_url(url):
    if not url:
        return False
    url = absolute_url(url)
    if not url:
        return False
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.lower().split(":")[0]
    if host not in ("bild.de", "www.bild.de", "m.bild.de"):
        return False

    path = parsed.path.lower()
    blocked = ("/video/mediathek", "/rss", "/suche", "/login", "/account", "/shop", "/angebote", ".bildMobile.html")
    if any(item in path for item in blocked) or path in ("", "/"):
        return False
    return True


def get_anchor_url(anchor):
    for attr in ("href", "data-href", "data-url", "data-link", "data-target-url"):
        value = anchor.get(attr)
        if value:
            return absolute_url(value)
    return ""


def get_anchor_title(anchor):
    for attr in ("aria-label", "title", "data-title"):
        value = anchor.get(attr)
        if value and len(clean_text(value)) >= 4:
            return clean_text(value)
    for tag in ("h1", "h2", "h3", "strong"):
        el = anchor.find(tag)
        if el:
            val = clean_text(el.get_text(" ", strip=True))
            if len(val) >= 4:
                return val
    return clean_text(anchor.get_text(" ", strip=True))


def get_anchor_thumbnail(anchor):
    img = anchor.find("img") or (anchor.parent and anchor.parent.find("img"))
    if img:
        for attr in ("src", "data-src", "data-original", "data-lazy-src"):
            val = img.get(attr)
            if val and absolute_url(val):
                return absolute_url(val)
        srcset = img.get("srcset") or img.get("data-srcset")
        if srcset:
            first = srcset.split(",")[0].strip().split(" ")[0]
            if absolute_url(first):
                return absolute_url(first)
    return ADDON_ICON


def get_anchor_description(anchor):
    container = anchor.find_parent(["article", "div", "li"])
    if container:
        p_tags = container.find_all("p")
        for p in p_tags:
            text = clean_text(p.get_text(" ", strip=True))
            if len(text) > 10:
                return text
        spans = container.find_all(["span", "div"], class_=re.compile(r"(sub|desc|text|teaser|summary)", re.I))
        for span in spans:
            text = clean_text(span.get_text(" ", strip=True))
            if len(text) > 10:
                return text
    return ""


def parse_bildplay_link(anchor):
    url = get_anchor_url(anchor)
    if not url or not is_bild_article_url(url):
        return None
    title = get_anchor_title(anchor)
    if not title or title.lower() in ("startseite", "stream", "dokus", "bild talk", "podcasts", "mehr", "alle anzeigen", "zurück"):
        return None
    thumb = get_anchor_thumbnail(anchor)
    plot = get_anchor_description(anchor)
    if not plot:
        plot = f"Video-Beitrag: {title}"
    return {"title": title, "url": url, "thumb": thumb, "plot": plot}


def extract_bildplay_sections(soup):
    sections = []
    headings = soup.find_all("h2")

    for heading in headings:
        title = clean_text(heading.get_text(" ", strip=True))
        if not title:
            continue

        videos = []
        seen = set()

        for node in heading.find_all_next():
            if node.name == "h2" and node is not heading:
                break
            if node.name != "a":
                continue

            item = parse_bildplay_link(node)
            if item:
                key = item["url"].split("?", 1)[0].lower()
                if key not in seen:
                    seen.add(key)
                    videos.append(item)

        if videos:
            sections.append({"title": title, "videos": videos})

    return sections


def list_bildplay():
    try:
        page = load_bildplay()
        soup = BeautifulSoup(page, "html.parser")
        sections = extract_bildplay_sections(soup)

        if not sections:
            xbmcgui.Dialog().notification("BILDplay", "Keine Kategorien gefunden", xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        for section in sections:
            title = section["title"]
            url = build_url({"mode": "section", "title": title, "page": 1})
            li = xbmcgui.ListItem(label=title)
            li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
            plot = f"Videos und Beiträge in der Rubrik: {title}"
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(title)
                tag.setPlot(plot)
            except Exception:
                li.setInfo("video", {"title": title, "plot": plot})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    except Exception as e:
        xbmc.log(f"BILDplay MENU ERROR: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def list_bildplay_section(section_title, page=1):
    try:
        page = int(page)
        section_title = urllib.parse.unquote(section_title)
        page_html = load_bildplay()
        soup = BeautifulSoup(page_html, "html.parser")
        sections = extract_bildplay_sections(soup)

        selected = next((s for s in sections if s["title"].strip() == section_title.strip()), None)

        if not selected:
            xbmcgui.Dialog().notification("BILDplay", "Kategorie nicht gefunden", xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        videos = selected["videos"]
        start_idx = (page - 1) * PER_PAGE
        end_idx = start_idx + PER_PAGE
        page_videos = videos[start_idx:end_idx]

        for video in page_videos:
            title = video["title"]
            article_url = video["url"]
            thumb = video["thumb"]
            plot = video["plot"]

            play_url = build_url({"mode": "play", "url": article_url, "title": title})
            li = xbmcgui.ListItem(label=title)
            li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})

            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(title)
                tag.setPlot(plot)
                tag.setStudio("BILD")
                tag.setGenre(selected["title"])
            except Exception:
                li.setInfo("video", {"title": title, "plot": plot, "studio": "BILD", "genre": selected["title"]})

            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=play_url, listitem=li, isFolder=False)

        if len(videos) > end_idx:
            next_url = build_url({
                "mode": "section",
                "title": section_title,
                "page": page + 1
            })
            next_li = xbmcgui.ListItem(label="Nächste Seite >>")
            next_li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
            try:
                tag = next_li.getVideoInfoTag()
                tag.setTitle("Nächste Seite")
                tag.setPlot("Weitere Videos in dieser Kategorie laden.")
            except Exception:
                next_li.setInfo("video", {"title": "Nächste Seite", "plot": "Weitere Videos in dieser Kategorie laden."})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=next_url, listitem=next_li, isFolder=True)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    except Exception as e:
        xbmc.log(f"BILDplay SECTION ERROR: {e}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def resolve_article_stream(article_url):
    try:
        response = SESSION.get(article_url, headers=VIDEO_HEADERS, timeout=15, allow_redirects=True)
        if response.status_code == 200:
            html_content = response.text

            m3u8_matches = re.findall(r'https?://[^\s<>"]+?\.m3u8[^\s<>"]*', html_content)
            for m3u8_url in m3u8_matches:
                clean_m3u8 = m3u8_url.replace('\\/', '/')
                if clean_m3u8.startswith("http"):
                    return {"url": clean_m3u8, "type": "hls"}

            soup = BeautifulSoup(html_content, "html.parser")
            for script in soup.find_all("script"):
                script_text = script.get_text()
                if not script_text:
                    continue

                m3u8_script = re.findall(r'https?:\\?/\\?/[^\s<>"]+?\.m3u8', script_text)
                for found in m3u8_script:
                    clean_url = found.replace('\\/', '/')
                    if clean_url.startswith("http"):
                        return {"url": clean_url, "type": "hls"}

                for key in ['hlsUrl', 'streamUrl', 'playbackUrl', 'file', 'src']:
                    pattern = rf'"{key}"\s*:\s*"([^"]+\.m3u8[^"]*)"'
                    match = re.search(pattern, script_text)
                    if match:
                        url_val = match.group(1).replace('\\/', '/')
                        if url_val.startswith("http"):
                            return {"url": url_val, "type": "hls"}

            match_ak = re.search(r'https?://hds\.ak\.token\.bild\.de/([a-f0-9]{24})', html_content)
            if match_ak:
                token_id = match_ak.group(1)
                return {"url": f"https://hds.ak.token.bild.de/{token_id},delivery=hls.m3u8", "type": "hls"}

            match_url_id = re.search(r'-([a-f0-9]{24})(?:\.bild\.html)?$', article_url)
            if match_url_id:
                token_id = match_url_id.group(1)
                return {"url": f"https://hds.ak.token.bild.de/{token_id},delivery=hls.m3u8", "type": "hls"}

            for iframe in soup.find_all("iframe", src=True):
                iframe_src = iframe["src"]
                if ".m3u8" in iframe_src:
                    return {"url": absolute_url(iframe_src), "type": "hls"}

        return None
    except Exception as e:
        xbmc.log(f"BILDplay Resolver ERROR: {e}", xbmc.LOGERROR)
        return None


def play_video(article_url, title=""):
    article_url = absolute_url(urllib.parse.unquote(article_url))
    if not article_url:
        xbmcgui.Dialog().notification("BILDplay", "Keine Video-URL", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    result = resolve_article_stream(article_url)
    if not result:
        xbmcgui.Dialog().notification("BILDplay", "Kein Stream verfügbar", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    stream_url = result["url"]
    li = xbmcgui.ListItem(label=title, path=stream_url)
    li.setProperty("IsPlayable", "true")

    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setStudio("BILD")
    except Exception:
        li.setInfo("video", {"title": title, "studio": "BILD"})

    header_string = (
        f"User-Agent={urllib.parse.quote(USER_AGENT, safe='')}&"
        f"Referer={urllib.parse.quote(article_url, safe='')}"
    )
    li.setPath(f"{stream_url}|{header_string}")

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def list_live_channels():
    try:
        response = SESSION.get(BILD_LIVE_URL, headers=VIDEO_HEADERS, timeout=25)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        videos = []
        seen = set()

        for a in soup.find_all("a", href=True):
            item = parse_bildplay_link(a)
            if item:
                key = item["url"].split("?", 1)[0].lower()
                if key not in seen:
                    seen.add(key)
                    videos.append(item)

        filtered_videos = []
        blocked_words = ["leasing", "autokredit", "game", "slot", "casino", "spiel", "rabatt", "gutschein", "vergleich", "reality-tv", "kredit", "finanzierung"]
        allowed_words = ["tv", "kanal", "stream", "cooking", "xplore", "moconomy"]

        for video in videos:
            title_lower = video["title"].lower()
            if any(b in title_lower for b in blocked_words):
                continue
            if any(a in title_lower for a in allowed_words):
                filtered_videos.append(video)

        videos = filtered_videos

        if not videos:
            xbmcgui.Dialog().notification("BILD Live", "Keine Live-Sender gefunden", xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        for video in videos:
            title = video["title"]
            article_url = video["url"]
            thumb = video["thumb"]
            plot = video["plot"] if video["plot"] else f"Live-Stream / TV-Sender: {title}"

            play_url = build_url({"mode": "play", "url": article_url, "title": title})
            li = xbmcgui.ListItem(label=title)
            li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})

            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(title)
                tag.setPlot(plot)
                tag.setStudio("BILD Live")
            except Exception:
                li.setInfo("video", {"title": title, "plot": plot, "studio": "BILD Live"})

            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    except Exception as e:
        xbmc.log(f"BILD Live List ERROR: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("BILD Live", "Fehler beim Laden der Sender", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")

    if mode is None:
        show_categories()
    elif mode == "list":
        list_articles(params.get("feed", ""), int(params.get("page", 1)))
    elif mode == "article":
        show_article(params.get("title", "Artikel"), params.get("link", ""))
    elif mode == "bildplay":
        list_bildplay()
    elif mode == "section":
        list_bildplay_section(params.get("title", ""), int(params.get("page", 1)))
    elif mode == "play":
        play_video(params.get("url", ""), params.get("title", ""))
    elif mode == "live":
        list_live_channels()
    else:
        show_categories()


if __name__ == "__main__":
    try:
        paramstring = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
        router(paramstring)
    except Exception as e:
        xbmc.log(f"BILD Addon FATAL ERROR: {e}", xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification("BILD", f"Fehler: {str(e)[:100]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        except Exception:
            pass
