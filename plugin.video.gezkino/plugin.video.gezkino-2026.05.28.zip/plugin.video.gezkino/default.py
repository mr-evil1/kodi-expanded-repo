import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import requests
import xbmc
import xbmcaddon
import os
import sqlite3
import xbmcvfs
import re
import json
import hashlib
import string
# ==========================================
# 1. KONFIGURATION & PFADE
# ==========================================
BASE_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2].lstrip('?'))

# Dynamische Pfade für das Addon und den Medien-Ordner ermitteln
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA_DIR = os.path.join(ADDON_PATH, "media")

ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.gezkino/")
if not os.path.exists(ADDON_DATA_DIR):
    os.makedirs(ADDON_DATA_DIR)
DB_PATH = os.path.join(ADDON_DATA_DIR, "movie_metadata.db")

# ==========================================
# 2. DATENBANK INITIALISIERUNG
# ==========================================
def init_db():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS movie_cache
                         (search_title TEXT PRIMARY KEY, plot TEXT, rating TEXT, 
                          poster_url TEXT, local_poster TEXT, genres_json TEXT)''')
            c.execute('''CREATE TABLE IF NOT EXISTS film_list 
                         (hash_id TEXT PRIMARY KEY, title TEXT, video_url TEXT, 
                          search_name TEXT, year TEXT, genres_json TEXT)''')
            conn.commit()
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Fehler bei DB-Initialisierung: {str(e)}", xbmc.LOGERROR)

init_db()

# ==========================================
# 3. TITEL-BEREINIGUNG & TMDB-ABFRAGE
# ==========================================
def clean_title(title):
    """ Bereinigt Titel radikal von Mediathek-Altlasten für perfekte TMDB-Treffer """
    year_match = re.search(r'(\d{4})', title)
    year = year_match.group(1) if year_match else None
    
    clean = title
    markers = [
        ' - Spielfilm', ' – Spielfilm', ' - Spiellfilm', ' – Spiellfilm', ', Spielfilm', 
        ' Österreich', ', Deutschland', ', Schweiz', ', Belgien', ', Frankreich', ', Spanien',
        ', Niederlande', ', Irland', ', Luxemburg', ', Italien', ', USA', ', Kosovo', 
        ', Großbritannien', ', Tschechische Republik', ', Norwegen', ', BRD', ', Dänemark', 
        ', Australien', ', Schweden', ', Video:', ', Präsentiert:', ', Kurzfilm',
        ' Fernsehfilm', ' Heimatfilm', ' - Thriller', ' - Drama',
        ' - Aufstand der Pferdefreunde Spielfilm', '«', '»'
    ]
    for marker in markers:
        clean = re.split(marker, clean, flags=re.I)[0]

    clean = re.sub(r'^(Spielfilm|Spiellfilm):\s*', '', clean, flags=re.I)
    clean = clean.replace('–', '-').replace('—', '-')
    clean = re.sub(r'\(.*?\)', '', clean)
    clean = clean.strip().rstrip('( ,.-_–—»')
    return (clean, year)

def get_tmdb_data_sync(session, title, year=None):
    """ Holt echte Filmdaten und Genre-IDs von TMDB """
    api_key = '60b3801a9e76b5706ee2a432f06423e6'
    genres_map = {
        28: 'Action', 12: 'Abenteuer', 16: 'Animation', 35: 'Komödie', 80: 'Krimi', 99: 'Doku',
        18: 'Drama', 10751: 'Familie', 14: 'Fantasy', 36: 'Historie', 27: 'Horror', 10402: 'Musik',
        9648: 'Mystery', 10749: 'Romanze', 878: 'Sci-Fi', 10770: 'TV-Film', 53: 'Thriller', 10752: 'Krieg', 37: 'Western'
    }
    try:
        import time
        time.sleep(0.02)  # API-Rate-Limit schonen
        params = {"api_key": api_key, "query": title, "language": "de-DE", "include_adult": "false"}
        if year:
            params["year"] = year
        
        res = session.get("https://api.themoviedb.org/3/search/movie", params=params, timeout=5).json()
        results = res.get('results', [])
        
        if not results and year:
            params.pop("year")
            res = session.get("https://api.themoviedb.org/3/search/movie", params=params, timeout=5).json()
            results = res.get('results', [])
            
        if results:
            movie = results[0]
            path = movie.get('poster_path')
            g_ids = movie.get('genre_ids', [])
            genres_list = [genres_map[gid] for gid in g_ids if gid in genres_map]
            if not genres_list:
                genres_list = ['Mediathek']
            return {
                "poster": f"https://image.tmdb.org/t/p/w342{path}" if path else "",
                "plot": movie.get('overview', 'Keine Beschreibung verfügbar.'),
                "rating": str(movie.get('vote_average', 'N/A')),
                "genres_list": genres_list
            }
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] TMDB Fehler für {title}: {e}", xbmc.LOGERROR)
    return None

# ==========================================
# 4. BACKGROUND SYNC LOGIK
# ==========================================
def aktualisiere_datenbank():
    """ Lädt alle Filme, filtert Duplikate/Hörfassungen und gleicht sie mit TMDB ab """
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('GEZ Kino', 'Starte Abfrage der Mediatheken...')
    
    session = requests.Session()
    seen_titles = set()
    results_map = {}
    
    api_url = 'https://mediathekviewweb.de/api/query'
    headers = {'User-Agent': 'Mozilla/5.0', 'Accept-Encoding': 'gzip, deflate'}
    queries = ['Spielfilm', 'Spielfilme', 'Spielfilm-Highlights', 'Filme', 'Kino - Filme']
    
    # 1. Mediatheken durchsuchen
    for idx, q in enumerate(queries):
        pDialog.update(int((idx / len(queries)) * 30), f'Lade Kategorie: {q}...')
        if pDialog.iscanceled(): return
        
        payload = {'queries': [{'fields': ['topic'], 'query': q}], 'size': 2000, 'sortBy': 'timestamp', 'sortOrder': 'desc'}
        try:
            r = session.post(api_url, json=payload, headers=headers, timeout=10)
            if r.status_code == 200:
                results = r.json().get('result', {}).get('results', [])
                for m in results:
                    url = m.get('url_video', '')
                    title = m.get('title', '')
                    if not url or not title: continue
                    
                    lower_title = title.lower()
                    if any(x in lower_title for x in ["audiodeskription", "audio description", "ad version", "hörfilm", "deskription", "barrierefrei version"]):
                        continue
                    if url in results_map: continue
                    
                    clean_name, prod_year = clean_title(title)
                    if not clean_name: continue
                    
                    title_norm = clean_name.strip().lower()
                    if title_norm in seen_titles: continue
                    if m.get('duration', 0) < 4680: continue # Mindestens 78 Minuten
                    
                    seen_titles.add(title_norm)
                    results_map[url] = {
                        'title': clean_name, 'year': prod_year, 'video_url': url, 'search': clean_name,
                        'plot': 'Keine Info verfügbar.', 'rating': 'N/A', 'genres_list': ['Mediathek']
                    }
        except Exception as e:
            xbmc.log(f"[GEZ-Kino] API Fehler bei {q}: {e}", xbmc.LOGERROR)

    # 2. IPTV Live-TV Kanäle hinzufügen
    pDialog.update(35, 'Lade Live-TV Senderliste...')
    iptv_url = "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_main.m3u"
    try:
        r = session.get(iptv_url, timeout=5)
        if r.status_code == 200:
            lines = r.text.splitlines()
            for i in range(len(lines)):
                if lines[i].startswith("#EXTINF"):
                    logo_match = re.search(r'tvg-logo="([^"]+)"', lines[i])
                    name = lines[i].split(',')[-1].strip()
                    if i + 1 < len(lines) and lines[i+1].startswith("http"):
                        url = lines[i+1].strip()
                        results_map[url] = {
                            'title': f"[TV] {name}", 'year': '', 'video_url': url, 'search': name,
                            'plot': 'Live-TV Sender', 'rating': 'LIVE', 'genres_list': ['Live-TV'],
                            'logo_url': logo_match.group(1) if logo_match else ""
                        }
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] IPTV Fehler: {e}", xbmc.LOGERROR)

    # 3. TMDB-Daten einspeisen und in Datenbank sichern
    total_movies = len(results_map)
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("DELETE FROM film_list") # Altdaten leeren
            
            for idx, (url, movie) in enumerate(results_map.items()):
                if idx % 15 == 0:
                    pct = 40 + int((idx / total_movies) * 60)
                    pDialog.update(pct, f'Verarbeite Eintrag {idx}/{total_movies}...\n{movie["title"]}')
                    if pDialog.iscanceled(): break
                
                if 'Live-TV' not in movie['genres_list']:
                    cache_key = f"{movie['search']}_{movie['year']}"
                    c = conn.cursor()
                    c.execute("SELECT plot, rating, local_poster, genres_json FROM movie_cache WHERE search_title=?", (cache_key,))
                    res = c.fetchone()
                    
                    if res:
                        movie['plot'], movie['rating'], movie['thumb'] = res[0], res[1], res[2]
                        movie['genres_list'] = json.loads(res[3])
                    else:
                        tmdb = get_tmdb_data_sync(session, movie['search'], movie['year'])
                        if tmdb:
                            movie['plot'], movie['rating'], movie['genres_list'], movie['thumb'] = tmdb['plot'], tmdb['rating'], tmdb['genres_list'], tmdb['poster']
                            conn.execute("INSERT OR REPLACE INTO movie_cache VALUES (?, ?, ?, ?, ?, ?)",
                                         (cache_key, tmdb['plot'], tmdb['rating'], tmdb['poster'], tmdb['poster'], json.dumps(tmdb['genres_list'])))
                        else:
                            movie['thumb'] = ''
                else:
                    movie['thumb'] = movie.get('logo_url', '')

                conn.execute("INSERT OR REPLACE INTO film_list VALUES (?,?,?,?,?,?)",
                             (hashlib.md5(url.encode()).hexdigest(), movie['title'], url, movie['search'], str(movie['year']), json.dumps(movie['genres_list'])))
            conn.commit()
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] DB Speicherfehler: {e}", xbmc.LOGERROR)
        
    pDialog.close()
    xbmcgui.Dialog().notification('GEZ Kino', 'Datenbank erfolgreich aktualisiert!', xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin('Container.Refresh')

# ==========================================
# 5. LOKALE ABFRAGE, FILTERUNG & SORTIERUNG
# ==========================================
def hole_lokale_filme_aus_db(genre_filter, suchbegriff_suche=None, start_char=None):
    """ Filtert und sortiert das Material lokal aus der SQLite-Struktur """
    filme_liste = []
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='film_list'")
            if not c.fetchone(): return None
            
            query = """
                SELECT f.title, f.video_url, f.search_name, f.year, f.genres_json, c.local_poster, c.plot, c.rating
                FROM film_list f
                LEFT JOIN movie_cache c ON (f.search_name || '_' || f.year) = c.search_title
            """
            rows = conn.execute(query).fetchall()
            if not rows: return None
            
            for r in rows:
                g_list = json.loads(r[4])
                is_tv = 'Live-TV' in g_list
                title = r[0]
                
                # Suchbegriff Filter
                if suchbegriff_suche and suchbegriff_suche.lower() not in title.lower():
                    continue
                
                # A-Z Filter
                if start_char:
                    first_char = title[0].upper()
                    if start_char == '#':
                        # Filtere alles, was NICHT mit A-Z beginnt
                        if first_char.isalpha():
                            continue
                    else:
                        # Filtere nur nach dem spezifischen Buchstaben
                        if first_char != start_char:
                            continue
                    
                # Genre Filter
                if genre_filter != 'AZ': # Bei AZ überspringen wir die Genre-Logik
                    if genre_filter == 'Live-TV':
                        if not is_tv: continue
                    elif genre_filter == 'Alle':
                        if is_tv: continue
                    elif genre_filter == 'Sonstige':
                        if is_tv or (g_list and g_list != ['Mediathek']): continue
                    else:
                        if genre_filter not in g_list: continue
                    
                filme_liste.append({
                    "title": title, "url": r[1], "desc": r[6] if r[6] else 'Keine Beschreibung.',
                    "rating": r[7] if r[7] else 'N/A', "thumb": r[5] if r[5] else '', "genres": g_list
                })
                
        # Alphabetische Sortierung
        filme_liste.sort(key=lambda x: x['title'].lower())
        return filme_liste
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] DB Ladefehler: {e}", xbmc.LOGERROR)
        return []

# ==========================================
# 6. KODI UI MENÜSTRUKTUR (korrigiert)
# ==========================================
def zeige_hauptmenue():
    p_icon1 = os.path.join(MEDIA_DIR, "icon1.png")
    p_icon2 = os.path.join(MEDIA_DIR, "icon2.png")
    p_icon3 = os.path.join(MEDIA_DIR, "icon3.png")
    p_icon4 = os.path.join(MEDIA_DIR, "icon4.png")
    p_icon5 = os.path.join(MEDIA_DIR, "icon5.png")    
    # 1. Alle Spielfilme
    li1 = xbmcgui.ListItem(label="[ Alle Spielfilme ]")
    li1.setInfo('video', {'title': "Alle Spielfilme", 'plot': "Zeigt die komplette Liste vieler Spielfilme aus den öffentlich-rechtlichen Mediatheken an. Komplett alphabetisch sortiert."})
    li1.setArt({'icon': p_icon1, 'thumb': p_icon1})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=list&query=Alle", listitem=li1, isFolder=True)

    # 1.1. A-Z Menü
    li_az = xbmcgui.ListItem(label="[ Filme A-Z ]")
    li_az.setInfo('video', {'title': "Filme A-Z", 'plot': "Durchsuche die Filmliste alphabetisch."})
    li_az.setArt({'icon': p_icon5, 'thumb': p_icon5})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=az_menu", listitem=li_az, isFolder=True)

    # 2. Nach Genres filtern
    li2 = xbmcgui.ListItem(label="[ Nach Genres filtern... ]")
    li2.setInfo('video', {'title': "Nach Genres filtern", 'plot': "Öffnet das Genre-Menü. Hier kannst du gezielt nach Kategorien wie Krimi, Action, Drama, Komödien oder Dokumentationen filtern."})
    li2.setArt({'icon': p_icon2, 'thumb': p_icon2})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=genres_menu", listitem=li2, isFolder=True)

    # 3. Film suchen
    li3 = xbmcgui.ListItem(label="[ Film suchen... ]")
    li3.setInfo('video', {'title': "Film suchen", 'plot': "Öffnet eine Tastatur, um die lokale Datenbank gezielt nach einem bestimmten Filmtitel oder Suchbegriff zu durchsuchen."})
    li3.setArt({'icon': p_icon3, 'thumb': p_icon3})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=search", listitem=li3, isFolder=True)

    # 4. Datenbank aktualisieren
    li4 = xbmcgui.ListItem(label="[ Mediathek Datenbank aktualisieren ]")
    li4.setInfo('video', {'title': "Datenbank aktualisieren", 'plot': "Startet den Suchlauf. Lädt frische Filme aus den Mediatheken."})
    li4.setArt({'icon': p_icon4, 'thumb': p_icon4})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=sync", listitem=li4, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_az_menue():
    buchstaben = ['#'] + list(string.ascii_uppercase)
    for buchstabe in buchstaben:
        url = f"{BASE_URL}?action=list&query=AZ&char={buchstabe}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=buchstabe), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def zeige_genre_menue():
    genres = [
        ("Live-TV", "Live-TV"), ("Action", "Action"),    
        ("Abenteuer", "Abenteuer"), ("Animation", "Animation"), ("Komoedien", "Komödie"),
        ("Krimi", "Krimi"), ("Dokumentationen", "Doku"), ("Dramen", "Drama"),
        ("Familie", "Familie"), ("Fantasy", "Fantasy"), ("Historie", "Historie"),
        ("Horror", "Horror"), ("Musik", "Musik"), ("Mystery", "Mystery"),    
        ("Liebesfilme und Romantik", "Romanze"), ("Science Fiction", "Sci-Fi"),
        ("TV-Film", "TV-Film"), ("Thriller", "Thriller"), ("Krieg", "Krieg"),      
        ("Western", "Western"), ("Sonstige (Unkategorisiert)", "Sonstige")
    ]
    for label, internal_name in genres:
        url = f"{BASE_URL}?action=list&query={urllib.parse.quote_plus(internal_name)}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=label), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_filmliste(genre_query, search_str=None, start_char=None):
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    filme = hole_lokale_filme_aus_db(genre_query, suchbegriff_suche=search_str, start_char=start_char)
    
    if filme is None: # DB komplett leer
        if xbmcgui.Dialog().yesno("Datenbank leer", "Die lokale Datenbank ist leer. Jetzt aktualisieren?"):
            aktualisiere_datenbank()
            # Hier start_char auch übergeben!
            filme = hole_lokale_filme_aus_db(genre_query, suchbegriff_suche=search_str, start_char=start_char)
        else:
            filme = []
            
    if not filme:
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=xbmcgui.ListItem(label="Keine Filme gefunden."), isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
        
    for film in filme:
        display_label = film['title']
        if film['rating'] and film['rating'] not in ['N/A', 'LIVE']:
            display_label += f" [★ {film['rating']}]"
            
        li = xbmcgui.ListItem(label=display_label)
        li.setInfo('video', {
            'title': film['title'], 'plot': film['desc'], 
            'genre': ", ".join(film['genres']),
            'rating': float(film['rating']) if film['rating'] not in ['N/A', 'LIVE'] else 0.0
        })
        
        art_dict = {}
        if film['thumb']:
            art_dict['poster'] = film['thumb']
            art_dict['thumb'] = film['thumb']
            art_dict['icon'] = film['thumb']
            art_dict['fanart'] = film['thumb']
        li.setArt(art_dict)
        li.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=film['url'], listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# ==========================================
# 7. ROUTING-SYSTEM (aktualisiert)
# ==========================================
action = ARGS.get('action', [None])[0]
query = ARGS.get('query', [None])[0]
char = ARGS.get('char', [None])[0] # Parameter für Buchstabe

if action == 'list' and query == 'AZ':
    zeige_filmliste('AZ', start_char=char)
elif action == 'list' and query:
    zeige_filmliste(query)
elif action == 'az_menu':
    zeige_az_menue()
elif action == 'genres_menu':
    zeige_genre_menue()
elif action == 'sync':
    aktualisiere_datenbank()
elif action == 'search':
    kb = xbmc.Keyboard('', 'Film suchen...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        zeige_filmliste('Alle', search_str=kb.getText())
else:
    zeige_hauptmenue()
