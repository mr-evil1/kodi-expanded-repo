import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import requests
import xbmc
import xbmcaddon
import os
import sqlite3
import xbmcvfs
import re
import json
import hashlib
import string
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

BASE_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2].lstrip('?'))

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA_DIR = os.path.join(ADDON_PATH, "media")

ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.gezkino/")
if not os.path.exists(ADDON_DATA_DIR):
    os.makedirs(ADDON_DATA_DIR)
DB_PATH = os.path.join(ADDON_DATA_DIR, "movie_metadata.db")

def init_db():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS movie_cache
                         (search_title TEXT PRIMARY KEY, plot TEXT, rating TEXT,
                          poster_url TEXT, local_poster TEXT, genres_json TEXT)''')
            c.execute('''CREATE TABLE IF NOT EXISTS film_list
                         (hash_id TEXT PRIMARY KEY, title TEXT, video_url TEXT,
                          search_name TEXT, year TEXT, genres_json TEXT)''')
            conn.commit()
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Fehler bei DB-Initialisierung: {str(e)}", xbmc.LOGERROR)

init_db()

def clean_title(title):
    year_match = re.search(r'(\d{4})', title)
    year = year_match.group(1) if year_match else None
    clean = title
    markers = [
        ' - Spielfilm', ' – Spielfilm', ' - Spiellfilm', ' – Spiellfilm', ', Spielfilm',
        ' Österreich', ', Deutschland', ', Schweiz', ', Belgien', ', Frankreich', ', Spanien',
        ', Niederlande', ', Irland', ', Luxemburg', ', Italien', ', USA', ', Kosovo',
        ', Großbritannien', ', Tschechische Republik', ', Norwegen', ', BRD', ', Dänemark',
        ', Australien', ', Schweden', ', Video:', ', Präsentiert:', ', Kurzfilm',
        ' Fernsehfilm', ' Heimatfilm', ' - Thriller', ' - Drama',
        ' - Aufstand der Pferdefreunde Spielfilm', '«', '»'
    ]
    for marker in markers:
        clean = re.split(marker, clean, flags=re.I)[0]
    clean = re.sub(r'^(Spielfilm|Spiellfilm):\s*', '', clean, flags=re.I)
    clean = clean.replace('–', '-').replace('—', '-')
    clean = re.sub(r'\(.*?\)', '', clean)
    clean = clean.strip().rstrip('( ,.-_–—»')
    return (clean, year)

_GENRES_MAP = {
    28: 'Action', 12: 'Abenteuer', 16: 'Animation', 35: 'Komödie', 80: 'Krimi', 99: 'Doku',
    18: 'Drama', 10751: 'Familie', 14: 'Fantasy', 36: 'Historie', 27: 'Horror', 10402: 'Musik',
    9648: 'Mystery', 10749: 'Romanze', 878: 'Sci-Fi', 10770: 'TV-Film', 53: 'Thriller',
    10752: 'Krieg', 37: 'Western'
}
_TMDB_KEY = '60b3801a9e76b5706ee2a432f06423e6'

def get_tmdb_data_sync(session, title, year=None):
    try:
        params = {"api_key": _TMDB_KEY, "query": title, "language": "de-DE", "include_adult": "false"}
        if year:
            params["year"] = year
        res = session.get("https://api.themoviedb.org/3/search/movie", params=params, timeout=5).json()
        results = res.get('results', [])
        if not results and year:
            params.pop("year")
            res = session.get("https://api.themoviedb.org/3/search/movie", params=params, timeout=5).json()
            results = res.get('results', [])
        if results:
            movie = results[0]
            path = movie.get('poster_path')
            genres_list = [_GENRES_MAP[gid] for gid in movie.get('genre_ids', []) if gid in _GENRES_MAP]
            if not genres_list:
                genres_list = ['Mediathek']
            return {
                "poster": f"https://image.tmdb.org/t/p/w342{path}" if path else "",
                "plot": movie.get('overview', 'Keine Beschreibung verfügbar.'),
                "rating": str(movie.get('vote_average', 'N/A')),
                "genres_list": genres_list
            }
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] TMDB Fehler für {title}: {e}", xbmc.LOGERROR)
    return None

def aktualisiere_datenbank():
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('GEZ Kino', 'Starte parallele Abfrage...')

    api_url = 'https://mediathekviewweb.de/api/query'
    headers = {'User-Agent': 'Mozilla/5.0', 'Accept-Encoding': 'gzip, deflate'}
    queries = ['Spielfilm', 'Spielfilme', 'Spielfilm-Highlights', 'Filme', 'Kino - Filme']
    iptv_url = "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_main.m3u"
    skip_words = ["audiodeskription", "audio description", "ad version", "hörfilm", "deskription", "barrierefrei version"]

    def fetch_mediathek(q):
        s = requests.Session()
        payload = {'queries': [{'fields': ['topic'], 'query': q}], 'size': 2000, 'sortBy': 'timestamp', 'sortOrder': 'desc'}
        try:
            r = s.post(api_url, json=payload, headers=headers, timeout=10)
            if r.status_code == 200:
                return r.json().get('result', {}).get('results', [])
        except Exception as e:
            xbmc.log(f"[GEZ-Kino] API Fehler bei {q}: {e}", xbmc.LOGERROR)
        return []

    def fetch_iptv():
        s = requests.Session()
        try:
            r = s.get(iptv_url, timeout=5)
            if r.status_code == 200:
                return r.text.splitlines()
        except Exception as e:
            xbmc.log(f"[GEZ-Kino] IPTV Fehler: {e}", xbmc.LOGERROR)
        return []

    pDialog.update(5, 'Lade Mediatheken + IPTV parallel...')
    raw_mediathek = {}
    raw_iptv_lines = []

    with ThreadPoolExecutor(max_workers=6) as ex:
        mediathek_futures = {ex.submit(fetch_mediathek, q): q for q in queries}
        iptv_future = ex.submit(fetch_iptv)

        for future in as_completed(list(mediathek_futures.keys()) + [iptv_future]):
            if pDialog.iscanceled():
                ex.shutdown(wait=False, cancel_futures=True)
                return
            if future is iptv_future:
                raw_iptv_lines = future.result()
            else:
                raw_mediathek[mediathek_futures[future]] = future.result()

    pDialog.update(28, 'Verarbeite Ergebnisse...')
    seen_titles = set()
    results_map = {}

    for q in queries:
        for m in raw_mediathek.get(q, []):
            url = m.get('url_video', '')
            title = m.get('title', '')
            if not url or not title or url in results_map:
                continue
            if any(x in title.lower() for x in skip_words):
                continue
            clean_name, prod_year = clean_title(title)
            if not clean_name:
                continue
            title_norm = clean_name.strip().lower()
            if title_norm in seen_titles:
                continue
            if m.get('duration', 0) < 4680:
                continue
            seen_titles.add(title_norm)
            results_map[url] = {
                'title': clean_name, 'year': prod_year if prod_year else '', 'video_url': url, 'search': clean_name,
                'plot': 'Keine Info verfügbar.', 'rating': 'N/A', 'genres_list': ['Mediathek'], 'thumb': ''
            }

    for i in range(len(raw_iptv_lines)):
        if raw_iptv_lines[i].startswith("#EXTINF"):
            logo_match = re.search(r'tvg-logo="([^"]+)"', raw_iptv_lines[i])
            name = raw_iptv_lines[i].split(',')[-1].strip()
            if i + 1 < len(raw_iptv_lines) and raw_iptv_lines[i + 1].startswith("http"):
                url = raw_iptv_lines[i + 1].strip()
                results_map[url] = {
                    'title': f"[TV] {name}", 'year': '', 'video_url': url, 'search': name,
                    'plot': 'Live-TV Sender', 'rating': 'LIVE', 'genres_list': ['Live-TV'],
                    'logo_url': logo_match.group(1) if logo_match else "", 'thumb': ''
                }

    if pDialog.iscanceled():
        return

    pDialog.update(32, 'Prüfe Cache...')
    to_fetch = []

    movie_urls = [url for url, m in results_map.items() if 'Live-TV' not in m['genres_list']]
    cache_key_map = {f"{results_map[url]['search']}_{results_map[url]['year']}": url for url in movie_urls}

    try:
        with sqlite3.connect(DB_PATH) as conn:
            for url, movie in results_map.items():
                if 'Live-TV' in movie['genres_list']:
                    movie['thumb'] = movie.get('logo_url', '')

            if cache_key_map:
                keys = list(cache_key_map.keys())
                placeholders = ','.join('?' * len(keys))
                rows = conn.execute(
                    f"SELECT search_title, plot, rating, local_poster, genres_json FROM movie_cache WHERE search_title IN ({placeholders})",
                    keys
                ).fetchall()
                cached = {row[0]: row for row in rows}

                for cache_key, url in cache_key_map.items():
                    movie = results_map[url]
                    if cache_key in cached:
                        row = cached[cache_key]
                        movie['plot'], movie['rating'], movie['thumb'] = row[1], row[2], row[3] or ''
                        movie['genres_list'] = json.loads(row[4])
                    else:
                        to_fetch.append((url, movie, cache_key))
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Cache-Prüfung Fehler: {e}", xbmc.LOGERROR)

    total_fetch = len(to_fetch)
    tmdb_results = {}
    completed_count = [0]
    count_lock = threading.Lock()
    _tl = threading.local()

    def _sess():
        if not hasattr(_tl, 's'):
            _tl.s = requests.Session()
        return _tl.s

    def _fetch(args):
        url, movie, cache_key = args
        tmdb = get_tmdb_data_sync(_sess(), movie['search'], movie['year'])
        with count_lock:
            completed_count[0] += 1
        return url, cache_key, tmdb

    if total_fetch > 0:
        pDialog.update(35, f'TMDB: 0 / {total_fetch}...')
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_map = {executor.submit(_fetch, args): args for args in to_fetch}
            for future in as_completed(future_map):
                if pDialog.iscanceled():
                    executor.shutdown(wait=False, cancel_futures=True)
                    pDialog.close()
                    return
                url, cache_key, tmdb = future.result()
                tmdb_results[url] = (cache_key, tmdb)
                done = completed_count[0]
                if done % 10 == 0 or done == total_fetch:
                    pct = 35 + int((done / total_fetch) * 57)
                    pDialog.update(pct, f'TMDB: {done} / {total_fetch}...')

    pDialog.update(94, 'Speichere in Datenbank...')
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("DELETE FROM film_list")
            for url, (cache_key, tmdb) in tmdb_results.items():
                movie = results_map[url]
                if tmdb:
                    movie['plot'] = tmdb['plot']
                    movie['rating'] = tmdb['rating']
                    movie['genres_list'] = tmdb['genres_list']
                    movie['thumb'] = tmdb['poster']
                    conn.execute(
                        "INSERT OR REPLACE INTO movie_cache VALUES (?,?,?,?,?,?)",
                        (cache_key, tmdb['plot'], tmdb['rating'], tmdb['poster'], tmdb['poster'], json.dumps(tmdb['genres_list']))
                    )
            for url, movie in results_map.items():
                conn.execute(
                    "INSERT OR REPLACE INTO film_list VALUES (?,?,?,?,?,?)",
                    (hashlib.md5(url.encode()).hexdigest(), movie['title'], url,
                     movie['search'], str(movie['year']), json.dumps(movie['genres_list']))
                )
            conn.commit()
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] DB Speicherfehler: {e}", xbmc.LOGERROR)

    pDialog.close()
    xbmcgui.Dialog().notification('GEZ Kino', 'Datenbank erfolgreich aktualisiert!', xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin('Container.Refresh')

def hole_lokale_filme_aus_db(genre_filter, suchbegriff_suche=None, start_char=None, year_filter=None):
    filme_liste = []
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='film_list'")
            if not c.fetchone():
                return None
            rows = conn.execute("""
                SELECT f.title, f.video_url, f.search_name, f.year, f.genres_json, c.local_poster, c.plot, c.rating
                FROM film_list f
                LEFT JOIN movie_cache c ON (f.search_name || '_' || f.year) = c.search_title
            """).fetchall()
            if not rows:
                return None
            for r in rows:
                g_list = json.loads(r[4])
                is_tv = 'Live-TV' in g_list
                title = r[0]
                film_year = r[3]
                
                if suchbegriff_suche and suchbegriff_suche.lower() not in title.lower():
                    continue
                if start_char:
                    first_char = title[0].upper()
                    if start_char == '#':
                        if first_char.isalpha():
                            continue
                    else:
                        if first_char != start_char:
                            continue
                
                if year_filter:
                    if film_year != year_filter:
                        continue

                if genre_filter != 'AZ' and genre_filter != 'YEAR':
                    if genre_filter == 'Live-TV':
                        if not is_tv: continue
                    elif genre_filter == 'Alle':
                        if is_tv: continue
                    elif genre_filter == 'Sonstige':
                        if is_tv or (g_list and g_list != ['Mediathek']): continue
                    else:
                        if genre_filter not in g_list: continue
                
                filme_liste.append({
                    "title": title, "url": r[1], "desc": r[6] if r[6] else 'Keine Beschreibung.',
                    "rating": r[7] if r[7] else 'N/A', "thumb": r[5] if r[5] else '', "genres": g_list,
                    "year": film_year
                })
        
        filme_liste.sort(key=lambda x: x['title'].lower())
        return filme_liste
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] DB Ladefehler: {e}", xbmc.LOGERROR)
        return []

def zeige_hauptmenue():
    p_icon1 = os.path.join(MEDIA_DIR, "icon1.png")
    p_icon2 = os.path.join(MEDIA_DIR, "icon2.png")
    p_icon3 = os.path.join(MEDIA_DIR, "icon3.png")
    p_icon4 = os.path.join(MEDIA_DIR, "icon4.png")
    p_icon5 = os.path.join(MEDIA_DIR, "icon5.png")
    p_icon6 = os.path.join(MEDIA_DIR, "icon6.png")    
    li1 = xbmcgui.ListItem(label="[ Alle Spielfilme ]")
    li1.setInfo('video', {'title': "Alle Spielfilme", 'plot': "Zeigt die komplette Liste vieler Spielfilme aus den öffentlich-rechtlichen Mediatheken an. Komplett alphabetisch sortiert."})
    li1.setArt({'icon': p_icon1, 'thumb': p_icon1})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=list&query=Alle", listitem=li1, isFolder=True)
    
    li_az = xbmcgui.ListItem(label="[ Filme A-Z ]")
    li_az.setInfo('video', {'title': "Filme A-Z", 'plot': "Durchsuche die Filmliste alphabetisch."})
    li_az.setArt({'icon': p_icon5, 'thumb': p_icon5})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=az_menu", listitem=li_az, isFolder=True)
    
    li_year = xbmcgui.ListItem(label="[ Nach Jahren sortiert... ]")
    li_year.setInfo('video', {'title': "Nach Jahren sortiert", 'plot': "Zeigt die Filme nach Produktionsjahren gruppiert an."})
    li_year.setArt({'icon': p_icon6, 'thumb': p_icon6})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=years_menu", listitem=li_year, isFolder=True)

    li2 = xbmcgui.ListItem(label="[ Nach Genres filtern... ]")
    li2.setInfo('video', {'title': "Nach Genres filtern", 'plot': "Öffnet das Genre-Menü. Hier kannst du gezielt nach Kategorien wie Krimi, Action, Drama, Komödien oder Dokumentationen filtern."})
    li2.setArt({'icon': p_icon2, 'thumb': p_icon2})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=genres_menu", listitem=li2, isFolder=True)
    
    li3 = xbmcgui.ListItem(label="[ Film suchen... ]")
    li3.setInfo('video', {'title': "Film suchen", 'plot': "Öffnet eine Tastatur, um die lokale Datenbank gezielt nach einem bestimmten Filmtitel oder Suchbegriff zu durchsuchen."})
    li3.setArt({'icon': p_icon3, 'thumb': p_icon3})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=search", listitem=li3, isFolder=True)
    
    li4 = xbmcgui.ListItem(label="[ Mediathek Datenbank aktualisieren ]")
    li4.setInfo('video', {'title': "Datenbank aktualisieren", 'plot': "Startet den Suchlauf. Lädt frische Filme aus den Mediatheken."})
    li4.setArt({'icon': p_icon4, 'thumb': p_icon4})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=sync", listitem=li4, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_az_menue():
    buchstaben = ['#'] + list(string.ascii_uppercase)
    for buchstabe in buchstaben:
        url = f"{BASE_URL}?action=list&query=AZ&char={buchstabe}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=buchstabe), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_jahre_menue():
    jahre = []
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            rows = c.execute("SELECT DISTINCT year FROM film_list WHERE year IS NOT NULL AND year != ''").fetchall()
            jahre = [r[0] for r in rows]
            jahre.sort(reverse=True)
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Fehler beim Laden der Jahre: {e}", xbmc.LOGERROR)

    if not jahre:
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=xbmcgui.ListItem(label="Keine Jahresdaten gefunden. Bitte DB aktualisieren."), isFolder=False)
    else:
        for jahr in jahre:
            url = f"{BASE_URL}?action=list&query=YEAR&year={jahr}"
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=f"Jahr {jahr}"), isFolder=True)
            
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_genre_menue():
    genres = [
        ("Live-TV", "Live-TV"), ("Action", "Action"),
        ("Abenteuer", "Abenteuer"), ("Animation", "Animation"), ("Komoedien", "Komödie"),
        ("Krimi", "Krimi"), ("Dokumentationen", "Doku"), ("Dramen", "Drama"),
        ("Familie", "Familie"), ("Fantasy", "Fantasy"), ("Historie", "Historie"),
        ("Horror", "Horror"), ("Musik", "Musik"), ("Mystery", "Mystery"),
        ("Liebesfilme und Romantik", "Romanze"), ("Science Fiction", "Sci-Fi"),
        ("TV-Film", "TV-Film"), ("Thriller", "Thriller"), ("Krieg", "Krieg"),
        ("Western", "Western"), ("Sonstige (Unkategorisiert)", "Sonstige")
    ]
    for label, internal_name in genres:
        url = f"{BASE_URL}?action=list&query={urllib.parse.quote_plus(internal_name)}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=label), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_filmliste(genre_query, search_str=None, start_char=None, year_filter=None):
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    filme = hole_lokale_filme_aus_db(genre_query, suchbegriff_suche=search_str, start_char=start_char, year_filter=year_filter)
    if filme is None:
        if xbmcgui.Dialog().yesno("Datenbank leer", "Die lokale Datenbank ist leer. Jetzt aktualisieren?"):
            aktualisiere_datenbank()
            filme = hole_lokale_filme_aus_db(genre_query, suchbegriff_suche=search_str, start_char=start_char, year_filter=year_filter)
        else:
            filme = []
    if not filme:
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=xbmcgui.ListItem(label="Keine Filme gefunden."), isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for film in filme:
        display_label = film['title']
        if film['year']:
            display_label += f" ({film['year']})"
        if film['rating'] and film['rating'] not in ['N/A', 'LIVE']:
            display_label += f" [★ {film['rating']}]"
        li = xbmcgui.ListItem(label=display_label)
        li.setInfo('video', {
            'title': film['title'], 'plot': film['desc'],
            'genre': ", ".join(film['genres']),
            'year': int(film['year']) if film['year'] and film['year'].isdigit() else 0,
            'rating': float(film['rating']) if film['rating'] not in ['N/A', 'LIVE'] else 0.0
        })
        art_dict = {}
        if film['thumb']:
            art_dict['poster'] = film['thumb']
            art_dict['thumb'] = film['thumb']
            art_dict['icon'] = film['thumb']
            art_dict['fanart'] = film['thumb']
        li.setArt(art_dict)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=film['url'], listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

action = ARGS.get('action', [None])[0]
query = ARGS.get('query', [None])[0]
char = ARGS.get('char', [None])[0]
year_param = ARGS.get('year', [None])[0]

if action == 'list' and query == 'AZ':
    zeige_filmliste('AZ', start_char=char)
elif action == 'list' and query == 'YEAR':
    zeige_filmliste('YEAR', year_filter=year_param)
elif action == 'list' and query:
    zeige_filmliste(query)
elif action == 'az_menu':
    zeige_az_menue()
elif action == 'years_menu':
    zeige_jahre_menue()
elif action == 'genres_menu':
    zeige_genre_menue()
elif action == 'sync':
    aktualisiere_datenbank()
elif action == 'search':
    kb = xbmc.Keyboard('', 'Film suchen...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        zeige_filmliste('Alle', search_str=kb.getText())
else:
    zeige_hauptmenue()
