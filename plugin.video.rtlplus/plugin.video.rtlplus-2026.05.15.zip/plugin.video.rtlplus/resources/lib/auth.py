import json 
import os 
import time 
import uuid 
import hashlib 
import hmac 
import urllib .request 
import binascii 
import zlib 
import xbmcaddon 
import xbmcvfs 
import xbmc 
import xbmcgui 
_addon =xbmcaddon .Addon ()
_addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))

try :
    from resources .lib .evil import gui as evil_gui 
    from resources .lib .evil .gui import Item as EvilItem 
    _EVIL_AVAILABLE =True 
except Exception :
    _EVIL_AVAILABLE =False 

ADDON =xbmcaddon .Addon ()
ADDON_ID =ADDON .getAddonInfo ('id')
PROFILE_PATH =xbmcvfs .translatePath (ADDON .getAddonInfo ('profile'))

TOKEN_FILE =os .path .join (PROFILE_PATH ,'tokens.json')

AUTH_BASE ='https://auth.rtl.de/auth/realms/rtlplus/protocol/openid-connect'
CLIENT_ID ='bedrock-m6group_web'
REDIRECT_URI ='https://plus.rtl.de/silent-sso-iframe.html'

FRONT_AUTH_URL ='https://front-auth.rtlde.bedrock.tech/v2/rtlde/platforms/m6group_web/token'

CLIENT_RELEASE ='6.41.2'
USER_AGENT =('Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
'(KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36')

def _log (msg ):
    xbmc .log (f'[RTL+ Auth] {msg }',xbmc .LOGDEBUG )
def _img (fname ):
            return os .path .join (_addon_path ,'resources','media',fname )

class RTLAuth :
    def __init__ (self ):
        os .makedirs (PROFILE_PATH ,exist_ok =True )
        self ._tokens =self ._load_tokens ()

    def _load_tokens (self ):
        try :
            if os .path .exists (TOKEN_FILE ):
                with open (TOKEN_FILE ,'r')as f :
                    raw =json .load (f )
                if raw .get ('__locked__'):
                    try :
                        return json .loads (_decrypt_tokens (raw ['data']))
                    except Exception as e :
                        _log (f'GERÄTEBINDUNG fehlgeschlagen: {e }')
                        xbmcgui .Dialog ().notification (
                        'RTL+','Token ungültig für dieses Gerät – bitte neu anmelden',
                        xbmcgui .NOTIFICATION_ERROR ,5000 )
                        os .remove (TOKEN_FILE )
                        return {}
                return raw 
        except Exception as e :
            _log (f'Load tokens error: {e }')
        return {}

    def _save_tokens (self ):
        try :
            payload =json .dumps (self ._tokens )
            wrapper ={'__locked__':True ,'data':_encrypt_tokens (payload )}
            with open (TOKEN_FILE ,'w')as f :
                json .dump (wrapper ,f )
        except Exception as e :
            _log (f'Save tokens error: {e }')

    def logout (self ):
        self ._tokens ={}
        if os .path .exists (TOKEN_FILE ):
            os .remove (TOKEN_FILE )

    def invalidate_tokens (self ):
        for key in ('access_token','oidc_expires','bedrock_token','bedrock_expires'):
            self ._tokens .pop (key ,None )
        self ._save_tokens ()
        _log ('Tokens invalidated – will refresh on next request')

    def get_device_id (self ):
        if 'device_id'not in self ._tokens :
            self ._tokens ['device_id']='_luid_'+str (uuid .uuid4 ())
            self ._save_tokens ()
        return self ._tokens ['device_id']

    def get_oidc_token (self ):
        import requests 
        now =time .time ()

        if (self ._tokens .get ('access_token')and 
        self ._tokens .get ('oidc_expires',0 )>now +300 ):
            return self ._tokens ['access_token']

        refresh_expires =self ._tokens .get ('oidc_refresh_expires',0 )
        if refresh_expires and refresh_expires <now +300 :
            _log ('Refresh-Token läuft bald ab – direkt silent re-login')
            self ._tokens .pop ('refresh_token',None )
            token =self ._silent_relogin ()
            if token :
                return token 
            return self ._login ()

        refresh_token =self ._tokens .get ('refresh_token','')
        if refresh_token :
            _log ('Attempting OIDC token refresh...')
            try :
                resp =requests .post (
                f'{AUTH_BASE }/token',
                data ={
                'client_id':CLIENT_ID ,
                'grant_type':'refresh_token',
                'refresh_token':refresh_token ,
                },
                headers ={'User-Agent':USER_AGENT },
                timeout =15 
                )
                if resp .status_code ==200 :
                    data =resp .json ()
                    self ._tokens ['access_token']=data ['access_token']
                    self ._tokens ['refresh_token']=data .get ('refresh_token',refresh_token )
                    self ._tokens ['oidc_expires']=now +data .get ('expires_in',3600 )
                    self ._tokens ['oidc_refresh_expires']=now +data .get ('refresh_expires_in',86400 )
                    self ._tokens .pop ('bedrock_token',None )
                    self ._tokens .pop ('bedrock_expires',None )
                    self ._save_tokens ()
                    _log ('OIDC token refreshed successfully')
                    return self ._tokens ['access_token']
                else :
                    _log (f'Refresh token rejected (HTTP {resp .status_code }) - will re-login silently')

                    self ._tokens .pop ('refresh_token',None )
                    self ._tokens .pop ('oidc_refresh_expires',None )
                    self ._save_tokens ()
            except Exception as e :
                _log (f'Refresh error: {e }')

        _log ('No valid token - attempting silent re-login')
        token =self ._silent_relogin ()
        if token :
            return token 

        return self ._login ()

    def _silent_relogin (self ):
        import requests 
        username =ADDON .getSetting ('username')
        password =ADDON .getSetting ('password')
        if not username or not password :
            _log ('Silent re-login skipped: no saved credentials')
            return None 

        _log (f'Silent re-login for {username }')
        try :
            code_verifier =uuid .uuid4 ().hex +uuid .uuid4 ().hex 
            import base64 as _b64 ,hashlib as _hl 
            code_challenge =_b64 .urlsafe_b64encode (
            _hl .sha256 (code_verifier .encode ()).digest ()
            ).rstrip (b'=').decode ()

            session =requests .Session ()
            session .headers ['User-Agent']=USER_AGENT 

            r1 =session .get (
            f'{AUTH_BASE }/auth',
            params ={
            'response_type':'code',
            'client_id':CLIENT_ID ,
            'redirect_uri':REDIRECT_URI ,
            'code_challenge':code_challenge ,
            'code_challenge_method':'S256',
            'scope':'openid',
            },
            allow_redirects =True ,
            timeout =15 
            )

            import re as _re 
            action_match =_re .search (r'action="([^"]+)"',r1 .text )
            if not action_match :
                _log ('Silent re-login: login form not found')
                return None 

            action_url =action_match .group (1 ).replace ('&amp;','&')

            r2 =session .post (
            action_url ,
            data ={'username':username ,'password':password ,'credentialId':''},
            allow_redirects =False ,
            timeout =15 
            )

            location =r2 .headers .get ('Location','')
            code_match =_re .search (r'code=([^&]+)',location )
            if not code_match :
                _log (f'Silent re-login: no auth code in redirect ({location [:100 ]})')
                return None 

            r3 =session .post (
            f'{AUTH_BASE }/token',
            data ={
            'client_id':CLIENT_ID ,
            'grant_type':'authorization_code',
            'code':code_match .group (1 ),
            'code_verifier':code_verifier ,
            'redirect_uri':REDIRECT_URI ,
            },
            timeout =15 
            )
            r3 .raise_for_status ()
            data =r3 .json ()

            now =time .time ()
            self ._tokens ['access_token']=data ['access_token']
            self ._tokens ['refresh_token']=data .get ('refresh_token','')
            self ._tokens ['oidc_expires']=now +data .get ('expires_in',3600 )
            self ._tokens ['oidc_refresh_expires']=now +data .get ('refresh_expires_in',86400 )

            try :
                payload =data ['access_token'].split ('.')[1 ]
                payload +='='*(-len (payload )%4 )
                import base64 as _b64j ,json as _json 
                jwt_data =_json .loads (_b64j .b64decode (payload ))
                parts =jwt_data .get ('sub','').split (':')
                self ._tokens ['gigya_uid']=parts [-1 ]if parts else ''
            except Exception as je :
                _log (f'Silent re-login JWT parse: {je }')
                self ._tokens ['gigya_uid']=''

            self ._tokens .pop ('bedrock_token',None )
            self ._tokens .pop ('bedrock_expires',None )
            self ._save_tokens ()
            _log ('Silent re-login successful')
            return self ._tokens ['access_token']

        except Exception as e :
            _log (f'Silent re-login error: {e }')
            return None 

    def download_accounts (self ):
        passw =''
        username =''
        userpass =''
        jsonData ={"js":[{"name":"Hier Anmelden","pass":"","username":"","password":""}]}

        return jsonData 

    def select_and_save_credentials (self ):

        jsonData =[{"name":"Hier anmelden","pass":"","username":"","password":"",'icon':_img ('icon.png')}]

        Name =[]
        Username =[]
        Password =[]
        Passw =[]
        Icon =[]

        for i in jsonData :
            name =i .get ('name','?')
            username =i .get ('username','')
            password =i .get ('password','')
            passw =i .get ('pass','')
            try :
                icon =i ['icon']
            except Exception :
                icon =''

            Username .append (username )
            Password .append (password )
            Passw .append (passw )
            if passw !='':
                name =name +' [Pin Safe]'
            Name .append (name )
            Icon .append (icon )

        names =Name 
        userlist =Username 
        passlist =Password 
        pinlist =Passw 

        if _EVIL_AVAILABLE :
            _options =[]
            for i ,name in enumerate (names ):
                _options .append (EvilItem (label =name ,art ={'thumb':Icon [i ]}if Icon [i ]else {}))
            index =evil_gui .select ('RTL+ Zugang wählen',options =_options ,useDetails =True )
        else :
            index =xbmcgui .Dialog ().select ('RTL+ Zugang wählen',names )
        if index <0 :
            return None ,None 

        username =userlist [index ]
        password =passlist [index ]
        pin =pinlist [index ]

        if not username :
            kb =xbmc .Keyboard ('','RTL+ E-Mail')
            kb .doModal ()
            if not kb .isConfirmed ():
                return None ,None 
            username =kb .getText ().strip ()

            kb2 =xbmc .Keyboard ('','RTL+ Passwort',True )
            kb2 .doModal ()
            if not kb2 .isConfirmed ():
                return None ,None 
            password =kb2 .getText ().strip ()
            pin =''

        if pin :
            while True :
                kb_pin =xbmc .Keyboard ('','User PIN',True )
                kb_pin .doModal ()
                if not kb_pin .isConfirmed ():
                    return None ,None 
                if kb_pin .getText ()==pin :
                    break 
                xbmcgui .Dialog ().notification ('RTL+','Falscher PIN',xbmcgui .NOTIFICATION_ERROR ,2000 )

        ADDON .setSetting ('username',username )
        ADDON .setSetting ('password',password )
        _log (f'select_and_save_credentials: Konto "{names [index ]}" gewählt')
        return username ,password 

    def _login (self ):
        import requests 

        username =ADDON .getSetting ('username')
        password =ADDON .getSetting ('password')

        if not username or not password :

            username ,password =self .select_and_save_credentials ()
            if not username or not password :
                return None 

        _log (f'Logging in as {username }...')

        code_verifier =uuid .uuid4 ().hex +uuid .uuid4 ().hex 
        import base64 ,hashlib 
        code_challenge =base64 .urlsafe_b64encode (
        hashlib .sha256 (code_verifier .encode ()).digest ()
        ).rstrip (b'=').decode ()

        session =requests .Session ()
        session .headers ['User-Agent']=USER_AGENT 

        try :
            r1 =session .get (
            f'{AUTH_BASE }/auth',
            params ={
            'response_type':'code',
            'client_id':CLIENT_ID ,
            'redirect_uri':REDIRECT_URI ,
            'code_challenge':code_challenge ,
            'code_challenge_method':'S256',
            'scope':'openid',
            },
            allow_redirects =True ,
            timeout =15 
            )
        except Exception as e :
            _log (f'Auth page error: {e }')
            return None 

        import re 
        action_match =re .search (r'action="([^"]+)"',r1 .text )
        if not action_match :
            _log ('Could not find login form action')
            return None 

        action_url =action_match .group (1 ).replace ('&amp;','&')

        try :
            r2 =session .post (
            action_url ,
            data ={
            'username':username ,
            'password':password ,
            'credentialId':'',
            },
            allow_redirects =False ,
            timeout =15 
            )
        except Exception as e :
            _log (f'Login POST error: {e }')
            return None 

        location =r2 .headers .get ('Location','')
        code_match =re .search (r'code=([^&]+)',location )
        if not code_match :
            _log (f'No code in redirect: {location [:200 ]}')
            _log ('Login fehlgeschlagen - Zugangsdaten pruefen')
            return None 

        code =code_match .group (1 )

        try :
            r3 =session .post (
            f'{AUTH_BASE }/token',
            data ={
            'client_id':CLIENT_ID ,
            'grant_type':'authorization_code',
            'code':code ,
            'code_verifier':code_verifier ,
            'redirect_uri':REDIRECT_URI ,
            },
            timeout =15 
            )
            r3 .raise_for_status ()
            data =r3 .json ()
        except Exception as e :
            _log (f'Token exchange error: {e }')
            return None 

        now =time .time ()
        self ._tokens ['access_token']=data ['access_token']
        self ._tokens ['refresh_token']=data .get ('refresh_token','')
        self ._tokens ['oidc_expires']=now +data .get ('expires_in',3600 )
        self ._tokens ['oidc_refresh_expires']=now +data .get ('refresh_expires_in',86400 )

        try :
            import base64 
            payload =data ['access_token'].split ('.')[1 ]
            payload +='='*(-len (payload )%4 )
            jwt_data =json .loads (base64 .b64decode (payload ))
            self ._tokens ['gigya_uid']=jwt_data .get ('sub','').split (':')[-1 ]

            parts =jwt_data .get ('sub','').split (':')
            if len (parts )>=3 :
                self ._tokens ['gigya_uid']=parts [-1 ]
            else :
                self ._tokens ['gigya_uid']=parts [-1 ]if parts else ''
        except Exception as e :
            _log (f'JWT parse error: {e }')
            self ._tokens ['gigya_uid']=''

        self ._tokens .pop ('bedrock_token',None )
        self ._tokens .pop ('bedrock_expires',None )

        self ._save_tokens ()
        _log (f'Login OK, gigya_uid={self ._tokens .get ("gigya_uid")}')
        return self ._tokens ['access_token']

    def get_bedrock_token (self ):
        import requests 
        now =time .time ()

        if (self ._tokens .get ('bedrock_token')and 
        self ._tokens .get ('bedrock_expires',0 )>now +300 ):
            return self ._tokens ['bedrock_token']

        access_token =self .get_oidc_token ()
        if not access_token :
            return None 

        gigya_uid =self ._tokens .get ('gigya_uid','')
        device_id =self .get_device_id ()
        profile_id =self ._tokens .get ('profile_id','')

        ts =int (now )
        auth_token =hmac .new (
        gigya_uid .encode ()if gigya_uid else b'',
        str (ts ).encode (),
        hashlib .sha1 
        ).hexdigest ()if gigya_uid else ''

        headers ={
        'Authorization':f'Bearer {access_token }',
        'x-auth-device-name':'Android - Samsung Internet',
        'x-auth-gigya-uid':gigya_uid ,
        'x-auth-token-timestamp':str (ts ),
        'x-auth-token':auth_token ,
        'x-auth-profile-id':profile_id ,
        'x-auth-device-id':device_id ,
        'x-auth-device-player-size-width':'1920',
        'x-auth-device-player-size-height':'1080',
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'request-timeout':'10000',
        'User-Agent':USER_AGENT ,
        'Origin':'https://plus.rtl.de',
        'Referer':'https://plus.rtl.de/',
        'Accept':'*/*',
        }

        _log ('Getting Bedrock token...')
        try :
            resp =requests .get (FRONT_AUTH_URL ,headers =headers ,timeout =15 )
            resp .raise_for_status ()
            data =resp .json ()
            bedrock_token =data .get ('token','')
            if not bedrock_token :
                _log (f'No bedrock token in response: {data }')
                return self ._tokens .get ('guest_bedrock_token') or None 

            self ._tokens ['bedrock_token']=bedrock_token 
            self ._tokens ['bedrock_expires']=now +86000 
            self ._save_tokens ()
            _log ('Bedrock token OK')
            return bedrock_token 

        except Exception as e :
            _log (f'Bedrock token error: {e } - using guest_bedrock_token fallback')
            return self ._tokens .get ('guest_bedrock_token') or None 

    def get_gigya_uid (self ):
        uid =self ._tokens .get ('gigya_uid','')
        if uid :
            return uid
        import base64 ,json as _json
        at =self ._tokens .get ('access_token','')
        if at :
            try :
                parts =at .split ('.')
                payload =parts [1 ]+'=' *(-len (parts [1 ])%4 )
                sub =_json .loads (base64 .b64decode (payload )).get ('sub','')
                uid =sub .split (':')[-1 ]if sub else ''
                if uid :
                    self ._tokens ['gigya_uid']=uid
                    self ._save_tokens ()
                return uid
            except Exception :
                pass
        return ''

    def ensure_profile_id (self ):
        if self ._tokens .get ('profile_id'):
            return 
        try :
            access_token =self .get_oidc_token ()
            self .get_profile_id (access_token =access_token )
            if self ._tokens .get ('profile_id'):
                self ._tokens .pop ('bedrock_token',None )
                self ._tokens .pop ('bedrock_expires',None )
                _log ('ensure_profile_id: bedrock invalidated for re-fetch with profile_id')
        except Exception as e :
            _log (f'ensure_profile_id error: {e }')

    def get_profile_id (self ,access_token =None ):
        if self ._tokens .get ('profile_id'):
            return self ._tokens ['profile_id']

        import requests 
        gigya_uid =self .get_gigya_uid ()
        if not gigya_uid :
            return ''

        if not access_token :
            access_token =self .get_oidc_token ()

        try :
            bedrock =self .get_bedrock_token ()
            resp =requests .get (
            f'https://users.rtlde.bedrock.tech/v2/platforms/m6group_web/users/{gigya_uid }/profiles',
            headers ={
            'Authorization':f'Bearer {access_token }',
            'x-bedrock-token':bedrock or '',
            'User-Agent':USER_AGENT ,
            'Origin':'https://plus.rtl.de',
            'Referer':'https://plus.rtl.de/',
            },
            timeout =10 
            )
            profiles =resp .json ()
            if profiles :
                self ._tokens ['profile_id']=profiles [0 ].get ('uid','')
                self ._save_tokens ()
                return self ._tokens ['profile_id']
        except Exception as e :
            _log (f'Profile error: {e }')
        return ''

    def get_drm_token (self ,service_code ,content_type ,content_id ):
        import requests 
        if content_type =='live':
            self .ensure_profile_id ()
        access_token =self .get_oidc_token ()
        bedrock_token =self .get_bedrock_token ()or self .get_guest_bedrock_token ()
        gigya_uid =self .get_gigya_uid ()
        _log (f'get_drm_token: gigya_uid={gigya_uid } bedrock={"OK" if bedrock_token else "LEER"}')

        if not gigya_uid :
            _log ('get_drm_token: gigya_uid leer - kein DRM-Token moeglich')
            return None 

        if content_type =='video':
            url =(f'https://drm.rtlde.bedrock.tech/v1/customers/rtlde/platforms/m6group_web'
            f'/services/{service_code }/users/{gigya_uid }/videos/{content_id }/upfront-token')
        else :
            url =(f'https://drm.rtlde.bedrock.tech/v1/customers/rtlde/platforms/m6group_web'
            f'/services/{service_code }/users/{gigya_uid }/live/{content_id }/upfront-token')

        headers ={
        'Authorization':f'Bearer {access_token }',
        'x-bedrock-token':bedrock_token or '',
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'request-timeout':'10000',
        'User-Agent':USER_AGENT ,
        'Origin':'https://plus.rtl.de',
        'Referer':'https://plus.rtl.de/',
        'Accept':'*/*',
        }

        try :
            resp =requests .get (url ,headers =headers ,timeout =15 )
            resp .raise_for_status ()
            data =resp .json ()
            return data .get ('token','')
        except Exception as e :
            _log (f'DRM token error: {e }')
            return None 

    def is_premium (self ):
        import requests 
        import time as _time 

        cached =self ._tokens .get ('_premium_status')
        cached_ts =self ._tokens .get ('_premium_status_ts',0 )
        if cached is not None and (_time .time ()-cached_ts )<21600 :
            return bool (cached )

        access_token =self .get_oidc_token ()
        gigya_uid =self .get_gigya_uid ()
        if not access_token or not gigya_uid :
            return False 

        bedrock_token =self .get_bedrock_token ()
        if not bedrock_token :
            _log ('is_premium: kein Bedrock-Token – abbruch')
            if cached is not None :
                return bool (cached )
            return False 

        url =(f'https://stores.rtlde.bedrock.tech/premium/v4/customers/rtlde'
        f'/platforms/m6group_web/users/{gigya_uid }/subscriptions')
        headers ={
        'Authorization':f'Bearer {access_token }',
        'x-bedrock-token':bedrock_token ,
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'User-Agent':USER_AGENT ,
        'Origin':'https://plus.rtl.de',
        'Referer':'https://plus.rtl.de/',
        }
        try :
            resp =requests .get (url ,headers =headers ,timeout =10 )
            resp .raise_for_status ()
            if resp .status_code ==204 or not resp .content :
                _log ('is_premium: HTTP 204 No Content – Server hat keinen Body gesendet')
                if cached is not None :
                    _log (f'is_premium: verwende gecachten Wert: {bool (cached )}')
                    return bool (cached )
                return False 
            data =resp .json ()
            result =False 
            offer_code =''
            for sub in (data .get ('current',[])or []):
                offer_code =(sub .get ('offer',{})or {}).get ('code','')
                if offer_code .startswith ('PM'):
                    result =True 
                    break 
            self ._tokens ['_premium_status']=result 
            self ._tokens ['_premium_status_ts']=_time .time ()
            self ._save_tokens ()
            _log (f'is_premium={result } (offer={offer_code if result else "none"})')
            return result 
        except Exception as e :
            _log (f'is_premium check error: {e }')
            return False 

    _GUEST_RT = (
        'eyJhbGciOiJIUzUxMiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIwYzcxYzJlNC1lMzIzLTQwNWQtYmUyNS00MTEzOWRhOGE2Y2IifQ.eyJleHAiOjE3ODY0O'
        'DE0ODYsImlhdCI6MTc3ODcwNTQ4NiwianRpIjoiZjI3ODg2YTQtMmZmMi1iNDg2LTQ2ODUtODc4OThlYmNkYTQ2IiwiaXNzIjoiaHR0cHM6Ly9hdXRoLnJ0b'
        'C5kZS9hdXRoL3JlYWxtcy9ydGxwbHVzIiwiYXVkIjoiaHR0cHM6Ly9hdXRoLnJ0bC5kZS9hdXRoL3JlYWxtcy9ydGxwbHVzIiwic3ViIjoiZjo4M2EyZTIyN'
        'y1mMjdkLTRkMzMtYTgxMS0zM2FkNTg4MTcwYzQ6MTA1Njg5MTc1MyIsInR5cCI6IlJlZnJlc2giLCJhenAiOiJiZWRyb2NrLW02Z3JvdXBfd2ViIiwic2lkI'
        'joiZTJfTTEySGlMMnM0dThsdmRZejl5Z2F0Iiwic2NvcGUiOiJvcGVuaWQgbGltaXRQcm9maWxlIGJlZHJvY2sgYmFzaWMgd2ViLW9yaWdpbnMgcHJvZmlsZ'
        'SBlbWFpbCJ9.adx10lkkm93C_aFaB5n8rXqBCJ7mTqMurSpPCIgbJEaTEShiM_JRKbfaXPxZNs9XgdUjbrXc9xvHCkvfrtkL-w'
    )
    _GUEST_AT = (
        'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJ4N1RJT2o1bXd3T0daLS1fOVdjcmhDbzdHemVCTDgwOWQxZlByN29wUThBIn0.eyJleHAi'
        'OjE3Nzg4MzUwODYsImlhdCI6MTc3ODcwNTQ4NiwiYXV0aF90aW1lIjoxNzc4NzAyNjUxLCJqdGkiOiJvbnJ0YWM6ZDNlNmVlNGUtMzc1Ni1mY2UzLTA3YjIt'
        'Y2U3NjBlNWI5ZWIyIiwiaXNzIjoiaHR0cHM6Ly9hdXRoLnJ0bC5kZS9hdXRoL3JlYWxtcy9ydGxwbHVzIiwic3ViIjoiZjo4M2EyZTIyNy1mMjdkLTRkMzMt'
        'YTgxMS0zM2FkNTg4MTcwYzQ6MTA1Njg5MTc1MyIsInR5cCI6IkJlYXJlciIsImF6cCI6ImJlZHJvY2stbTZncm91cF93ZWIiLCJzaWQiOiJlMl9NMTJIaUwy'
        'czR1OGx2ZFl6OXlnYXQiLCJhbGxvd2VkLW9yaWdpbnMiOlsiaHR0cHM6Ly9wbHVzLnJ0bC5kZSIsImh0dHBzOi8vcnRsZGUtZnJvbnQuc3RhZ2luZy5ydGxk'
        'ZS5iZWRyb2NrLnRlY2giLCJodHRwczovL2JldGEucGx1cy5ydGwuZGUiLCJodHRwczovL3J0bHBsdXMtZnJvbnQucnRsZGUuYmVkcm9jay50ZWNoIl0sInNj'
        'b3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwiLCJjb3VudHJ5IjoiREUiLCJ1aWQiOjEwNTY4OTE3NTMsImJpcnRoZGF0ZSI6IjE5NTgtMDItMjAiLCJlbWFp'
        'bF92ZXJpZmllZCI6dHJ1ZSwiZ2VuZGVyIjoiZmVtYWxlIiwibmFtZSI6IkNhcm1lbiBUcsO2bGxlciIsImxpbWl0UHJvZmlsZSI6dHJ1ZSwicHJlZmVycmVk'
        'X3VzZXJuYW1lIjoiY2FybWVuLXRyb2VsbGVyQHQtb25saW5lLmRlIiwiZ2l2ZW5fbmFtZSI6IkNhcm1lbiIsImZhbWlseV9uYW1lIjoiVHLDtmxsZXIiLCJl'
        'bWFpbCI6ImNhcm1lbi10cm9lbGxlckB0LW9ubGluZS5kZSJ9.Ipl6HOtu936ItID4nz8G1MaDfIWw_nXc3j5PoXC3BeIjzueLSocY8476E4ub39_TEGL8UUq'
        '7bvPEoTBybTVQSusrpIgEUmG3EHx7cMwBQgb7g_ihCRdImK-8-3PYeHfESaNnSJiT7r9Ix4RVrEwYh0vXnzztM7WudFh7JBSuLjuG7ptzhautqLd8jugOYkC'
        '7Qbi2H_4MPwebGN54F--BklB7ggWsXVqWTywmRpgR4d3P-LqQCPli8JTV_bR1yJFcO0tf7bk0TYK95ZS5nmg2mAJV08l-pfkMruMEUH9POq2pZPhWB39ifmd'
        '2gjsiy0EV-L1xpQgZWGdw6qex0JdOCA'
    )
    _GUEST_DID = '_luid_cab52d96-5153-4111-bc06-dc279e4c2e14'
    _GUEST_BT = (
        'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJodHRwczovL2Zyb250LWF1dGgucnRsZGUuYmVkcm9jay50ZWNoL3YyL3Rva2VuIiwiaWF0Ijo'
        'xNzc4NzA1NDg3LCJuYmYiOjE3Nzg3MDU0ODcsImV4cCI6MTc3ODc5MTg4NywiYXV0aF9tZXRob2QiOiJzaWduYXR1cmUiLCJwbGF0Zm9ybSI6Im02Z3JvdXB'
        'fd2ViIiwiY3VzdG9tZXIiOiJydGxkZSIsImFjY291bnRpZCI6IjEwNTY4OTE3NTMiLCJnaWd5YSI6IjEwNTY4OTE3NTMiLCJkZXZpY2VpZCI6Im02Z3JvdXB'
        'fd2VifF9sdWlkX2NhYjUyZDk2LTUxNTMtNDExMS1iYzA2LWRjMjc5ZTRjMmUxNCIsInByb2ZpbGVpZCI6IjA1YWRiZGUxOWI1YTQzOGFiMDQ5NDA0NWJkODd'
        'lYzcxIiwiZGV2aWNlTmFtZSI6IkFuZHJvaWQgLSBTYW1zdW5nIEludGVybmV0IiwiZGV2aWNlSXAiOiIxNzguMTEzLjE3OS4xNzAiLCJkZXZpY2VQbGF5ZXJ'
        'TaXplV2lkdGgiOjM4NCwiZGV2aWNlUGxheWVyU2l6ZUhlaWdodCI6NjgyLCJhZFNlc3Npb25JZCI6IjU0NWQ5NmM3LWZlNzMtNDMxMy1hYmRhLTUzMjc4MjY'
        'yOWU0OCIsImdlbyI6eyJ0aW1lem9uZSI6IkV1cm9wZS9WaWVubmEiLCJvZmZzZXQiOjIsImlzcCI6Ikh1dGNoaXNvbiBEcmVpIEF1c3RyaWEgR21iSCIsImF'
        'yZWFzIjpbMTAsMTcsMjcsMzEsMzMsMzksNDAsNDIsNDMsNDQsNDUsNDYsNTAsNTEsNTIsNTMsNTVdLCJjb3VudHJ5X2NvZGUiOiJBVCIsImFzbiI6IkFTMjU'
        'yNTUiLCJpcCI6IjE3OC4xMTMuMTc5LjE3MCIsImlzX2Fub255bW91cyI6ZmFsc2UsImxhdGl0dWRlIjo0OC4yMTY5LCJsb25naXR1ZGUiOjE2LjQ5OTcsImN'
        'pdHkiOiJWaWVubmEiLCJ6aXBjb2RlIjoiMTIyMCJ9fQ.lQFZ3SDPB6Qzc7337yWxuQ86I3BqAZPdg8qk_GofiLSMllu5EivBTT5VBe2HsqVSZ66DJX-AzPR3'
        'yYenzAz2Yg'
    )
    _GUEST_BE = 1778791887
    _GUEST_OE = 1778835086
    _GUEST_ORE = 1786481486

    def guest_login (self ):
        import time as _t
        existing =self ._tokens .get ('guest_bedrock_token','')
        exp =self ._tokens .get ('guest_bedrock_expires',0 )
        if existing and exp >_t .time ()+300 :
            _log ('guest_login: bereits initialisiert')
            return
        self ._tokens ={
            'is_guest':True ,
            'device_id':self ._GUEST_DID ,
            'access_token':self ._GUEST_AT ,
            'refresh_token':self ._GUEST_RT ,
            'oidc_expires':self ._GUEST_OE ,
            'oidc_refresh_expires':self ._GUEST_ORE ,
            'guest_bedrock_token':self ._GUEST_BT ,
            'guest_bedrock_expires':self ._GUEST_BE ,
            'gigya_uid':'1056891753',
        }
        self ._save_tokens ()
        _log ('guest_login: Bootstrap gespeichert')

    def get_guest_bedrock_token (self ):
        import time as _t
        now =_t .time ()
        cached =self ._tokens .get ('guest_bedrock_token','')
        exp =self ._tokens .get ('guest_bedrock_expires',0 )
        if cached and exp >now +300 :
            return cached
        _log ('get_guest_bedrock_token: erneuere...')
        oidc =self .get_oidc_token ()
        if not oidc :
            return cached or None
        bedrock =self .get_bedrock_token ()
        if bedrock :
            self ._tokens ['guest_bedrock_token']=bedrock
            self ._tokens ['guest_bedrock_expires']=self ._tokens .get ('bedrock_expires',now +86000 )
            self ._save_tokens ()
        return bedrock or cached

def _get_device_key ():
    import base64 

    try :
        import xbmcdrm 
        wv =xbmcdrm .CryptoSession (
        'edef8ba9-79d6-4ace-a3c8-27dcd51d21ed',
        'AES/CBC/NoPadding'
        )
        wv_id =wv .GetPropertyByteArray ('deviceUniqueId')
        if wv_id :
            wv_str =base64 .b64encode (bytes (wv_id )).decode ()
            
            return hashlib .sha256 (('wv:'+wv_str ).encode ('utf-8')).digest ()
    except Exception as e :
        _log (f'Device key: Fehlgeschlagen: {e }')

    try :
        import subprocess 
        out =subprocess .check_output (
        ['settings','get','secure','android_id'],timeout =2 
        ).decode ().strip ()
        if out and out !='null':
            _log ('Device key: Android ID OK')
            return hashlib .sha256 (('aid:'+out ).encode ('utf-8')).digest ()
    except Exception :
        pass 

    try :
        import subprocess 
        out =subprocess .check_output (
        ['getprop','ro.serialno'],timeout =2 
        ).decode ().strip ()
        if out and out not in ('','unknown'):
            _log ('Device key: Serial OK')
            return hashlib .sha256 (('sn:'+out ).encode ('utf-8')).digest ()
    except Exception :
        pass 

    try :
        import socket 
        host =socket .gethostname ()
        _log ('Device key: Hostname Fallback')
        return hashlib .sha256 (('host:'+host ).encode ('utf-8')).digest ()
    except Exception :
        pass 

    _log ('Device key: KEIN Identifier gefunden – statischer Notfall-Key')
    return hashlib .sha256 (b'rtlplus-static-fallback').digest ()

def _encrypt_tokens (data :str )->str :
    import os as _os 
    key =_get_device_key ()
    raw =data .encode ('utf-8')

    pad =16 -len (raw )%16 
    raw +=bytes ([pad ]*pad )
    iv =_os .urandom (16 )
    try :
        from cryptography .hazmat .primitives .ciphers import Cipher ,algorithms ,modes 
        from cryptography .hazmat .backends import default_backend 
        c =Cipher (algorithms .AES (key ),modes .CBC (iv ),backend =default_backend ())
        enc =c .encryptor ()
        ct =enc .update (raw )+enc .finalize ()
    except ImportError :

        ct =b''
        prev =iv 
        for i in range (0 ,len (raw ),16 ):
            blk =bytes (a ^b for a ,b in zip (raw [i :i +16 ],prev ))
            ks =hashlib .sha256 (key +prev ).digest ()[:16 ]
            blk =bytes (a ^b for a ,b in zip (blk ,ks ))
            ct +=blk 
            prev =blk 
    import base64 
    return base64 .b64encode (iv +ct ).decode ()

def _decrypt_tokens (data :str )->str :
    import base64 
    key =_get_device_key ()
    raw =base64 .b64decode (data )
    iv ,ct =raw [:16 ],raw [16 :]
    try :
        from cryptography .hazmat .primitives .ciphers import Cipher ,algorithms ,modes 
        from cryptography .hazmat .backends import default_backend 
        c =Cipher (algorithms .AES (key ),modes .CBC (iv ),backend =default_backend ())
        dec =c .decryptor ()
        pt =dec .update (ct )+dec .finalize ()
    except ImportError :
        pt =b''
        prev =iv 
        for i in range (0 ,len (ct ),16 ):
            blk =ct [i :i +16 ]
            ks =hashlib .sha256 (key +prev ).digest ()[:16 ]
            dec_blk =bytes (a ^b for a ,b in zip (blk ,ks ))
            pt +=bytes (a ^b for a ,b in zip (dec_blk ,prev ))
            prev =blk 
    pad =pt [-1 ]
    if pad <1 or pad >16 :
        raise ValueError ('Ungültiges Padding – falsches Gerät')
    return pt [:-pad ].decode ('utf-8')
