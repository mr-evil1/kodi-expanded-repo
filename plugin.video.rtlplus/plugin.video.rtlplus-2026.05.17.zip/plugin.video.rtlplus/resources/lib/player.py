import sys
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from .api import BedrockAPI
from .auth import USER_AGENT

DRM_LICENSE_URL = 'https://lic.drmtoday.com/license-proxy-widevine/cenc/'

def _log(msg):
    xbmc.log(f'[RTL+ Player] {msg}', xbmc.LOGDEBUG)

def _q(value):
    return urllib.parse.quote(str(value).encode('utf8'))

class RTLPlayer:
    def __init__(self, handle):
        self.handle = handle
        self.api = BedrockAPI()

    def _no_assets_error(self):
        try:
            is_free = not self.api.auth.is_premium()
        except Exception:
            is_free = False
        if is_free:
            xbmcgui.Dialog().ok('RTL+', 'Premium Inhalt im Free Modus nicht verfuegbar.\n\nBitte upgraden Sie Ihren Account auf RTL+ Premium.')
        else:
            xbmcgui.Dialog().notification('RTL+', 'Stream nicht gefunden', xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

    def play_vod(self, video_id, title='Video', video_seo='', program_seo='', program_id=''):
        _log(f'play_vod id={video_id}')

        addon = xbmcaddon.Addon()
        if addon.getSettingBool('weiterschauen_enabled'):
            self._save_resume_info(video_id, title)

        assets = self.api.get_video_assets(video_id, video_seo=video_seo, program_seo=program_seo, program_id=program_id)
        if not assets:
            self._no_assets_error()
            return

        asset = self._best_asset(assets)
        _log(f'Asset: quality={asset["quality"]} drm_type={asset["drm_type"]}')

        drm_cfg = asset.get('drm_config', {})
        service_code = drm_cfg.get('serviceCode', 'video_tv')
        content_id = drm_cfg.get('contentId', video_id)

        drm_token = self.api.auth.get_drm_token(service_code, 'video', content_id)
        self._resolve(asset['path'], drm_token, title, is_live=False)

    def _save_resume_info(self, video_id, title):
        from .evil import bookmarks as _bookmarks
        from .evil.constants import ADDON_ID

        current_path = f'plugin://{ADDON_ID}/?mode=play_vod&video_id={video_id}&title={urllib.parse.quote_plus(title)}'

        data = _bookmarks.get()
        data = [x for x in data if x.get('path') != current_path]
        data.insert(0, {
            'path': current_path,
            'label': f'[Weiterschauen] {title}',
            'thumb': '',
            'folder': 0,
            'playable': 1,
        })
        data = data[:5]
        from .evil.util import save_json
        from .evil.constants import BOOKMARK_FILE
        save_json(BOOKMARK_FILE, data, pretty=True)
        _log(f'Weiterschauen gespeichert: {title}')

    def play_audio(self, audio_id, title='Audio'):
        _log(f'play_audio id={audio_id}')

        assets = self.api.get_audio_assets(audio_id)
        if not assets:
            self._no_assets_error()
            return

        def _audio_score(a):
            fmt = a.get('format', '')
            return {'mp3': 10, 'passthrough_mp3_mpeg': 9, 'aac': 7, 'hls': 5, 'hlsfp': 5, 'm3u8': 5}.get(fmt, 3)

        asset = max(assets, key=_audio_score)
        _log(f'Audio asset: format={asset["format"]} drm_type={asset.get("drm_type", "none")} path={asset["path"][:80]}')

        drm_cfg = asset.get('drm_config', {})
        if drm_cfg:
            service_code = drm_cfg.get('serviceCode', 'video_tv')
            content_id = drm_cfg.get('contentId', audio_id)
            drm_token = self.api.auth.get_drm_token(service_code, 'video', content_id)
            _log(f'Audio DRM-Token: {"OK" if drm_token else "FEHLT"} serviceCode={service_code}')
        else:
            drm_token = None

        self._resolve_audio(asset['path'], title, fmt=asset.get('format', ''), drm_token=drm_token)

    def play_radio(self, radio_id, title='Radio'):
        _log(f'play_radio id={radio_id}')

        assets = self.api.get_radio_assets(radio_id)

        if assets:
            def _radio_score(a):
                fmt = a.get('format', '')
                return {'hls': 10, 'm3u8': 10, 'mp3': 8, 'aac': 7, 'dash': 3, 'dashcenc': 2}.get(fmt, 5)

            asset = max(assets, key=_radio_score)
            stream_url = asset['path']
            fmt = asset.get('format', '')
            _log(f'Radio asset: format={fmt} url={stream_url[:80]}')

            if fmt in ('hls', 'hlsfp', 'm3u8', 'mp3', 'aac', 'passthrough_mp3_mpeg'):
                self._resolve_audio(stream_url, title, fmt=fmt)
                return

            drm_cfg = asset.get('drm_config', {})
            service_code = drm_cfg.get('serviceCode', 'rtlplus_root')
            content_id = drm_cfg.get('contentId', radio_id)
            drm_token = self.api.auth.get_drm_token(service_code, 'live', content_id) if drm_cfg else None
            self._resolve(stream_url, drm_token, title, is_live=True)
        else:
            self._no_assets_error()

    def play_live(self, channel_id, service_code='rtlplus_root', content_id='', title='Live'):
        _log(f'play_live channel={channel_id}')

        if not content_id:
            content_id = f'dashcenc_rtlde_{channel_id}'

        assets = self.api.get_live_assets(channel_id)

        if assets:
            asset = self._best_asset(assets, is_live=True)
            mpd_url = asset['path']
            drm_cfg = asset.get('drm_config', {})
            service_code = drm_cfg.get('serviceCode', service_code)
            live_content_id = drm_cfg.get('contentId', content_id)
            use_drm = bool(drm_cfg)
        else:
            _log('No assets, using fallback URL')
            channel_slug_dash = channel_id.replace('_', '-')
            if channel_id.startswith('fast'):
                mpd_url = (
                    f'https://origin.live.rtlde.bedrock.tech/out/v1/rtlde/'
                    f'rtlde-{channel_slug_dash}/cmaf_cenc00/dash-short-sd.mpd'
                )
            else:
                mpd_url = (
                    f'https://origin.live.rtlde.bedrock.tech/out/v1/rtlde/'
                    f'rtlde-{channel_slug_dash}/cmaf_cenc71/dash-short-hd720.mpd'
                )
            live_content_id = content_id
            use_drm = True

        if 'cmaf_cenc00' in mpd_url and 'yospace.com' not in mpd_url:
            is_fast_channel = f'rtlde-{channel_id}' in mpd_url and channel_id.startswith('fast')
            if not is_fast_channel:
                mpd_url = mpd_url.replace('cmaf_cenc00', 'cmaf_cenc71')
                _log(f'cenc00 -> cenc71 (Origin, nicht-FAST): {mpd_url}')
            else:
                _log(f'cenc00 beibehalten (FAST-Kanal): {mpd_url}')
            use_drm = True
            if not service_code:
                service_code = 'rtlplus_root'
            if not live_content_id:
                live_content_id = f'dashcenc_rtlde_{channel_id}'
            _log(f'DRM: service={service_code}, cid={live_content_id}')

        _log(f'Live MPD: {mpd_url}')

        if use_drm:
            drm_token = self.api.auth.get_drm_token(service_code, 'live', live_content_id)
        else:
            drm_token = None
            _log(f'DRM deaktiviert: kein DRM-Asset (channel={channel_id})')

        self._resolve(mpd_url, drm_token, title, is_live=True)

    def _resolve(self, mpd_url, drm_token, title, is_live=False):
        li = xbmcgui.ListItem(label=title, path=mpd_url)
        li.setInfo('video', {'title': title, 'mediatype': 'video'})

        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')

        addon = xbmcaddon.Addon()
        lang_index = int(addon.getSetting('audio_language') or '0')
        lang_map = {1: 'deu', 2: 'eng'}
        if lang_index in lang_map:
            li.setProperty('inputstream.adaptive.audio_language', lang_map[lang_index])
            _log(f'Bevorzugte Audiosprache: {lang_map[lang_index]}')

        stream_headers = (
            f'User-Agent={_q(USER_AGENT)}'
            f'&Origin={_q("https://plus.rtl.de")}'
            f'&Referer={_q("https://plus.rtl.de/")}'
        )
        li.setProperty('inputstream.adaptive.stream_headers', stream_headers)
        li.setProperty('inputstream.adaptive.manifest_headers', stream_headers)

        if drm_token:
            lic_headers = (
                f'Content-Type=application%2Foctet-stream'
                f'&User-Agent={_q(USER_AGENT)}'
                f'&Origin={_q("https://plus.rtl.de")}'
                f'&Referer={_q("https://plus.rtl.de/")}'
                f'&x-dt-auth-token={_q(drm_token)}'
            )
            license_key = f'{DRM_LICENSE_URL}|{lic_headers}|R{{SSM}}|JBlicense'
            li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            li.setProperty('inputstream.adaptive.license_key', license_key)
            _log('DRM: license_key mit JBlicense Response-Filter gesetzt')
        else:
            _log('Kein DRM-Token: Stream ohne Widevine')

        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def _resolve_audio(self, url, title, fmt='', drm_token=None):
        _log(f'_resolve_audio fmt={fmt} drm={"ja" if drm_token else "nein"} url={url[:100]}')

        headers = {
            'User-Agent': USER_AGENT,
            'Referer': 'https://plus.rtl.de/',
            'Origin': 'https://plus.rtl.de',
        }
        stream_headers_pipe = urllib.parse.urlencode(headers)

        if fmt in ('hls', 'hlsfp') or url.split('?')[0].endswith('.m3u8'):
            if fmt == 'hlsfp':
                _log('Audio HLS: Format hlsfp (HE-AAC) wird von Kodi nicht unterstuetzt')
                xbmcgui.Dialog().ok('RTL+', 'Stream mit Kodi nicht unterstuetzt.[CR][CR]Das Audioformat (HE-AAC) wird von Kodi leider nicht dekodiert.')
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return

            full_url = f'{url}|{stream_headers_pipe}'
            li = xbmcgui.ListItem(label=title, path=full_url)
            li.setInfo('video', {'title': title})
            li.setProperty('IsPlayable', 'true')
        else:
            full_url = f'{url}|{stream_headers_pipe}'
            li = xbmcgui.ListItem(label=title, path=full_url)
            li.setInfo('music', {'title': title})
            li.setProperty('IsPlayable', 'true')

        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def _best_asset(self, assets, is_live=False):
        if not is_live:
            try:
                if not self.api.auth.is_premium():
                    sd_assets = [a for a in assets
                                 if a.get('quality', '').lower() in ('sd', '')
                                 or a.get('video_quality', '').lower() in ('sd', '576p', '576', '')]
                    if sd_assets:
                        assets = sd_assets
                        _log('Free-Account: Stream auf SD/576p begrenzt')
                    else:
                        _log('Free-Account: Kein SD-Asset gefunden, nehme verfügbares Asset')
            except Exception as e:
                _log(f'is_premium check in _best_asset fehlgeschlagen: {e}')

        def score(a):
            drm_score = 10 if a.get('drm_type') == 'software' else 5
            q = a.get('video_quality', a.get('quality', 'sd'))
            quality_score = {'hd': 3, 'hd2': 4, 'sd': 1, 'fhd': 5}.get(q, 2)
            path = a.get('path', '')
            origin_score = 5 if (is_live and 'origin.live' in path) else 0
            return drm_score + quality_score + origin_score

        return max(assets, key=score)
