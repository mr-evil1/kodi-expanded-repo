import json 
import os 
import time 
import uuid 
import hashlib 
import hmac 
import urllib .request 
import binascii 
import zlib 
import xbmcaddon 
import xbmcvfs 
import xbmc 
import xbmcgui 
_addon =xbmcaddon .Addon ()
_addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))

try :
    from resources .lib .evil import gui as evil_gui 
    from resources .lib .evil .gui import Item as EvilItem 
    _EVIL_AVAILABLE =True 
except Exception :
    _EVIL_AVAILABLE =False 

ADDON =xbmcaddon .Addon ()
ADDON_ID =ADDON .getAddonInfo ('id')
PROFILE_PATH =xbmcvfs .translatePath (ADDON .getAddonInfo ('profile'))

TOKEN_FILE =os .path .join (PROFILE_PATH ,'tokens.json')
GUEST_TOKEN_FILE =os .path .join (PROFILE_PATH ,'guest_tokens.json')
DEVICE_FILE =os .path .join (PROFILE_PATH ,'device.json')

AUTH_BASE ='https://auth.rtl.de/auth/realms/rtlplus/protocol/openid-connect'
CLIENT_ID ='bedrock-m6group_web'
REDIRECT_URI ='https://plus.rtl.de/silent-sso-iframe.html'

FRONT_AUTH_URL ='https://front-auth.rtlde.bedrock.tech/v2/rtlde/platforms/m6group_web/token'

CLIENT_RELEASE ='6.41.2'
USER_AGENT =('Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
'(KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36')

def _log (msg ):
    xbmc .log (f'[RTL+ Auth] {msg }',xbmc .LOGDEBUG )
def _img (fname ):
            return os .path .join (_addon_path ,'resources','media',fname )

class RTLAuth :
    def __init__ (self ):
        os .makedirs (PROFILE_PATH ,exist_ok =True )
        self ._tokens =self ._load_tokens ()
        self ._guest_tokens =self ._load_guest_tokens ()

    def _load_guest_tokens (self ):
        try :
            if os .path .exists (GUEST_TOKEN_FILE ):
                with open (GUEST_TOKEN_FILE ,'r')as f :
                    return json .load (f )
        except Exception as e :
            _log (f'Load guest tokens error: {e }')
        return {}

    def _save_guest_tokens (self ):
        try :
            with open (GUEST_TOKEN_FILE ,'w')as f :
                json .dump (self ._guest_tokens ,f )
        except Exception as e :
            _log (f'Save guest tokens error: {e }')

    def _load_tokens (self ):
        _GUEST_KEYS =('is_guest','guest_bedrock_token','guest_bedrock_expires')
        try :
            if os .path .exists (TOKEN_FILE ):
                with open (TOKEN_FILE ,'r')as f :
                    raw =json .load (f )
                if raw .get ('__locked__'):
                    try :
                        data =json .loads (_decrypt_tokens (raw ['data']))
                    except Exception as e :
                        _log (f'GERÄTEBINDUNG fehlgeschlagen: {e }')
                        xbmcgui .Dialog ().notification (
                        'RTL+','Token ungültig für dieses Gerät – bitte neu anmelden',
                        xbmcgui .NOTIFICATION_ERROR ,5000 )
                        os .remove (TOKEN_FILE )
                        return {}
                else :
                    data =raw
                migrated =any (k in data for k in _GUEST_KEYS )
                for k in _GUEST_KEYS :
                    data .pop (k ,None )
                if migrated :
                    _log ('_load_tokens: Gast-Keys aus tokens.json entfernt (Migration)')
                return data
        except Exception as e :
            _log (f'Load tokens error: {e }')
        return {}

    def _save_tokens (self ):
        _login_keys =('access_token','refresh_token','gigya_uid')
        if not any (self ._tokens .get (k )for k in _login_keys ):
            _log ('_save_tokens: kein Login-Token vorhanden – tokens.json wird nicht geschrieben')
            return
        try :
            payload =json .dumps (self ._tokens )
            wrapper ={'__locked__':True ,'data':_encrypt_tokens (payload )}
            with open (TOKEN_FILE ,'w')as f :
                json .dump (wrapper ,f )
        except Exception as e :
            _log (f'Save tokens error: {e }')

    def logout (self ):
        self ._tokens ={}
        if os .path .exists (TOKEN_FILE ):
            os .remove (TOKEN_FILE )

    def invalidate_tokens (self ):
        for key in ('bedrock_token','bedrock_expires'):
            self ._tokens .pop (key ,None )
        self ._save_tokens ()
        _log ('Bedrock-Token invalidiert - wird beim naechsten Request erneuert')

    def _load_device_id (self ):
        try :
            if os .path .exists (DEVICE_FILE ):
                with open (DEVICE_FILE ,'r')as f :
                    return json .load (f ).get ('device_id','')
        except Exception as e :
            _log (f'Load device_id error: {e }')
        return ''

    def _save_device_id (self ,device_id ):
        try :
            os .makedirs (PROFILE_PATH ,exist_ok =True )
            with open (DEVICE_FILE ,'w')as f :
                json .dump ({'device_id':device_id },f )
        except Exception as e :
            _log (f'Save device_id error: {e }')

    def get_device_id (self ):
        if 'device_id'in self ._tokens :
            did =self ._tokens .pop ('device_id')
            self ._save_device_id (did )
            if self ._tokens :
                self ._save_tokens ()
            _log ('get_device_id: device_id aus tokens.json nach device.json migriert')
            return did
        did =self ._load_device_id ()
        if not did :
            did ='_luid_'+str (uuid .uuid4 ())
            self ._save_device_id (did )
            _log (f'get_device_id: neue device_id erzeugt: {did }')
        return did

    def get_oidc_token (self ):
        import requests 
        now =time .time ()

        if (self ._tokens .get ('access_token')and 
        self ._tokens .get ('oidc_expires',0 )>now +300 ):
            return self ._tokens ['access_token']

        _has_real_user =(bool (ADDON .getSetting ('username'))
                        and bool (self ._tokens .get ('refresh_token','')))
        if self ._guest_tokens .get ('is_guest')and not _has_real_user :
            return None 
        if not ADDON .getSetting ('username'):
            return None 

        refresh_expires =self ._tokens .get ('oidc_refresh_expires',0 )
        if refresh_expires and refresh_expires <now +300 :
            _log ('Refresh-Token läuft bald ab – direkt silent re-login')
            self ._tokens .pop ('refresh_token',None )
            token =self ._silent_relogin ()
            if token :
                return token 
            return self ._login ()

        refresh_token =self ._tokens .get ('refresh_token','')
        if refresh_token :
            _log ('Attempting OIDC token refresh...')
            try :
                resp =requests .post (
                f'{AUTH_BASE }/token',
                data ={
                'client_id':CLIENT_ID ,
                'grant_type':'refresh_token',
                'refresh_token':refresh_token ,
                },
                headers ={'User-Agent':USER_AGENT },
                timeout =15 
                )
                if resp .status_code ==200 :
                    data =resp .json ()
                    self ._tokens ['access_token']=data ['access_token']
                    self ._tokens ['refresh_token']=data .get ('refresh_token',refresh_token )
                    self ._tokens ['oidc_expires']=now +data .get ('expires_in',3600 )
                    self ._tokens ['oidc_refresh_expires']=now +data .get ('refresh_expires_in',86400 )
                    self ._tokens .pop ('bedrock_token',None )
                    self ._tokens .pop ('bedrock_expires',None )
                    self ._save_tokens ()
                    _log ('OIDC token refreshed successfully')
                    return self ._tokens ['access_token']
                else :
                    _log (f'Refresh token rejected (HTTP {resp .status_code }) - will re-login silently')

                    self ._tokens .pop ('refresh_token',None )
                    self ._tokens .pop ('oidc_refresh_expires',None )
                    self ._save_tokens ()
            except Exception as e :
                _log (f'Refresh error: {e }')

        _log ('No valid token - attempting silent re-login')
        token =self ._silent_relogin ()
        if token :
            return token 

        return self ._login ()

    def _silent_relogin (self ):
        import requests 
        username =ADDON .getSetting ('username')
        password =ADDON .getSetting ('password')
        if not username or not password :
            _log ('Silent re-login skipped: no saved credentials')
            return None 

        _log (f'Silent re-login for {username }')
        try :
            code_verifier =uuid .uuid4 ().hex +uuid .uuid4 ().hex 
            import base64 as _b64 ,hashlib as _hl 
            code_challenge =_b64 .urlsafe_b64encode (
            _hl .sha256 (code_verifier .encode ()).digest ()
            ).rstrip (b'=').decode ()

            session =requests .Session ()
            session .headers ['User-Agent']=USER_AGENT 

            r1 =session .get (
            f'{AUTH_BASE }/auth',
            params ={
            'response_type':'code',
            'client_id':CLIENT_ID ,
            'redirect_uri':REDIRECT_URI ,
            'code_challenge':code_challenge ,
            'code_challenge_method':'S256',
            'scope':'openid',
            },
            allow_redirects =True ,
            timeout =15 
            )

            import re as _re 
            action_match =_re .search (r'action="([^"]+)"',r1 .text )
            if not action_match :
                _log ('Silent re-login: login form not found')
                return None 

            action_url =action_match .group (1 ).replace ('&amp;','&')

            r2 =session .post (
            action_url ,
            data ={'username':username ,'password':password ,'credentialId':''},
            allow_redirects =False ,
            timeout =15 
            )

            location =r2 .headers .get ('Location','')
            code_match =_re .search (r'code=([^&]+)',location )
            if not code_match :
                _log (f'Silent re-login: no auth code in redirect ({location [:100 ]})')
                return None 

            r3 =session .post (
            f'{AUTH_BASE }/token',
            data ={
            'client_id':CLIENT_ID ,
            'grant_type':'authorization_code',
            'code':code_match .group (1 ),
            'code_verifier':code_verifier ,
            'redirect_uri':REDIRECT_URI ,
            },
            timeout =15 
            )
            r3 .raise_for_status ()
            data =r3 .json ()

            now =time .time ()
            self ._tokens ['access_token']=data ['access_token']
            self ._tokens ['refresh_token']=data .get ('refresh_token','')
            self ._tokens ['oidc_expires']=now +data .get ('expires_in',3600 )
            self ._tokens ['oidc_refresh_expires']=now +data .get ('refresh_expires_in',86400 )

            try :
                payload =data ['access_token'].split ('.')[1 ]
                payload +='='*(-len (payload )%4 )
                import base64 as _b64j ,json as _json 
                jwt_data =_json .loads (_b64j .b64decode (payload ))
                parts =jwt_data .get ('sub','').split (':')
                self ._tokens ['gigya_uid']=parts [-1 ]if parts else ''
            except Exception as je :
                _log (f'Silent re-login JWT parse: {je }')
                self ._tokens ['gigya_uid']=''

            self ._tokens .pop ('bedrock_token',None )
            self ._tokens .pop ('bedrock_expires',None )
            self ._save_tokens ()
            _log ('Silent re-login successful')
            return self ._tokens ['access_token']

        except Exception as e :
            _log (f'Silent re-login error: {e }')
            return None 

    def download_accounts (self ):
        passw =''
        username =''
        userpass =''
        jsonData ={"js":[{"name":"Hier Anmelden","pass":"","username":"","password":""}]}

        return jsonData 

    def select_and_save_credentials (self ):

        jsonData =[{"name":"Hier anmelden","pass":"","username":"","password":"",'icon':_img ('icon.png')}]

        Name =[]
        Username =[]
        Password =[]
        Passw =[]
        Icon =[]

        for i in jsonData :
            name =i .get ('name','?')
            username =i .get ('username','')
            password =i .get ('password','')
            passw =i .get ('pass','')
            try :
                icon =i ['icon']
            except Exception :
                icon =''

            Username .append (username )
            Password .append (password )
            Passw .append (passw )
            if passw !='':
                name =name +' [Pin Safe]'
            Name .append (name )
            Icon .append (icon )

        names =Name 
        userlist =Username 
        passlist =Password 
        pinlist =Passw 

        if _EVIL_AVAILABLE :
            _options =[]
            for i ,name in enumerate (names ):
                _options .append (EvilItem (label =name ,art ={'thumb':Icon [i ]}if Icon [i ]else {}))
            index =evil_gui .select ('RTL+ Zugang wählen',options =_options ,useDetails =True )
        else :
            index =xbmcgui .Dialog ().select ('RTL+ Zugang wählen',names )
        if index <0 :
            return None ,None 

        username =userlist [index ]
        password =passlist [index ]
        pin =pinlist [index ]

        if not username :
            kb =xbmc .Keyboard ('','RTL+ E-Mail')
            kb .doModal ()
            if not kb .isConfirmed ():
                return None ,None 
            username =kb .getText ().strip ()

            kb2 =xbmc .Keyboard ('','RTL+ Passwort',True )
            kb2 .doModal ()
            if not kb2 .isConfirmed ():
                return None ,None 
            password =kb2 .getText ().strip ()
            pin =''

        if pin :
            while True :
                kb_pin =xbmc .Keyboard ('','User PIN',True )
                kb_pin .doModal ()
                if not kb_pin .isConfirmed ():
                    return None ,None 
                if kb_pin .getText ()==pin :
                    break 
                xbmcgui .Dialog ().notification ('RTL+','Falscher PIN',xbmcgui .NOTIFICATION_ERROR ,2000 )

        ADDON .setSetting ('username',username )
        ADDON .setSetting ('password',password )
        _log (f'select_and_save_credentials: Konto "{names [index ]}" gewählt')
        return username ,password 

    def _login (self ):
        import requests 

        username =ADDON .getSetting ('username')
        password =ADDON .getSetting ('password')

        if not username or not password :

            username ,password =self .select_and_save_credentials ()
            if not username or not password :
                return None 

        _log (f'Logging in as {username }...')

        code_verifier =uuid .uuid4 ().hex +uuid .uuid4 ().hex 
        import base64 ,hashlib 
        code_challenge =base64 .urlsafe_b64encode (
        hashlib .sha256 (code_verifier .encode ()).digest ()
        ).rstrip (b'=').decode ()

        session =requests .Session ()
        session .headers ['User-Agent']=USER_AGENT 

        try :
            r1 =session .get (
            f'{AUTH_BASE }/auth',
            params ={
            'response_type':'code',
            'client_id':CLIENT_ID ,
            'redirect_uri':REDIRECT_URI ,
            'code_challenge':code_challenge ,
            'code_challenge_method':'S256',
            'scope':'openid',
            },
            allow_redirects =True ,
            timeout =15 
            )
        except Exception as e :
            _log (f'Auth page error: {e }')
            return None 

        import re 
        action_match =re .search (r'action="([^"]+)"',r1 .text )
        if not action_match :
            _log ('Could not find login form action')
            return None 

        action_url =action_match .group (1 ).replace ('&amp;','&')

        try :
            r2 =session .post (
            action_url ,
            data ={
            'username':username ,
            'password':password ,
            'credentialId':'',
            },
            allow_redirects =False ,
            timeout =15 
            )
        except Exception as e :
            _log (f'Login POST error: {e }')
            return None 

        location =r2 .headers .get ('Location','')
        code_match =re .search (r'code=([^&]+)',location )
        if not code_match :
            _log (f'No code in redirect: {location [:200 ]}')
            _log ('Login fehlgeschlagen - Zugangsdaten pruefen')
            return None 

        code =code_match .group (1 )

        try :
            r3 =session .post (
            f'{AUTH_BASE }/token',
            data ={
            'client_id':CLIENT_ID ,
            'grant_type':'authorization_code',
            'code':code ,
            'code_verifier':code_verifier ,
            'redirect_uri':REDIRECT_URI ,
            },
            timeout =15 
            )
            r3 .raise_for_status ()
            data =r3 .json ()
        except Exception as e :
            _log (f'Token exchange error: {e }')
            return None 

        now =time .time ()
        self ._tokens ['access_token']=data ['access_token']
        self ._tokens ['refresh_token']=data .get ('refresh_token','')
        self ._tokens ['oidc_expires']=now +data .get ('expires_in',3600 )
        self ._tokens ['oidc_refresh_expires']=now +data .get ('refresh_expires_in',86400 )

        try :
            import base64 
            payload =data ['access_token'].split ('.')[1 ]
            payload +='='*(-len (payload )%4 )
            jwt_data =json .loads (base64 .b64decode (payload ))
            self ._tokens ['gigya_uid']=jwt_data .get ('sub','').split (':')[-1 ]

            parts =jwt_data .get ('sub','').split (':')
            if len (parts )>=3 :
                self ._tokens ['gigya_uid']=parts [-1 ]
            else :
                self ._tokens ['gigya_uid']=parts [-1 ]if parts else ''
        except Exception as e :
            _log (f'JWT parse error: {e }')
            self ._tokens ['gigya_uid']=''

        self ._tokens .pop ('bedrock_token',None )
        self ._tokens .pop ('bedrock_expires',None )

        if self ._guest_tokens .get ('is_guest'):
            self ._guest_tokens ['is_guest']=False
            self ._save_guest_tokens ()
            _log ('Login: is_guest-Flag in guest_tokens geloescht')

        self ._save_tokens ()
        _log (f'Login OK, gigya_uid={self ._tokens .get ("gigya_uid")}')
        self .get_bedrock_token ()
        _log (f'Login OK, profile_id={self ._tokens .get ("profile_id","FEHLT")}')
        return self ._tokens ['access_token']

    def get_bedrock_token (self ):
        import requests 
        now =time .time ()

        if (self ._tokens .get ('bedrock_token')and 
        self ._tokens .get ('bedrock_expires',0 )>now +300 ):
            return self ._tokens ['bedrock_token']

        access_token =self .get_oidc_token ()
        if not access_token :
            return None 

        gigya_uid =self .get_gigya_uid ()
        device_id =self .get_device_id ()
        profile_id =self ._tokens .get ('profile_id','')

        ts =int (now )
        auth_token =hmac .new (
        gigya_uid .encode ()if gigya_uid else b'',
        str (ts ).encode (),
        hashlib .sha1 
        ).hexdigest ()if gigya_uid else ''

        headers ={
        'Authorization':f'Bearer {access_token }',
        'x-auth-device-name':'Android - Samsung Internet',
        'x-auth-gigya-uid':gigya_uid ,
        'x-auth-token-timestamp':str (ts ),
        'x-auth-token':auth_token ,
        'x-auth-profile-id':profile_id ,
        'x-auth-device-id':device_id ,
        'x-auth-device-player-size-width':'1920',
        'x-auth-device-player-size-height':'1080',
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'request-timeout':'10000',
        'User-Agent':USER_AGENT ,
        'Origin':'https://plus.rtl.de',
        'Referer':'https://plus.rtl.de/',
        'Accept':'*/*',
        }

        _log ('Getting Bedrock token...')
        try :
            resp =requests .get (FRONT_AUTH_URL ,headers =headers ,timeout =15 )
            resp .raise_for_status ()
            data =resp .json ()
            bedrock_token =data .get ('token','')
            if not bedrock_token :
                _log (f'No bedrock token in response: {data }')
                return self ._guest_tokens .get ('guest_bedrock_token') or None 

            self ._tokens ['bedrock_token']=bedrock_token 
            self ._tokens ['bedrock_expires']=now +86000 
            self ._save_tokens ()
            _log ('Bedrock token OK')
            if not self ._tokens .get ('profile_id'):
                try :
                    import base64 as _b64 ,json as _json 
                    payload =bedrock_token .split ('.')[1 ]
                    payload +='='*(4 -len (payload )%4 )
                    jwt_data =_json .loads (_b64 .b64decode (payload ))
                    _log (f'Bedrock JWT keys: {list (jwt_data .keys ())}')
                    pid =jwt_data .get ('profileid','')or jwt_data .get ('profileId','')
                    if pid :
                        self ._tokens ['profile_id']=pid 
                        _log (f'Bedrock token: profileId={pid }')
                        self ._save_tokens ()
                    else :
                        _log ('Bedrock JWT: kein profileid - versuche Users-API')
                        gigya =self .get_gigya_uid ()
                        if gigya :
                            _pid =self ._fetch_profile_id_from_api (access_token ,bedrock_token )
                            if _pid :
                                self ._tokens ['profile_id']=_pid
                                self ._tokens .pop ('bedrock_token',None )
                                self ._tokens .pop ('bedrock_expires',None )
                                self ._save_tokens ()
                                _log (f'Bedrock token: profileId via API={_pid }, hole neuen Bedrock')
                                return self .get_bedrock_token ()
                except Exception as _ex :
                    _log (f'Bedrock JWT decode Fehler: {_ex }')
            return bedrock_token 

        except Exception as e :
            _log (f'Bedrock token error: {e } - using guest_bedrock_token fallback')
            return self ._guest_tokens .get ('guest_bedrock_token') or None 

    def _fetch_profile_id_from_api (self ,access_token ,bedrock_token ):
        import requests as _r
        gigya =self .get_gigya_uid ()
        if not gigya :
            return ''
        try :
            resp =_r .get (
                f'https://users.rtlde.bedrock.tech/v2/platforms/m6group_web/users/{gigya }/profiles',
                headers ={
                    'Authorization':f'Bearer {access_token }',
                    'x-bedrock-token':bedrock_token ,
                    'User-Agent':USER_AGENT ,
                    'Origin':'https://plus.rtl.de',
                    'Referer':'https://plus.rtl.de/',
                },
                timeout =10
            )
            profiles =resp .json ()
            if profiles and isinstance (profiles ,list ):
                pid =profiles [0 ].get ('uid','')
                _log (f'_fetch_profile_id_from_api: pid={pid }')
                return pid
        except Exception as e :
            _log (f'_fetch_profile_id_from_api error: {e }')
        return ''

    def get_gigya_uid (self ):
        uid =self ._tokens .get ('gigya_uid','')
        if uid :
            return uid
        import base64 ,json as _json
        at =self ._tokens .get ('access_token','')
        if at :
            try :
                parts =at .split ('.')
                payload =parts [1 ]+'=' *(-len (parts [1 ])%4 )
                sub =_json .loads (base64 .b64decode (payload )).get ('sub','')
                uid =sub .split (':')[-1 ]if sub else ''
                if uid :
                    self ._tokens ['gigya_uid']=uid
                    self ._save_tokens ()
                return uid
            except Exception :
                pass
        return ''

    def ensure_profile_id (self ):
        if self ._tokens .get ('profile_id'):
            return 
        try :
            access_token =self .get_oidc_token ()
            self .get_profile_id (access_token =access_token )
            if self ._tokens .get ('profile_id'):
                self ._tokens .pop ('bedrock_token',None )
                self ._tokens .pop ('bedrock_expires',None )
                _log ('ensure_profile_id: bedrock invalidated for re-fetch with profile_id')
        except Exception as e :
            _log (f'ensure_profile_id error: {e }')

    def get_profile_id (self ,access_token =None ):
        if self ._tokens .get ('profile_id'):
            return self ._tokens ['profile_id']

        import base64 as _b64 ,json as _json ,requests 
        bedrock_cached =self ._tokens .get ('bedrock_token','')
        if bedrock_cached :
            try :
                payload =bedrock_cached .split ('.')[1 ]
                payload +='='*(4 -len (payload )%4 )
                data =_json .loads (_b64 .b64decode (payload ))
                pid =data .get ('profileid','')or data .get ('profileId','')
                if pid :
                    self ._tokens ['profile_id']=pid 
                    self ._save_tokens ()
                    _log (f'get_profile_id: aus bedrock-JWT: {pid }')
                    return pid 
            except Exception as e :
                _log (f'get_profile_id JWT-Decode Fehler: {e }')

        gigya_uid =self .get_gigya_uid ()
        if not gigya_uid :
            return ''

        if not access_token :
            access_token =self .get_oidc_token ()

        try :
            bedrock =self .get_bedrock_token ()
            resp =requests .get (
            f'https://users.rtlde.bedrock.tech/v2/platforms/m6group_web/users/{gigya_uid }/profiles',
            headers ={
            'Authorization':f'Bearer {access_token }',
            'x-bedrock-token':bedrock or '',
            'User-Agent':USER_AGENT ,
            'Origin':'https://plus.rtl.de',
            'Referer':'https://plus.rtl.de/',
            },
            timeout =10 
            )
            profiles =resp .json ()
            if profiles :
                self ._tokens ['profile_id']=profiles [0 ].get ('uid','')
                self ._save_tokens ()
                return self ._tokens ['profile_id']
        except Exception as e :
            _log (f'Profile error: {e }')
        return ''

    def get_drm_token (self ,service_code ,content_type ,content_id ):
        import requests 
        if content_type =='live':
            self .ensure_profile_id ()
        access_token =self .get_oidc_token ()
        bedrock_token =self .get_bedrock_token ()or self .get_guest_bedrock_token ()
        gigya_uid =self .get_gigya_uid ()
        _log (f'get_drm_token: gigya_uid={gigya_uid } bedrock={"OK" if bedrock_token else "LEER"}')

        if not gigya_uid :
            anon_oidc =self ._get_anonymous_oidc_token ()
            if not anon_oidc or not bedrock_token :
                _log ('get_drm_token: kein anonymer Token - DRM nicht moeglich')
                return None 
            device_id =self .get_device_id ()
            anon_user_id =f'deviceid-{device_id }'
            if content_type =='video':
                url =(f'https://drm.rtlde.bedrock.tech/v1/customers/rtlde/platforms/m6group_web'
                f'/services/{service_code }/users/{anon_user_id }/videos/{content_id }/upfront-token')
            else :
                url =(f'https://drm.rtlde.bedrock.tech/v1/customers/rtlde/platforms/m6group_web'
                f'/services/{service_code }/users/{anon_user_id }/live/{content_id }/upfront-token')
            headers ={
            'Authorization':f'Bearer {anon_oidc }',
            'x-bedrock-token':bedrock_token ,
            'x-client-release':CLIENT_RELEASE ,
            'x-customer-name':'rtlde',
            'request-timeout':'10000',
            'User-Agent':USER_AGENT ,
            'Origin':'https://plus.rtl.de',
            'Referer':'https://plus.rtl.de/',
            'Accept':'*/*',
            }
            try :
                resp =requests .get (url ,headers =headers ,timeout =15 )
                _log (f'get_drm_token (Gast): HTTP {resp .status_code } user={anon_user_id }')
                resp .raise_for_status ()
                data =resp .json ()
                token =data .get ('token','')
                if token :
                    _log ('get_drm_token (Gast): Token OK')
                    return token 
                _log (f'get_drm_token (Gast): leere Antwort: {data }')
            except Exception as e :
                _log (f'get_drm_token (Gast) error: {e }')
            return None 

        if content_type =='video':
            url =(f'https://drm.rtlde.bedrock.tech/v1/customers/rtlde/platforms/m6group_web'
            f'/services/{service_code }/users/{gigya_uid }/videos/{content_id }/upfront-token')
        else :
            url =(f'https://drm.rtlde.bedrock.tech/v1/customers/rtlde/platforms/m6group_web'
            f'/services/{service_code }/users/{gigya_uid }/live/{content_id }/upfront-token')

        headers ={
        'Authorization':f'Bearer {access_token }',
        'x-bedrock-token':bedrock_token or '',
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'request-timeout':'10000',
        'User-Agent':USER_AGENT ,
        'Origin':'https://plus.rtl.de',
        'Referer':'https://plus.rtl.de/',
        'Accept':'*/*',
        }

        try :
            resp =requests .get (url ,headers =headers ,timeout =15 )
            resp .raise_for_status ()
            data =resp .json ()
            return data .get ('token','')
        except Exception as e :
            _log (f'DRM token error: {e }')
            return None 

    def get_subscription_tier (self ):
        import requests 
        import time as _time 

        cached =self ._tokens .get ('_subscription_tier')
        cached_ts =self ._tokens .get ('_premium_status_ts',0 )
        if cached is not None and (_time .time ()-cached_ts )<21600 :
            return cached 

        access_token =self .get_oidc_token ()
        gigya_uid =self .get_gigya_uid ()
        if not access_token or not gigya_uid :
            _log ('get_subscription_tier: kein OIDC/Gigya – abbruch')
            if cached is not None :
                return cached 
            return 'Free'

        bedrock_token =self .get_bedrock_token ()
        if not bedrock_token :
            _log ('get_subscription_tier: kein Bedrock-Token – abbruch')
            if cached is not None :
                return cached 
            return 'Free'

        url =(f'https://stores.rtlde.bedrock.tech/premium/v4/customers/rtlde'
        f'/platforms/m6group_web/users/{gigya_uid }/subscriptions')
        headers ={
        'Authorization':f'Bearer {access_token }',
        'x-bedrock-token':bedrock_token ,
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'User-Agent':USER_AGENT ,
        'Origin':'https://plus.rtl.de',
        'Referer':'https://plus.rtl.de/',
        }
        try :
            resp =requests .get (url ,headers =headers ,timeout =10 )
            resp .raise_for_status ()
            if resp .status_code ==204 or not resp .content :
                _log ('get_subscription_tier: HTTP 204 – kein Body')
                return cached if cached is not None else 'Free'
            data =resp .json ()
            tier ='Free'
            offer_code =''
            for sub in (data .get ('current',[])or []):
                offer_code =(sub .get ('offer',{})or {}).get ('code','')
                _log (f'get_subscription_tier: offer_code={offer_code !r}')
                if offer_code .startswith ('PM'):
                    tier ='Premium'
                    break 
                if offer_code .startswith ('BA'):
                    tier ='Basic'
                    break 
            self ._tokens ['_subscription_tier']=tier 
            self ._tokens ['_premium_status_ts']=_time .time ()
            self ._save_tokens ()
            _log (f'get_subscription_tier={tier } (offer={offer_code })')
            return tier 
        except Exception as e :
            _log (f'get_subscription_tier error: {e }')
            if cached is not None :
                _log (f'get_subscription_tier: Fehler, nutze gecachten Wert: {cached }')
                return cached 
            return 'Free'

    def is_premium (self ):
        return self .get_subscription_tier () in ('Premium','Basic')

    def guest_login (self ):
        import time as _t
        if bool (self ._tokens .get ('access_token','')):
            _log ('guest_login: echter User-Login aktiv – guest_login wird übersprungen')
            return
        existing =self ._guest_tokens .get ('guest_bedrock_token','')
        exp =self ._guest_tokens .get ('guest_bedrock_expires',0 )
        if existing and exp >_t .time ()+300 :
            _log ('guest_login: Gast-Token noch gültig')
            return
        self ._guest_tokens ={'is_guest':True }
        self ._save_guest_tokens ()
        _log ('guest_login: hole frischen Gast-Token...')
        self .get_guest_bedrock_token ()
        _log ('guest_login: abgeschlossen')

    _ANON_CLIENT_ID ='anonymous-user'
    _ANON_CLIENT_SECRET ='4bfeb73f-1c4a-4e9f-a7fa-96aa1ad3d94c'
    _ANON_OIDC_URL ='https://auth.rtl.de/auth/realms/rtlplus/protocol/openid-connect/token'

    def _get_anonymous_oidc_token (self ):
        import requests as _r
        cached =self ._guest_tokens .get ('anon_oidc_token','')
        exp =self ._guest_tokens .get ('anon_oidc_expires',0 )
        if cached and exp >time .time ()+300 :
            return cached
        try :
            resp =_r .post (
                self ._ANON_OIDC_URL ,
                data ={
                    'client_id':self ._ANON_CLIENT_ID ,
                    'client_secret':self ._ANON_CLIENT_SECRET ,
                    'grant_type':'client_credentials',
                },
                headers ={
                    'User-Agent':USER_AGENT ,
                    'Origin':'https://plus.rtl.de',
                    'Referer':'https://plus.rtl.de/',
                    'Accept':'*/*',
                    'Content-Type':'application/x-www-form-urlencoded',
                },
                timeout =15 
            )
            resp .raise_for_status ()
            data =resp .json ()
            token =data .get ('access_token','')
            expires_in =data .get ('expires_in',86400 )
            if token :
                self ._guest_tokens ['anon_oidc_token']=token
                self ._guest_tokens ['anon_oidc_expires']=time .time ()+expires_in
                self ._save_guest_tokens ()
                _log ('Anonymer OIDC-Token OK')
            return token
        except Exception as e :
            _log (f'Anonymer OIDC-Token Fehler: {e }')
        return cached or ''

    def get_guest_bedrock_token (self ):
        import time as _t
        import requests as _requests
        now =_t .time ()
        cached =self ._guest_tokens .get ('guest_bedrock_token','')
        exp =self ._guest_tokens .get ('guest_bedrock_expires',0 )
        if cached and exp >now +300 :
            return cached
        _log ('get_guest_bedrock_token: hole frischen anonymen Bedrock-Token...')
        anon_oidc =self ._get_anonymous_oidc_token ()
        if not anon_oidc :
            _log ('get_guest_bedrock_token: kein anonymer OIDC-Token')
            return cached or None
        try :
            device_id =self .get_device_id ()
            ts =int (now )
            auth_token =hmac .new (b'',str (ts ).encode (),hashlib .sha1 ).hexdigest ()
            headers ={
                'Authorization':f'Bearer {anon_oidc }',
                'x-auth-device-name':'Android - Samsung Internet',
                'x-auth-gigya-uid':'',
                'x-auth-token-timestamp':str (ts ),
                'x-auth-token':auth_token ,
                'x-auth-profile-id':'',
                'x-auth-device-id':device_id ,
                'x-auth-device-player-size-width':'384',
                'x-auth-device-player-size-height':'682',
                'x-client-release':CLIENT_RELEASE ,
                'x-customer-name':'rtlde',
                'request-timeout':'10000',
                'User-Agent':USER_AGENT ,
                'Origin':'https://plus.rtl.de',
                'Referer':'https://plus.rtl.de/',
                'Accept':'*/*',
            }
            resp =_requests .get (FRONT_AUTH_URL ,headers =headers ,timeout =15 )
            resp .raise_for_status ()
            data =resp .json ()
            bedrock =data .get ('token','')
            if bedrock :
                self ._guest_tokens ['guest_bedrock_token']=bedrock
                self ._guest_tokens ['guest_bedrock_expires']=now +86000
                self ._save_guest_tokens ()
                _log ('get_guest_bedrock_token: anonymer Bedrock-Token OK')
                return bedrock
            _log (f'get_guest_bedrock_token: leere Antwort: {data }')
        except Exception as e :
            _log (f'get_guest_bedrock_token Fehler: {e }')
        return cached or None

def _get_device_key ():
    import base64 

    try :
        import xbmcdrm 
        wv =xbmcdrm .CryptoSession (
        'edef8ba9-79d6-4ace-a3c8-27dcd51d21ed',
        'AES/CBC/NoPadding'
        )
        wv_id =wv .GetPropertyByteArray ('deviceUniqueId')
        if wv_id :
            wv_str =base64 .b64encode (bytes (wv_id )).decode ()
            
            return hashlib .sha256 (('wv:'+wv_str ).encode ('utf-8')).digest ()
    except Exception as e :
        _log (f'Device key: Fehlgeschlagen: {e }')

    try :
        import subprocess 
        out =subprocess .check_output (
        ['settings','get','secure','android_id'],timeout =2 
        ).decode ().strip ()
        if out and out !='null':
            _log ('Device key: Android ID OK')
            return hashlib .sha256 (('aid:'+out ).encode ('utf-8')).digest ()
    except Exception :
        pass 

    try :
        import subprocess 
        out =subprocess .check_output (
        ['getprop','ro.serialno'],timeout =2 
        ).decode ().strip ()
        if out and out not in ('','unknown'):
            _log ('Device key: Serial OK')
            return hashlib .sha256 (('sn:'+out ).encode ('utf-8')).digest ()
    except Exception :
        pass 

    try :
        import socket 
        host =socket .gethostname ()
        _log ('Device key: Hostname Fallback')
        return hashlib .sha256 (('host:'+host ).encode ('utf-8')).digest ()
    except Exception :
        pass 

    _log ('Device key: KEIN Identifier gefunden – statischer Notfall-Key')
    return hashlib .sha256 (b'rtlplus-static-fallback').digest ()

def _encrypt_tokens (data :str )->str :
    import os as _os 
    key =_get_device_key ()
    raw =data .encode ('utf-8')

    pad =16 -len (raw )%16 
    raw +=bytes ([pad ]*pad )
    iv =_os .urandom (16 )
    try :
        from cryptography .hazmat .primitives .ciphers import Cipher ,algorithms ,modes 
        from cryptography .hazmat .backends import default_backend 
        c =Cipher (algorithms .AES (key ),modes .CBC (iv ),backend =default_backend ())
        enc =c .encryptor ()
        ct =enc .update (raw )+enc .finalize ()
    except ImportError :

        ct =b''
        prev =iv 
        for i in range (0 ,len (raw ),16 ):
            blk =bytes (a ^b for a ,b in zip (raw [i :i +16 ],prev ))
            ks =hashlib .sha256 (key +prev ).digest ()[:16 ]
            blk =bytes (a ^b for a ,b in zip (blk ,ks ))
            ct +=blk 
            prev =blk 
    import base64 
    return base64 .b64encode (iv +ct ).decode ()

def _decrypt_tokens (data :str )->str :
    import base64 
    key =_get_device_key ()
    raw =base64 .b64decode (data )
    iv ,ct =raw [:16 ],raw [16 :]
    try :
        from cryptography .hazmat .primitives .ciphers import Cipher ,algorithms ,modes 
        from cryptography .hazmat .backends import default_backend 
        c =Cipher (algorithms .AES (key ),modes .CBC (iv ),backend =default_backend ())
        dec =c .decryptor ()
        pt =dec .update (ct )+dec .finalize ()
    except ImportError :
        pt =b''
        prev =iv 
        for i in range (0 ,len (ct ),16 ):
            blk =ct [i :i +16 ]
            ks =hashlib .sha256 (key +prev ).digest ()[:16 ]
            dec_blk =bytes (a ^b for a ,b in zip (blk ,ks ))
            pt +=bytes (a ^b for a ,b in zip (dec_blk ,prev ))
            prev =blk 
    pad =pt [-1 ]
    if pad <1 or pad >16 :
        raise ValueError ('Ungültiges Padding – falsches Gerät')
    return pt [:-pad ].decode ('utf-8')
