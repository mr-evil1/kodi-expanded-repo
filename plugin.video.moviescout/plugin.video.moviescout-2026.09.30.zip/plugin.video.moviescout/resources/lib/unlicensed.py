def is_unlicensed_allowed():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting('scraper.allow_unlicensed') == 'true'
    except Exception:
        return False


def filter_scrapers_by_license(scraper_modules):
    if is_unlicensed_allowed():
        return list(scraper_modules)
    result = []
    for m in scraper_modules:
        if getattr(m, 'STREAMLG', 'LG1') != 'LG1':
            result.append(m)
    return result


def filter_scraper_entries_by_license(scraper_entries):
    if is_unlicensed_allowed():
        return list(scraper_entries)
    result = []
    for entry in scraper_entries:
        if isinstance(entry, tuple):
            s, m = entry
            if getattr(m, 'STREAMLG', 'LG1') != 'LG1':
                result.append(entry)
        else:
            if getattr(entry, 'STREAMLG', 'LG1') != 'LG1':
                result.append(entry)
    return result
